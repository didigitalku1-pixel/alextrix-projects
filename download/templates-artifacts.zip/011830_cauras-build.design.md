---
version: "1.0.0"
name: "Cauras Visual System"
description: "A conversion-focused design system for visual workspace products using a deep slate palette and high-contrast blue accents."

colors:
  background: "#020617"
  surface: "#0f172a"
  surface-lighter: "#1e293b"
  primary: "#3b82f6"
  primary-glow: "#8484ff"
  accent-indigo: "#6366f1"
  text-main: "#f8fafc"
  text-muted: "#94a3b8"
  border-dim: "rgba(255, 255, 255, 0.1)"
  border-glow: "rgba(59, 130, 246, 0.3)"

typography:
  heading:
    family: "Geist, sans-serif"
    weight: 500
    tracking: "-0.05em"
  body:
    family: "Inter, sans-serif"
    weight: 400
    size: "14px"
  mono:
    family: "Geist Mono, monospace"
    weight: 400

spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "40px"
  section: "160px"

rounded:
  sm: "4px"
  md: "8px"
  lg: "12px"
  xl: "16px"
  full: "9999px"

components:
  nav:
    position: "sticky"
    top: "0px"
    z-index: 20
    blur: "12px"
  hero-title:
    font-size: "8rem"
    line-height: "0.9"
    gradient-mask: "linear-gradient(290deg, transparent, black)"
  card:
    background: "linear-gradient(to bottom right, #171717, #0a0a0a)"
    border: "1px solid rgba(255,255,255,0.1)"
    shadow: "2xl"
  editor-mockup:
    aspect: "video"
    perspective: "500px"
    transform: "rotateX(5deg)"
  shiny-button:
    border-width: "2px"
    animation: "border-spin 2.5s linear infinite"

motion:
  duration-fast: "300ms"
  duration-standard: "600ms"
  curve-out: "cubic-bezier(0.25, 1, 0.5, 1)"
---
## Overview
The Cauras system is built to evoke professional creative power. It uses a "Deep Space" theme (Slate-950) paired with interactive glass elements and glowing borders to simulate a high-end desktop application environment.

## Colors
The palette is rooted in dark neutrals with saturated blue and indigo accents for functional actions.
- **Primary UI:** Slate-950 background with white/10 borders.
- **Signaling:** Indigo-500 is used for 'Pro' or featured states; Blue-600 for 'Publish' or primary CTAs.
- **Gradients:** Subdued radial glows (#3b82f633) are placed behind cards to indicate depth.

## Typography
- **Headings:** Geist is the primary brand typeface, used with tight tracking and negative leading for a modern, compact look.
- **UI Labels:** Inter or system sans-serif at 12px-14px for maximum legibility in dense property panels.
- **Display:** Large display text uses a linear-gradient mask to fade out at specific angles.

## Spacing
Follows an 8px grid system. Section padding is aggressive (160px) to provide a premium feel, while internal component spacing (property panels) is condensed (4px-8px) to mimic professional IDEs.

## Layout
- **Layering:** Uses a fixed `gradient-blur` top bar to blend content into the viewport.
- **Z-Index:** Nav (20), Mobile Drawer (50), Background ( -10).
- **Structure:** 3-column app mockup (Layer Tree | Canvas | Property Panel) with fixed sidebars and scrollable centers.

## Elevation & Depth
- **Glassmorphism:** Components use `backdrop-blur` and `bg-white/5` to create layered transparency.
- **3D Transforms:** The primary feature showcase utilizes `perspective-normal` and `rotate-x-5` to break the 2D plane.
- **Glows:** Absolute-positioned radial gradients serve as midground light sources.

## Shapes
- **Containers:** High-radius corners (16px) for cards to soften the dark aesthetic.
- **Controls:** Pill-shaped (rounded-full) buttons and toggle containers.
- **Status:** 6px-8px circular dots for 'Active' or 'Live' indicators.

## Components
- **Visual Editor Mockup:** Features a layered side panel, a center canvas with blue selection handles (2px border), and property inputs.
- **Pricing Toggle:** A pill-shaped container with a sliding background indicator (Indigo-500) that transforms on click.
- **Marquee:** Seamless testimonial loops moving LTR and RTL with edge masks.
- **FAQ Accordion:** Bordered boxes with 180-degree rotating icons on expand.

## Motion
- **Fade-In-Up:** Standard entry for section headers (0.6s ease-out).
- **Shiny CTA:** A conic-gradient border animation that spins continuously to draw the eye.
- **Radar Sweep:** A 360-degree rotating gradient mask for performance visualizations.

## Do's and Don'ts
- **Do:** Use `mask-image` for smooth section transitions.
- **Do:** Pair thin borders (1px) with subtle glows for interactivity.
- **Don't:** Use solid white backgrounds for cards; stick to transparent slate/neutral mixes.
- **Don't:** Use standard sharp corners; maintain a minimum of 8px radius for UI elements.

## Accessibility
- **Selection:** High-contrast selection color (blue-500/30) with white text.
- **Contrast:** Ensure muted text (#94a3b8) maintains 4.5:1 ratio against slate-950.
- **Interactive:** Every button and trigger must have a defined `:hover` state transition.