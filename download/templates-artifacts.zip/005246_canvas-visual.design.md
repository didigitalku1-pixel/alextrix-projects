---
version: "2.4.0"
name: "Canvas Visual Synthesis"
description: "A high-contrast, parametric design system for creative intelligence tools and post-digital interfaces."
colors:
  background: "#050505"
  foreground: "#D4D4D4"
  primary: "#F97316"
  primary-muted: "rgba(249, 115, 22, 0.3)"
  surface: "#111111"
  surface-border: "rgba(255, 255, 255, 0.1)"
  neutral-mute: "#525252"
  accent-beam: "#F97316"
typography:
  display:
    family: "Space Grotesk"
    weight: 700
    tracking: "-0.05em"
  body:
    family: "Inter"
    weight: 400
    size: "16px"
  mono:
    family: "Geist Mono"
    weight: 500
    size: "10px"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "48px"
  section: "96px"
rounded:
  none: "0px"
  full: "999px"
components:
  nav:
    position: "sticky"
    z-index: 50
    border-bottom: "1px solid rgba(255,255,255,0.05)"
  button-primary:
    padding: "10px 20px"
    border: "1px solid #F97316"
    bg: "transparent"
    hover-bg: "#F97316"
  floating-card:
    shadow: "0 25px 50px -12px rgba(0, 0, 0, 0.5)"
    transition: "transform 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94)"
  stat-block:
    border-left: "2px solid transparent"
    hover-border: "#F97316"
motion:
  fade-slide:
    keyframes: "fadeSlideIn"
    duration: "0.8s"
    timing: "ease-out"
  beam-drop:
    duration: "5s"
    timing: "cubic-bezier(0.4, 0, 0.2, 1)"
---
## Overview
Canvas is a visual system built for the "post-digital" era, emphasizing modularity, brutalist constraints, and parametric efficiency. It utilizes a dark-mode first approach with high-intensity primary accents (#F97316).

## Colors
The palette is dominated by a deep black (#050505) and a scale of neutrals. The signature color is Safety Orange (#F97316), used sparingly for beams, interactive borders, and primary calls-to-action. Gradients are minimal, used only for depth masks and animated border effects.

## Typography
- **Space Grotesk**: Reserved for large watermark displays and header accents.
- **Inter**: The primary workhorse for UI copy and descriptive text.
- **Geist Mono**: Used for technical labels, versioning, and figure markers to reinforce the "engine" aesthetic.

## Spacing
A rigid grid system based on multiples of 8px. The system utilizes wide horizontal gutters (px-12) and significant vertical section separation (py-24 or py-32) to allow visual elements to breathe.

## Layout
- **Layering**: High use of z-index stacks. Backgrounds feature a grid-bg pattern with a radial mask. Midground features floating elements with 3D rotations.
- **Grid**: A 12-column system is used for the hero, splitting into asymmetrical 5-5-2 or 7-5 distributions.
- **Perspective**: Containers often use `perspective: 1000px` to allow child elements to rotate in 3D space.

## Elevation & Depth
Depth is communicated via grayscale image opacity (ranging from 20% to 80%) and 3D transforms (`rotate-x`, `rotate-y`). Shadows are heavy and sharp, primarily used on active cards to simulate lift.

## Shapes
Strictly rectangular and brutalist. Buttons and cards utilize `rounded-none`. The only exceptions are avatars and specific utility icons which use `rounded-full`.

## Components
- **Animated Beams**: Vertical and horizontal lines with a trailing gradient animation to simulate data flow.
- **Floating Cards**: Images or UI snippets with slight rotations that scale up and straighten on hover.
- **Metric Grid**: Large light-weight typography paired with uppercase mono labels.
- **Shimmer Button**: A custom button with a conic-gradient border beam and a solid center cutout.

## Motion
- **Entrance**: Sequence-based entry using `fadeSlideIn` with staggered delays (0.2s increments).
- **Interaction**: Cards utilize a transition of 0.5s for scaling. Icons often feature slow, infinite rotations.
- **Ambient**: Background beams and grid masks provide subtle, non-blocking motion.

## Do's and Don'ts
- **Do**: Use grayscale images with hover-to-color transitions.
- **Do**: Maintain strict 0px border-radius for primary UI containers.
- **Don't**: Use soft pastels or rounded corners on structural elements.
- **Don't**: Overload the screen with the primary orange; use it only for focus points.

## Accessibility
- Focus states are indicated by the primary orange color.
- High contrast ratio (white/orange on black) is mandatory for readability.
- Selection color is customized to #F97316 with black text for maximum visibility.