---
version: 1.0.0
name: Finex Finance Visual System
description: A premium dark-mode SaaS design system focused on fintech clarity, depth, and motion.
colors:
  background: "#000000"
  surface: "#0A0A0C"
  surface-elevated: "#121215"
  primary: "#3B82F6"
  secondary: "#8B5CF6"
  accent-cyan: "#22D3EE"
  accent-green: "#22C55E"
  border: "rgba(255, 255, 255, 0.1)"
  text-primary: "#FFFFFF"
  text-muted: "#9CA3AF"
typography:
  display:
    family: "Oswald, sans-serif"
    weight: "300"
    lineHeight: "1.1"
  body:
    family: "Inter, sans-serif"
    weight: "400"
    lineHeight: "1.6"
  mono:
    family: "Geist Mono, monospace"
    weight: "500"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "40px"
  container-padding: "1.5rem"
rounded:
  sm: "4px"
  md: "8px"
  lg: "12px"
  xl: "24px"
  full: "9999px"
  card: "2rem"
  phone: "3rem"
components:
  nav:
    style: "fixed-floating"
    blur: "backdrop-blur-md"
    background: "rgba(0, 0, 0, 0.9)"
  button-primary:
    style: "pill"
    animation: "beam-spin"
    glow: "blue-glow-hover"
  card-dashboard:
    border: "1px solid rgba(255, 255, 255, 0.08)"
    background: "#101018"
    shadow: "shadow-2xl"
  phone-mockup:
    frame: "#222"
    depth: "ring-1 ring-white/10"
    overflow: "hidden"
motion:
  curve: "cubic-bezier(0.25, 0.46, 0.45, 0.94)"
  duration-standard: "0.8s"
  fade-up: "translateY(30px) to (0)"
  blur-in: "scale(0.95) blur(15px) to (1)"
---
## Overview
Finex is a high-contrast dark system designed for financial data density. It utilizes "Dynamic Depth"—layering background noise, radial gradients, and semi-transparent surfaces to create an institutional yet futuristic aesthetic.

## Colors
The palette is rooted in deep blacks (`#000000`) and charcoals, using vibrant blues and purples as functional accents for growth and analytics. Borders use a consistent low-opacity white (10%) to define shapes without breaking the dark immersion.

## Typography
- **Oswald (Light)** is reserved for large headlines and financial figures to evoke a sense of precision.
- **Inter** handles all interface and body text for high readability at small scales.
- High use of `tracking-tight` on headlines and `tracking-widest` on small uppercase labels.

## Spacing
A hybrid spacing system uses standard 8px increments for layouts, but transitions to wide internal gutters (32px - 64px) within dashboard cards to prevent data clutter.

## Layout
- **Layering:** Background (Noise/Grid) > Midground (Glows/Radial Gradients) > Foreground (Cards/Glass surfaces).
- **Responsive Stacks:** Navigation uses a floating center-aligned container on desktop, collapsing to a full-width header on mobile.
- **Z-Index Strategy:** Nav (50) > Floating Tooltips (20) > Main Content (10) > Animated Backgrounds (-10).

## Elevation & Depth
Depth is achieved through `backdrop-blur-md` and `box-shadow: 0 0 40px -10px rgba(59,130,246,0.5)`. There are no traditional drop shadows; shadows are replaced by colored glows (blooms) that correspond to the primary action color.

## Shapes
Extremely rounded corners are a signature. Most containers use `2rem` (32px), while primary buttons and the navigation bar use the `9999px` pill shape. This softens the technical nature of financial data.

## Components
- **Beam Button:** Features a conic-gradient border animation that simulates a rotating light beam around the edge.
- **Radar Chart:** A multi-layered SVG component with dashed concentric circles and overlapping linear-gradient fills.
- **Dashboard Grid:** Bento-style layout using `grid-template-rows` to allow featured cards (like Cashflow) to span multiple vertical units.
- **Phone Frame:** A persistent UI shell used for mobile previews, featuring a 'Dynamic Notch' and fixed bottom navigation.

## Motion
- **Scroll Triggers:** Every major section uses `scroll-fade-up` or `scroll-blur-in` triggered as the user enters the viewport.
- **Looping Animations:** Continuous floating effects (6s-8s durations) are applied to financial labels to simulate an 'active market' feel.
- **Progress Bars:** Use `infinite` keyframe loops that pulse the width from 0 to its target percentage to indicate live loading.

## Do's and Don'ts
- **Do:** Use radial gradients to highlight the top-center of cards.
- **Do:** Pair a sharp accent color (like Cyan) with a soft background glow of the same hue.
- **Don't:** Use solid white backgrounds or high-opacity dividers.
- **Don't:** Use heavy weights for the Oswald font; it must remain light (300) to feel premium.

## Accessibility
- Selection color is customized to `bg-primary` with black text to ensure focus visibility.
- All interaction states (hover/focus) include a `scale-[1.02]` or `brightness-110` to provide tactile feedback.
- Text contrast is maintained by using `gray-400` as the absolute minimum brightness for secondary labels.