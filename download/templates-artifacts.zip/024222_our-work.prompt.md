Recreate the website "Stacked Marketing" with high visual fidelity as a Tailwind CSS and Vanilla JavaScript landing page.

The result must match the supplied reference website exactly, preserving its specific aesthetic of B2B tech professionalism mixed with serif typography.

Preserve source quirks:
- The navigation bar uses `pointer-events-none` on its outer fixed container and `pointer-events-auto` on the inner glass pill to allow clicking through the empty space.
- Responsive layout uses a negative margin technique (`ml-[calc(50%-50vw)]`) to achieve full-width sections inside a centered container.
- Section spacing is inconsistent, specifically the "Credibility Callout Section" is empty but occupies space.
- The social proof marquee uses a specific "scale-90" on mobile which transitions to "scale-100" on desktop.

CRITICAL FIDELITY CONSTRAINTS
- Use only Google Fonts: Instrument Serif (Italic), Inter, and Montserrat.
- Maintain the "glass" effect on the navbar: `backdrop-filter: blur(12px)` with `rgba(255, 255, 255, 0.8)` background.
- Ensure the "marquee-mask" utility is applied to the logo scroller: a linear gradient mask that fades the left and right edges to transparent.
- Do not use standard HTML details markers; use the custom `iconify-icon` (solar:alt-arrow-down-linear) and handle the `group-open:rotate-180` state.

TECH STACK / DEPENDENCIES
- Tailwind CSS (via CDN: https://cdn.tailwindcss.com)
- Iconify (via CDN: https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js)
- Lucide Icons (via CDN: https://unpkg.com/lucide@latest)
- Google Fonts: Instrument Serif, Inter, Montserrat

GLOBAL STYLE
- Body: `font-family: "Inter", sans-serif; antialiased; background-color: #FAFAFA; color: #666666;`
- Primary Accent: `#c9a646` (Gold/Tan)
- Dark Backgrounds: `#111827` (Slate 950)
- Selection: `bg-rose-100 text-rose-900`

ASSET MAP
- Redis Logo: https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Logo-redis_%28old%29.svg/3840px-Logo-redis_%28old%29.svg.png
- Mole Street Logo: https://4949049.fs1.hubspotusercontent-na1.net/hubfs/4949049/Logo%20-%20Horizontal.svg
- MindsDB Logo: https://images.g2crowd.com/uploads/product/image/social_landscape/social_landscape_b7f48a55cb259f2dce1b083a3cd2786d/mindsdb.png
- Case Study Hero: https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80
- Founder Photo (Harry): https://i.postimg.cc/4yJYQVVb/Work-Photo-Without-Spot.png
- Testimonial 1 (Neil): https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/c2691d35-e224-4940-9d4c-c76b5af4dce4_320w.jpg
- Testimonial 2 (Gavin): https://res.cloudinary.com/dcl96injm/image/upload/v1778182517/Gavin_Cahill_vzipix.jpg
- Testimonial 3 (Zac): https://content.api.news/v3/images/bin/db2f3093224863101773a6da90d4015b

VECTOR / ICON SHAPES
- Use `solar` icon set for most UI elements: `solar:graph-up-linear`, `solar:danger-circle-linear`, `solar:lightbulb-bolt-linear`, `solar:graph-down-linear`, `solar:users-group-rounded-linear`, `solar:clock-circle-linear`, `solar:check-circle-bold`.
- Ecosystem Checklist Icon: Custom SVG Circle `#fef9c3` fill with `#fcd34d` stroke and a green check path `d="M8 12L11 15L16 9"`.

MEDIA BEHAVIOR
- Loom Embed: iframe src `https://www.loom.com/embed/9784f841274a4bfea2f5c1caa1fbc4cd` inside a container with `padding-bottom: 56.25%` (16:9 aspect ratio).
- Logo Marquee: CSS animation `infinite-scroll` (40s, linear) moving from `0%` to `-50%` on a container with duplicated logo sets for a seamless loop.

LAYER STACK / POSITIONING MAP
- Header: `fixed top-0 z-50`, floating pill layout.
- Hero: Relative section with an absolute `inset-0` background grid (`linear-gradient` of `#f0f0f0` lines) and a `radial-gradient` mask (`ellipse 60% 50% at 50% 0%`).
- Case Study: `lg:flex-row` with a `w-1/2` image container using `aspect-square` and a floating badge at `bottom-6 left-6`.
- Floating Duplication Guide: `fixed bottom-6 right-6 z-[100]` white card with `shadow-xl`.

SECTION 1 - NAVIGATION
- Floating glass pill (`glass` class).
- Left: "Stacked Marketing" in `Instrument Serif` medium italic, tracking-tight.
- Right: `info@stackedmarketing.com` (hidden on mobile) and "Let's Talk" button in dark grey `bg-gray-900` with gold hover effect.

SECTION 2 - HERO
- Eyebrow: "For B2B Companies" in gold CAPS, tracking-widest, inside a `bg-slate-50` pill.
- Headline: 5rem font-serif (`Instrument Serif`), tracking-tighter.
- Video: Loom embed wrapped in a dark border-white/50 container with `shadow-2xl`.

SECTION 3 - LOGO MARQUEE
- Heading: "Our Experience" in `Instrument Serif`.
- Layout: `marquee-mask` container with an `animate-infinite-scroll` flex row.

SECTION 4 - CASE STUDY
- Badge: "Featured Case Study" in Montserrat gold.
- Content: Two-column layout. Left image has a metric badge for "$65,000 Revenue Closed". Right column uses Solar icons for "Challenge" and "Solution".

SECTION 5 - PAIN POINTS
- Title: "Why Cold Email Hasn't Worked For You".
- Grid: 3-column `grid-cols-1 md:grid-cols-3`. Each card has a gradient `from-[#fdf6e3] to-white` and a light gold icon box.

SECTION 6 - THE 60-DAY SYSTEM (SLATE BOX)
- Container: `bg-[#111827]` with `border-[#c9a646]/20`.
- Content: Two columns ("What You Get" vs "After 60 Days").
- Bottom: Integrated guarantee block with a specific gold `bg-[#c9a646]` CTA button.

SECTION 7 - THE ECOSYSTEM
- Layout: Centered checklist using custom SVG checkmarks. Two-column grid `sm:grid-cols-2`.

GLOBAL ANIMATION / INTERACTION RULES
- All major sections use `animate-fade-up` (0.8s cubic-bezier) with staggered delays (`delay-100` to `delay-500`).
- `details` elements use `group-open:rotate-180` for the chevron icon.
- Smooth scrolling enabled on `html`.

IMPLEMENTATION REQUIREMENTS
- Do not substitute assets or URLs.
- Use the exact pixel spacing and padding classes (e.g., `md:pt-32`, `p-12`, `mb-16`).
- Ensure the full-width backgrounds (`100vw`) do not cause horizontal scrolling by using the `ml-[calc(50%-50vw)]` technique correctly.