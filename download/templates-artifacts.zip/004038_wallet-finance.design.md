---
version: 1.0.0
name: Finance Visibility System
description: Modern SaaS aesthetic with significant usage of glassmorphism, blurred background accents, and tiered elevation for financial data visualization.
colors:
  background: "#FFFFFF"
  foreground: "#111827"
  primary: "#000000"
  accent-emerald: "#10B981"
  accent-indigo: "#6366F1"
  accent-fuchsia: "#D946EF"
  accent-amber: "#F59E0B"
  muted: "#4B5563"
  border: "#F3F4F6"
  glass-white: "rgba(255, 255, 255, 0.7)"
  glass-border: "rgba(255, 255, 255, 0.2)"
typography:
  fontFamily: "Geist, Inter, system-ui"
  h1:
    fontSize: "4.5rem"
    fontWeight: "700"
    letterSpacing: "-0.05em"
    lineHeight: "0.95"
  h2:
    fontSize: "3.75rem"
    fontWeight: "600"
    letterSpacing: "-0.025em"
  body:
    fontSize: "1rem"
    fontWeight: "400"
    lineHeight: "1.5"
  stats:
    fontSize: "1.125rem"
    fontWeight: "600"
  label:
    fontSize: "0.75rem"
    fontWeight: "500"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "32px"
  container-px: "1.5rem"
  section-py: "6rem"
rounded:
  sm: "4px"
  md: "8px"
  lg: "12px"
  xl: "16px"
  card: "24px"
  full: "999px"
components:
  buttons:
    primary: "Black bg, white text, pill-shaped, transition-transform duration-300"
    secondary: "Glassmorphic bg-white/10, border-white/20, backdrop-blur-md"
  cards:
    dashboard: "Glass background, backdrop-blur, ring-1 ring-black/5, layered shadows"
    stat-item: "White bg, ring-1 ring-black/5, rounded-xl, internal padding 1rem"
  navigation:
    top-bar: "Border-b border-gray-100, relative z-20, text-sm font-geist"
  badges:
    pill: "Uppercase or font-medium, rounded-full, background opacity 10-20% of stroke color"
motion:
  fadeSlideIn: "opacity: 0, transform: translateY(30px) -> opacity: 1, transform: translateY(0)"
  speed: "1s"
  easing: "ease-out"
---
## Overview
The Finance Visibility System is designed to present complex data with clarity and depth. It uses a "layered glass" approach where background gradients (fuchsia, indigo, amber) provide light sources behind semi-transparent UI elements.

## Colors
The palette is anchored in grayscale neutrals with vivid functional accents. Emerald represents live status and positive growth, while Indigo and Fuchsia provide depth in the visual background layers. Glassmorphism is achieved using `white/70` with `backdrop-blur-md`.

## Typography
Geist is the primary font for its geometric precision, essential for financial data. Inter serves as the fallback. Headlines use extreme tracking-tighter settings and low line-heights to create a modern architectural feel.

## Spacing
An 8px grid system guides the layout. Stat grids use a compact 12px gap, while hero sections leverage massive 160px vertical padding to create luxury whitespace.

## Layout
The system uses a "Visual/Copy" split (60/40) for hero sections. It prioritizes a Z-index hierarchy: background glow (Z-0), page content (Z-10), and floating dashboard badges (Z-20).

## Elevation & Depth
Depth is not created with simple shadows but with multi-layered drop shadows simulating different distances from the surface. The main dashboard cards use a six-step shadow stack ranging from 2.8px to 100px blur.

## Shapes
Highly rounded corners (24px to 32px) are used for major containers to soften the technical nature of the data. Buttons and interactive pills are strictly `rounded-full`.

## Components
- **Stat Cards**: Nested white tiles within a glass container. Feature `object-cover` imagery to represent categories.
- **Floating Badges**: Compact info-pills that overlap card boundaries to break the grid and add depth.
- **Horizontal Scrollers**: Multi-card displays with linear-gradient masks on edges to indicate overflow.
- **Feature Bullets**: Icon-led blocks with semi-transparent backgrounds and subtle ring borders.

## Motion
All entrance animations follow a staggered `fadeSlideIn` pattern. Scrollers use `scroll-smooth` with customized JS-driven arrow states. Background components may include high-performance Canvas or WebGL shaders for ambient movement.

## Do's and Don'ts
- **Do**: Use backdrop-blur whenever placing white cards over colored backgrounds.
- **Do**: Stagger animation delays by 0.1s to create a sequential build.
- **Don't**: Use solid borders; prefer `ring-1` with 5% or 10% opacity.
- **Don't**: Use standard sans-serif weights for headers; always use Medium (500) to Bold (700).

## Accessibility
- Maintain a minimum contrast ratio of 4.5:1 for body text against glass backgrounds.
- Provide `sr-only` descriptions for all icon-only buttons like slider controls.
- Ensure mobile toggle buttons have clear `aria-expanded` states.