Recreate the website "Mobile App Design Interface" with high visual fidelity as a Tailwind CSS and HTML site.

The result must match the supplied reference website, including its three-screen layout, specific mobile app aspect ratios, and precise stacking of floating cards.

Preserve source quirks:
- The site uses a mix of Inter for standard body text and Geist Mono for labels/headers.
- The "Floating Peach Card" in Screen 1 has a very specific, multi-layered complex shadow.
- Screen 3's "Floating Dark Profile Card" is intentionally offset to the right beyond the container boundary (right-[-40px]).
- No-scrollbar utility is required to hide scrollbars while maintaining functionality in the Course Schedule list.

CRITICAL FIDELITY CONSTRAINTS
- Background is a fixed `zinc-700` container with a `mix-blend-screen` and `saturate-0` animated background component.
- All screens have a fixed height of `840px` and a max-width of `sm` (approx 384px) to simulate mobile devices.
- Aspect ratios for profile images and card thumbnails must be preserved (e.g., 24x24 for library image, 16x16 for professor profile).

TECH STACK / DEPENDENCIES
- Tailwind CSS (via CDN: https://cdn.tailwindcss.com)
- Iconify (via CDN: https://code.iconify.design/3/3.1.0/iconify.min.js)
- Unicorn Studio (v1.4.29) for background effects.
- Fonts: Inter (300-600) and Geist Mono (300-700) from Google Fonts.

GLOBAL STYLE
- Body: `font-family: 'Inter', sans-serif;` with `bg-zinc-700`.
- Custom CSS for `-webkit-mask` border gradients used on floating cards.
- Scrollbar hiding: `.no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }`.

ASSET MAP
- Screen 1 Avatars:
  - https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/b8deab20-79f0-4568-be6e-c4baeded4050_320w.webp
  - https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/6e807631-f507-40d1-92e2-17f496e11b6b_320w.webp
  - https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/800c4988-577b-41c6-ab7f-990312f9f0cd_320w.webp
- Screen 2 Background: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/67351756-a1a8-4042-926e-9015a7f1e799_1600w.webp
- Screen 2 Thumbnail: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/843e481b-cf5e-495f-bc63-2febbc784407_320w.webp
- Screen 3 Professor: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/1b4169b2-1e5b-4014-a9a6-1785e7867fcd_320w.webp

VECTOR / ICON SHAPES
- Use `solar` icon sets via iconify: `solar:arrow-left-bold-duotone`, `solar:calendar-bold-duotone`, `solar:add-circle-bold-duotone`, `solar:calendar-add-bold-duotone`, `solar:upload-bold-duotone`, `solar:bookmark-bold-duotone`, `solar:chat-round-dots-bold-duotone`, `solar:pen-new-square-bold-duotone`, `solar:star-bold-duotone`, `solar:alt-arrow-right-bold-duotone`.

LAYER STACK / POSITIONING MAP
- Wrapper: Grid `xl:grid-cols-3` with `gap-10`.
- Screens: `flex flex-col h-[840px] rounded-3xl relative overflow-hidden shadow-2xl`.
- Screen 1: Header (Foreground) -> Content (Midground) -> Timeline line (Background, absolute) -> Floating Peach Card (z-20, absolute-like offset) -> Green Section (Footer position via mt-auto).
- Screen 2: Background Image (z-0, inset-0) -> Gradient Overlay (z-0) -> Top Bar (z-10) -> Floating Library Card (z-20, absolute top-1/2, -translate-y-1/2) -> Action Buttons (z-30, absolute right-4).
- Screen 3: White Header Card (z-10, sticky-like top) -> Dark Profile Card (z-20, absolute right-[-40px] top-[340px]) -> Course Schedule (Background flow, scrollable).

SECTION 1 - Event & Timeline (White Screen)
- Background: `bg-white`.
- Text: "UX Research Sync", "Mar 12th - 09:00", "Design Wing - 204" using `font-geist-mono` for labels.
- Timeline: Vertical `bg-gray-200` line at `right-6` with 3 overlapping avatars.
- Peach Card: `bg-orange-50` with `border-orange-100/50`. Contains "Current Sprints" and two list items with progress percentages.
- Bottom: `bg-neutral-500` with a dashed-border upload area.

SECTION 2 - Immersive Image (Dark Screen)
- Background: Image with `opacity-90` and a `bg-gradient-to-b from-black/40 to-black/80`.
- Pulse: Green dot with `animate-pulse` next to "84,209 designers active!".
- Library Card: `backdrop-blur-md`, `bg-white/90`. Includes a 24x24 thumbnail and "Reserve a Seat" button.
- Interaction: Floating vertical column of 3 blurred glass-effect buttons.

SECTION 3 - Course Details (Grey/White Screen)
- Layout: Top half `bg-white` with rounded bottom `rounded-b-[3rem]`. Bottom half `bg-gray-200` containing scrollable schedule.
- Dark Card: `bg-[#1a1a1a]` with Julian Thorne's profile, statistics (Courses: 5, Projects: 42, Rate: 9.9), and a "Enrol his Courses" button using a custom border-gradient.
- Schedule: Vertical list with Lessons 01-03, each with a `solar:alt-arrow-right-bold-duotone` icon.

GLOBAL ANIMATION / INTERACTION RULES
- All buttons must have `transition` with `hover:scale` or `hover:bg` shifts.
- The background must include the UnicornStudio initialization script and data attributes for the aura effect.

COMMON MISTAKES TO AVOID
- Do not use standard CSS scrollbars; use the `no-scrollbar` utility.
- Do not simplify the Peach Card shadow; it must be a multi-stop box-shadow as defined in the source.
- Do not center the Professor card in Screen 3; it must overflow to the right.

IMPLEMENTATION REQUIREMENTS
- Use original asset URLs.
- Maintain the `h-[840px]` fixed height for all screens.
- Ensure `backdrop-blur` is applied to the floating elements in Screen 2.