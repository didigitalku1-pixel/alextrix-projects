Recreate the website "Gemini 3 Motion Landing Page Template" with high visual fidelity as a Tailwind CSS and Vanilla JavaScript site.

The result must match the supplied reference website, not a cleaned-up reinterpretation.

Preserve source quirks:
- The mobile layout uses full-screen sections with 100vh height, while desktop cards use a specific 3:4 aspect ratio within the viewport.
- The scroll container uses `snap-y snap-mandatory` for a presentation-like feel.
- Several elements use specific hardcoded Tailwind brackets for custom animations (e.g., `[animation:animationIn_0.8s_ease-out_0.1s_both]`).

CRITICAL FIDELITY CONSTRAINTS
- All sections must have a `snap-start` property to ensure proper vertical snapping.
- All content must reside within a 3:4 aspect ratio card (on desktop) named `.glass-panel` with `backdrop-filter: blur(20px)` and background `rgba(23, 23, 23, 0.6)`.
- The background of the entire page is `#050505` (`bg-neutral-950`).
- Every image must use the exact Supabase URL provided. Do not use placeholders.

TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN: https://cdn.tailwindcss.com)
- Iconify Icon Component (CDN: https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js)
- Fonts: Inter (200-600), Geist, Roboto, Montserrat, Poppins, Playfair Display, Instrument Serif, Merriweather, Bricolage Grotesque, Plus Jakarta Sans, Manrope, Space Grotesk, Work Sans, PT Serif, Geist Mono, Space Mono, Quicksand, Nunito (all via Google Fonts).

GLOBAL STYLE
- Typography: Primary font is 'Inter', sans-serif.
- Selection: `selection:bg-white/20 selection:text-white`.
- Keyframes:
  - `animationIn`: 0% { opacity: 0; transform: translateY(30px); filter: blur(10px); } 100% { opacity: 1; transform: translateY(0); filter: blur(0px); }
  - `marquee`: 0% { transform: translateX(0); } 100% { transform: translateX(-50%); }
  - `shimmer`: From -100% to 200% with skewX(-15deg).
  - `textSlide`: TranslateY(110%) to (0%) with ease-out.

ASSET MAP
- Slide 1 BG: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/53970266-f8db-425c-8883-5535f3e41c4d_1600w.webp
- Slide 2 BG: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/d1e715c0-e250-4e7f-a4f5-433e96d81f31_1600w.webp
- Slide 3 BG: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/6ea6d66c-a7a6-4548-9b3f-680a206078c3_1600w.webp
- Slide 6 BG: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/47ccf769-0cb4-4a95-804e-cc919fd6d449_1600w.webp
- Slide 7 BG: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/7b8e6a1f-44f9-49ef-a26c-bf0d87724acf_1600w.webp
- Slide 8 BG: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/67df17f7-9681-4bd3-927b-ac569042a884_1600w.webp

LAYER STACK / POSITIONING MAP
- Fixed Header: `z-[60]`, top-0, flex justify-between.
- Nav Dots: `fixed right-8 top-1/2 -translate-y-1/2 z-[60]`, vertical flex.
- Main Scroll: `overflow-y-scroll snap-y snap-mandatory h-screen`.
- Slide Cards: Relative, `z-10` for content, `.glass-panel` background layer, and absolute image backgrounds using `bg-cover`.

SECTION 1 - COVER
- Heading: "Gemini 3" (6xl) / "Motion" (neutral-500 light).
- Icon: `solar:stars-minimalistic-bold-duotone` in a rounded-lg gradient box.
- Bottom Row: Animated pulse dot with text "Ready" and bouncing `solar:arrow-down-bold-duotone`.

SECTION 2 - INTRO
- Content: "02 — Intro" tag, title "Enhance with Motion".
- UI Mockup: A container with `backdrop-blur-lg` containing multiple shimmering rectangles (`bg-gradient-to-br from-white/10`).

SECTION 3 - BUTTONS
- Interaction: Shimmering beam button.
- CSS Pattern: A pill button with a `conic-gradient` spinning behind it, revealed on hover.
- Internal Shimmer: A `-skew-x-12` span that translates across the button on hover.

SECTION 4 - TYPOGRAPHY
- Layout: Vertical stack of "Clip-path", "Typography", "Animation".
- Style: Color transition from white to neutral-600 to neutral-800.

SECTION 5 - SOCIAL PROOF
- Marquee: `flex animate-marquee` containing brand icons: Nvidia, Linear, Vercel, Apple, Stripe, SpaceX.
- Masks: `bg-gradient-to-r from-[#0d0d0d] to-transparent` overlays on left/right for fade-out effect.

SECTION 6 - SWITCHING
- Component: 3D Stacked cards.
- Interaction: Floating buttons for Left/Right arrows.
- Style: Main card with `bg-stone-950` and `ring-white/10`.

SECTION 7 - INTERACTION
- Component: Flashlight cards.
- JS Logic: `onmousemove` sets CSS variables `--mouse-x` and `--mouse-y` to drive a `radial-gradient` highlight.

SECTION 8 - END
- Layout: Vertical split with a masked scrolling quote section.
- Mask: `mask-image: linear-gradient(180deg, transparent, black 20%, black 95%, transparent)`.
- CTA: White button with `Follow @mengto` and `solar:arrow-right-up-bold-duotone`.

GLOBAL ANIMATION / INTERACTION RULES
- Intersection Observer: Add `.animate` class to `.animate-on-scroll` elements when 20% in view to trigger the `animationIn` CSS animation.
- Navigation: `navigateSlide` function to scroll specific sections into view on arrow click.
- Scroll Sync: Update the side navigation dots highlight based on which section is currently active in the viewport.

IMPLEMENTATION REQUIREMENTS
- Use `box-sizing: border-box` and hide scrollbars on the body.
- Preserve the precise Tailwind utility classes for spacing (e.g., `pt-20 md:pt-12`).
- Ensure the `flashlight-card` uses `::before` pseudo-elements for the hover effect.
- Maintain the `perspective-1000` on the Section 6 container for 3D depth.