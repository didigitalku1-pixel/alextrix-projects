---
version: 1.0.0
name: NovaLearn System
description: Dark-mode academic interface with glassmorphism and emerald accents.
colors:
  background: "#0a0a0a"
  surface: "#171717"
  surface-elevated: "#262626"
  primary: "#10b981"
  primary-hover: "#34d399"
  text-base: "#f5f5f5"
  text-muted: "#a3a3a3"
  text-dim: "#737373"
  border: "#262626"
  border-light: "#404040"
typography:
  sans:
    family: "Inter, system-ui, sans-serif"
    weights:
      regular: 400
      medium: 500
      semibold: 600
  headings:
    h1: { size: "30px", weight: 600, tracking: "-0.025em" }
    h2: { size: "24px", weight: 600, tracking: "-0.025em" }
  utility:
    label: { size: "11px", weight: 500, tracking: "0.2em", transform: "uppercase" }
    body-sm: { size: "14px", weight: 400, leading: "1.625" }
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "32px"
  container: "40px"
rounded:
  sm: "4px"
  md: "8px"
  lg: "16px"
  xl: "24px"
  full: "9999px"
components:
  cards:
    background: "linear-gradient(to bottom, #171717, #262626)"
    border: "1px solid #262626"
    shadow: "0 20px 25px -5px rgb(0 0 0 / 0.5)"
  buttons:
    primary: { bg: "#10b981", text: "#0a0a0a", rounded: "9999px" }
    ghost: { bg: "transparent", border: "#262626", text: "#a3a3a3" }
  status-bar:
    font-size: "11px"
    color: "#d4d4d4"
  avatars:
    size: "36px"
    overlap: "-8px"
motion:
  transition: "all 0.2s cubic-bezier(0.4, 0, 0.2, 1)"
  hover-scale: "1.02"
---
## Overview
NovaLearn is a sophisticated visual system tailored for educational technology. It utilizes a deep neutral palette to reduce eye strain during long study sessions, punctuated by vibrant Emerald-500 highlights to draw attention to critical calls-to-action and progress indicators.

## Colors
The palette is rooted in Neutral-950 for backgrounds, with Neutral-900 and 800 forming the basis of the layered card architecture. Emerald (#10b981) is the exclusive functional color for success, active states, and primary actions.

## Typography
Typography relies on a clean sans-serif stack. Information hierarchy is established through extreme tracking (0.15em to 0.22em) on uppercase labels and tight tracking on large headings to create a modern, editorial feel.

## Spacing
A rigorous grid system uses 16px (md) and 24px (lg) as the primary padding units for containers. Internal card sections are separated by consistent 16px or 24px gaps to maintain high readability.

## Layout
The system uses a three-column layout on desktop with overlapping floating cards.
- **Layering**: High z-index floating elements utilize backdrop-blur (12px) to signify priority.
- **Responsibility**: Mobile views collapse into a single-column vertical stack with 16px gutters.

## Elevation & Depth
Depth is achieved through:
- **Gradients**: Vertical linear gradients on cards (Neutral-900 to 800).
- **Shadows**: Large 2xl shadows for floating contextual cards.
- **Borders**: Sub-pixel 1px borders in Neutral-800 define edges in dark environments.

## Shapes
Rounded corners are generous, using 24px (3xl) for main containers and 32px or 35px for mobile-mimicry frames. Buttons and utility icons are almost exclusively circular (rounded-full).

## Components
- **Session Card**: Features a status bar, hero image with gradient overlay, and integrated play controls.
- **Assignment Strip**: Uses a dashed Emerald border and low-opacity background (10%) to signify a drop zone or upload task.
- **Floating Info-Cards**: 320px wide fixed-width cards used for instructors or project tracking, utilizing high z-index and backdrop filters.
- **Icon Groups**: Consistent 16px duotone icons for secondary actions.

## Motion
- **Transitions**: Smooth 200ms ease-in-out for hover states on buttons and links.
- **Feedback**: Focus-visible rings in Emerald-500/70 for keyboard accessibility.

## Do's and Don'ts
- **Do**: Use Emerald sparingly for interactive elements only.
- **Do**: Use uppercase tracking for section labels.
- **Don't**: Use solid white text; stick to Neutral-50 or 100 for primary content.
- **Don't**: Use sharp 90-degree corners; everything must be rounded.

## Accessibility
- Contrast ratios for text-to-background are maintained above 4.5:1.
- Interactive elements feature a 2px focus-visible outline in Emerald.
- Semantic tags (section, h1, h2, p) define the document structure for screen readers.