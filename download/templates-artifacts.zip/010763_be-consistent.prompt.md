Recreate the website "Sakura Enterprise SaaS Landing Page Template" with high visual fidelity as a Tailwind CSS and Vanilla JS site. Be extremely precise with the dark-mode aesthetic and the "electric" UI details.

Preserve source quirks:
- The navigation logo is a high-contrast Midjourney-generated image link instead of a vector logo.
- Inconsistent naming: The footer and copy refer to "Sakura", but the FAQ and some subtext use "TaskXen". Keep this as-is.
- The "Today" link in the application sidebar is the only one with an active background and ring-1 border.
- The layer stack in the application section uses nested 12-column grids with very specific relative/absolute overlaps.

CRITICAL FIDELITY CONSTRAINTS
- Background: Use `#050505` for the body. The starry effect is a CSS radial-gradient tile: `radial-gradient(1px 1px at 20px 30px, #fff, rgba(0,0,0,0))` repeated every 200px.
- Shadows: Use `0 0 30px rgba(59, 130, 246, 0.3)` for primary glowing cards.
- Typographic mix: Use 'Oswald' (light/thin) for large headings and 'Inter' for all UI and body copy.
- Animation: Use the explicit IntersectionObserver logic provided for `.animate-on-scroll` classes to trigger the `animationIn` keyframes.

TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN)
- Lucide Icons (CDN)
- Google Fonts (Inter, Oswald)
- UnicornStudio.js (v1.4.34) for background shader effects

GLOBAL STYLE
- Selection color: `bg-blue-500/30`.
- Custom scrollbar: Hidden on the main app showcase (`no-scrollbar`), but styled as a thin track for the Activity Feed.
- Border Radius: Cards use `32px` (rounded-2xl is not enough; use custom `rounded-[32px]`).

ASSET MAP
- Logo/Brand: https://cdn.midjourney.com/64c5a844-b86f-4916-88a1-6971a20f442f/0_0.png?w=800&q=80
- FAQ/Hero Video: https://cdn.midjourney.com/video/e3cb0796-45c4-4450-badd-35a5998be45a/0.mp4
- Avatars: Unsplash URLs for Jessica Wu (...8d80), Alex Thompson (...a43e), Emily Clark (...df2e), and others as listed in the inventory.

VECTOR / ICON SHAPES
- Use Lucide icons via `data-lucide` or direct SVGs.
- Special SVG: Use the exact `conic-gradient` path logic for the "Hub Core" beam animation (animating at 12s, reversed).
- The Noodle/Beam connections in Section 5 must use the exact `viewBox="0 0 1000 560"` and the cubic-bezier path strings provided in the source inventory.

LAYER STACK / POSITIONING MAP
- Fixed Layer: Stars and blur-circles (top-left blue-900/10, bottom-right blue-950/20) at z-index 0.
- Nav: Sticky top-4, max-w-6xl, z-50, backdrop-blur-xl.
- Hero: 12-column grid. Left (col-span-7) for text, Right (col-span-5) for the "Electric Card".
- App Showcase: Nested inside a -mt-4/-mt-8 container. Z-index layering: Glow background -> Outer ring/border -> Top bar -> 3-column app layout (Sidebar/Main/Activity).

SECTION 1 - NAVIGATION
- Sticky header with 10% white border. Navigation links are 'Inter' font. "Get Started" button: `bg-blue-600`, active scale-95.

SECTION 2 - HERO CONTENT
- Heading: 'Oswald' font, light, 76px desktop, 5xl mobile.
- Electric Card: Custom gradient border (`indigo-500` to `blue-600/10`). Task list includes a pulse animation on the "Live Schedule" badge and a progress bar at 85% width.

SECTION 3 - DESKTOP APP SHOWCASE
- Recreate the 3-pane dashboard.
- Left Sidebar: "New Task" button with blue gradient. Projects list with status dots (blue-400, purple-400, orange-400).
- Center Panel: Tabbed navigation (List, Board, etc.). Include the "Website Migration" progress card with the `85%` width blue-to-indigo gradient.
- Right Sidebar: "Online Members" list with status indicators (green for Alex, amber for Emily).
- Activity Feed: Vertical timeline line (11px left) with glowing colored dots.

SECTION 4 - FEATURES (WHY SAKURA)
- Use the numbered 01-04 grid layout.
- SVG Animation: Card 1 must include the `ripple-expand` animation (4s cycle). Card 2 must have the `flowData` path animation using `stroke-dashoffset` from 120 to 0.

SECTION 5 - OUR APPROACH (THE HUB)
- This is a complex visual section. Use a single SVG overlay (`1000x560`) for the "Animated Noodles".
- Paths must animate with a `linearGradient` using the `noodleGradient` ID.
- Center Hub: A rotating conic-gradient beam around a bolt icon.

SECTION 6 - TESTIMONIALS
- JS Requirement: Implement the batch-rotation script. Every 5 seconds, fade out the 4 cards and update with the next 4 items from the `testimonials` array in the inventory. Smoothly transition opacity from 0 to 100.

SECTION 7 - FAQ
- Use a grid layout: Left for the video container (aspect-4/5), Right for the accordion.
- Accordion Logic: Use `grid-template-rows` [0fr] to [1fr] for the transition instead of simple `display:none` to ensure smooth sliding.

GLOBAL ANIMATION / INTERACTION RULES
- All `animate-on-scroll` elements must use the `animationIn` keyframes with a 0.8s duration.
- Buttons with `group-hover:translate-x-[100%]` must have a `white/20` gradient shine effect.
- The large footer "Sakura" background text must be at `17vw` with a `gradient-to-t` from white to transparent.

IMPLEMENTATION REQUIREMENTS
- Build exactly as described. Do not simplify the SVG paths or the absolute positioning used in the dashboard view.
- Maintain the specific font spacing and uppercase letter-spacing on small labels.
- Preserve the exact asset URLs provided.