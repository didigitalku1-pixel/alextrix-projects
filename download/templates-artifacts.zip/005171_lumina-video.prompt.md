Recreate the website "Lumina - Creative Suite" with high visual fidelity as a Tailwind CSS/HTML site. The result must match the supplied reference landing page exactly, preserving its dark-themed, cinematic aesthetic with orange highlights.

Preserve source quirks:
- Custom 3D transform utilities via Tailwind config for perspective and rotation.
- Non-standard scrollbar (hidden).
- Specific animation delays for "falling beams" (0s, 1.5s, 2s, 4s).
- Mix-blend-mode "luminosity" on background imagery.
- Inconsistent uppercase/lowercase in headings (e.g., "HELLO@LUMINA.AI" vs "Get In Touch").

CRITICAL FIDELITY CONSTRAINTS
- Background Layering: Must use a fixed background image with mix-blend-luminosity (opacity 40%) overlaid by a specific three-part gradient stack (top-down, radial orange, and page-specific black).
- Vertical Grid: Exactly 5 columns separated by border-white/5, with specific column IDs (01-05).
- Interaction: The "Stacked Cards" preview in the hero must be interactive via the "activateStep" JS function, shifting z-index, opacity, and scale transforms.

TECH STACK / DEPENDENCIES
- CSS: Tailwind CSS (cdn.tailwindcss.com).
- Icons: Lucide (unpkg.com/lucide@latest).
- Fonts: 'Inter' (300-700) and 'Instrument Serif' (400-700) via Google Fonts.
- Animations: Custom CSS keyframes for `beam-fall`, `floating-points` (particles), and `fadeSlideIn` (on-scroll entries).

GLOBAL STYLE
- Background: #050505.
- Selection color: orange-500/30.
- Typography: Primary font is Inter; Headings use Instrument Serif for stylistic weight.

ASSET MAP
- Hero Background: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/2b5079f4-4ddd-433b-a936-fc8f7dea9df0_3840w.webp
- Card 1: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/2b5079f4-4ddd-433b-a936-fc8f7dea9df0_800w.webp
- Card 2: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/6e8af32c-e155-4b33-9e0a-eb91a91debbe_800w.webp
- Card 3: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/c3337c33-82ae-4ad6-9c83-f9f1a5bdc53c_800w.webp
- Testimonials: i.pravatar.cc/100?img=12, i.pravatar.cc/100?img=32
- Footer Texture: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/4c087a1e-aa65-42f7-9a89-dc582f5d807a_3840w.webp
- Noise: https://grainy-gradients.vercel.app/noise.svg

VECTOR / ICON SHAPES
- Use exact Lucide icons: `video`, `scan-line`, `download`, `quote`, `sparkles`, `zap`, `play`, `arrow-right`, `check`.
- Custom SVG Paths (About Us Zap): M22 12c0 5.523-4.477 10-10 10S2 17.523 2 12S6.477 2 12 2s10 4.477 10 10.

LAYER STACK / POSITIONING MAP
1. BASE: Body #050505.
2. BG FIXED: Fixed <img> (z-0) + Overlay Gradients.
3. BEAMS: Fixed flex grid (z-0) with relative overflow-hidden children containing `animate-beam` divs.
4. CONTENT: Relative flex-1 container (max-w-7xl).
5. NAV: Sticky/Static top (z-10).
6. HERO: Grid lg:cols-12. Left: text. Right: perspective-1000 stack container.
7. OVERLAY (Phone): Absolute notch area (z-50), status bar (z-40), sticky app header (z-30).

SECTION 1 - NAVBAR
- Logo: Orange-to-amber gradient circle with nested black dot.
- Links: Workflow, Resources, Pricing (uppercase tracking-widest).
- Button: "Get Access" using `.button-custom` CSS with radial-gradient, inner particles (`.point`), and pseudo-element borders.

SECTION 2 - HERO
- Heading: "Craft Visual Stories." with gradient span (white to neutral-500).
- CTA Button: Conic-gradient rotating aura beam (`animate-spin`) behind a backdrop-blur rounded mask.
- Card Stack: 3 cards. Active card (z-30) scale 1; Card 2 (z-20) scale 0.95 translateY(12px); Card 3 (z-10) scale 0.9 translateY(24px).
- Interactive List: Step 1-3. Each has a `click` event listener that triggers `updateCardStack` and toggles Tailwind classes for active state (bg-white/5, text-white).

SECTION 3 - SOCIAL PROOF
- Orange Testimonial Card: bg-gradient-to-b (orange-400 to 600), black text, quote icon, avatar stack.
- Headline: "Next generation creative suite." using white/60 opacity for secondary text.

SECTION 4 - ABOUT / STATS
- About Badge: Rounded-full bg-white/5, border-white/10, backdrop-blur-sm.
- Typographic Wall: text-white/40 with specific inline spans as pure white.
- Stats Grid: 4 columns ($500M, 99%, 2M+, 4.9). text-light, tracking-tighter.
- Logo Cloud: Monotone SVGs (Vercel, Stripe, Adobe, Acme) with `grayscale opacity-60` class.

SECTION 5 - MOBILE SHOWCASE
- Mockup: w-[340px] h-[680px], rotate[-2deg].
- Features: Internal "Instagram-style" stories area with gradient ring avatars. Feed post with 12,453 likes and Lumina_official branding.

SECTION 6 - CASE STUDIES
- Table-style layout. Hover triggers `bg-white/[0.02]`.
- Expanded Row (Productivity): Shows Challenge, Solution, Result sub-grid with vertical alignment lines.

SECTION 7 - CONTACT / FOOTER
- Links: Privacy & Policy, Terms of Service (text-neutral-500).
- Giant Text: "LUMINA" in text-[17vw] tracking-tighter with `mix-blend-overlay` and `opacity-90`.
- Large Contact: Phone and Email using `tracking-tighter` and `group-hover/item:text-transparent bg-clip-text`.

GLOBAL ANIMATION / INTERACTION RULES
- Scroll Observer: Use `IntersectionObserver` to add `.animate` class to `.animate-on-scroll` elements when 15% in view.
- CSS Keyframes: `fadeSlideIn` must involve translateY(30px) and filter: blur(8px).
- Particles: `floating-points` animation for button interior.

COMMON MISTAKES TO AVOID
- Do not use generic orange; use #ea580c and specific amber/orange variants from the asset map.
- Do not miss the conic-gradient rotation in the hero CTA.
- Do not substitute Lucide icons with others.
- Ensure the z-index of the falling beams does not overlap interactive buttons.