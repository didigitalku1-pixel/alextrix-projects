---
version: 1.0.0
name: Gemini 3 Slides System
description: A specialized dark-mode design system for interactive horizontal storytelling with high-contrast typography and motion-heavy component patterns.
colors:
  background: "#000000"
  surface: "#0A0A0A"
  surface-elevated: "#171717"
  primary: "#FFFFFF"
  secondary: "#A3A3A3"
  accent: "#F97316"
  border: "rgba(255, 255, 255, 0.1)"
  glass: "rgba(255, 255, 255, 0.05)"
typography:
  display:
    family: "Space Grotesk"
    weight: "700"
    tracking: "-0.05em"
  body:
    family: "Geist"
    weight: "400"
    lineHeight: "1.6"
  mono:
    family: "Space Mono"
    weight: "400"
    tracking: "0.1em"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "40px"
  xxl: "64px"
rounded:
  sm: "2px"
  md: "8px"
  lg: "16px"
  full: "9999px"
components:
  nav:
    position: "fixed"
    blur: "12px"
    height: "64px"
  slide-card:
    aspectRatio: "3/4"
    width-desktop: "500px"
    width-mobile: "85vw"
    border: "1px solid border"
  button-pill:
    rounded: "9999px"
    padding: "10px 24px"
    textTransform: "uppercase"
  prompt-box:
    background: "rgba(23, 23, 23, 0.5)"
    border-left: "2px solid accent"
    padding: "16px"
motion:
  intro: "animationIn 0.8s ease-out"
  marquee: "marquee 20s linear infinite"
  clip: "clip-reveal 1.5s cubic-bezier(0.77, 0, 0.175, 1)"
  beam: "spin 3s linear infinite"
---
## Overview
The system is built for a "Swipe-to-Reveal" narrative. It prioritizes dark-mode aesthetics, using deep blacks (`#000000`) and subtle card backgrounds (`#0A0A0A`) to make primary white text and high-saturation accents pop.

## Colors
The palette is monochromatic with a singular functional accent.
- **Deep Space**: Primary background using absolute black.
- **Neutral High**: Pure white for headings and high-contrast UI.
- **Neutral Mid**: Zinc/Neutral 400-500 for secondary metadata and mono labels.
- **Solar Flare**: Orange-500 used sparingly for highlights and active prompts.

## Typography
- **Headings**: Space Grotesk with tight tracking and leading (`0.9`).
- **Interface**: Geist (Sans) for navigation and status labels.
- **Technical**: Space Mono for metadata, versioning, and prompt descriptions.

## Spacing
Based on an 8px grid. Slides use `40px` (xl) internal padding on desktop and `24px` (lg) on mobile to maintain breathable content zones.

## Layout
- **Horizontal Scroll**: A snap-mandatory flex container with `overflow-x-auto`.
- **Masking**: The slider uses a `90deg` linear-gradient mask to fade out edges of the scroll area.
- **Layering**: Navigation is `z-50`, floating above the `z-10` content slides.

## Elevation & Depth
- **Card Shadows**: Large `shadow-2xl` used to separate black cards from the black background.
- **Glassmorphism**: Internal components use `backdrop-blur-md` and `rgba` white borders for perceived depth.
- **Stacking**: 3D card stacks use `z-index` manipulation combined with `scale` and `blur` to simulate distance.

## Shapes
- **Containers**: Slides use a consistent `1px` border with `16px` (lg) or `8px` (md) rounding.
- **Controls**: Pagination dots and navigation buttons are strictly circular.
- **Input**: Prompt boxes use sharp `2px` left-borders for a code-editor feel.

## Components
- **The Slider**: A central horizontal viewport using CSS snap-points.
- **Pagination**: Minimalist dots with scale-transform on hover and active-state color transitions.
- **Border Beam Button**: A pill button utilizing a conic-gradient overlay and `overflow-hidden` to simulate a moving light beam.
- **Infinite Marquee**: A non-stop horizontal loop for logo-clouds with alpha-masking on edges.

## Motion
- **Visibility Trigger**: The `animate-on-scroll` class uses an IntersectionObserver to play `animationIn` (translateY + blur-in).
- **Stack Rotation**: CSS Keyframes (`cardStackCycle`) handle 3-layer card transitions.
- **Clip Reveals**: Background shapes and text utilize `clip-path` for modern entrance effects.

## Do's and Don'ts
- **Do**: Use `mix-blend-mode: color-dodge` for background textures.
- **Do**: Apply `font-mono` to all numbers and system labels.
- **Don't**: Use standard scrollbars; always use the `hide-scrollbar` utility.
- **Don't**: Exceed 2-3 lines of text in the prompt-box component.

## Accessibility
- **Aria-Labels**: Ensure navigation buttons have descriptive labels for screen readers.
- **Contrast**: Maintain a 4.5:1 ratio even on secondary mono text.
- **Reduced Motion**: Respect system preferences by wrapping complex keyframes in `@media (prefers-reduced-motion: no-preference)`.