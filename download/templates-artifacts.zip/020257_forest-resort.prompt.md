Recreate the website "Aetheria | Forest Sanctuary" with high visual fidelity as a Tailwind CSS-based landing page. The result must match the supplied reference exactly, including its specific typography, dark-minimalist aesthetic, and scroll-triggered animations.

Preserve source quirks:
- The Hero section has a height of 110vh (purposely taller than the viewport).
- The main heading uses a negative margin or tight leading (0.9) and combines uppercase words with a lowercase "to".
- The logo text "Aetheria." includes a trailing period.
- Social icons in the footer use a subtle 5% white background circle.

CRITICAL FIDELITY CONSTRAINTS
- Use only the provided fonts: Oswald for headings/branding, Playfair Display for specific serif accents, and Instrument Sans for body text.
- Implement the "Progressive Blur" header overlay exactly as defined in the CSS (multiple stacked divs with incrementing blur and mask-gradients).
- Match the stone-based color palette: bg-stone-50 (light sections), bg-stone-900 (hero/dark sections), and bg-stone-950 (footer).
- Maintain the .animate-on-scroll logic: elements start at opacity 0, translateY(30px), and blur(8px) before animating into place.

TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN)
- Iconify (CDN: https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js)
- Google Fonts (Instrument Sans, Playfair Display, Oswald)
- Intersection Observer for scroll animations.

GLOBAL STYLE
- Body: font-family: 'Instrument Sans', antialiased, selection:bg-stone-800 selection:text-white.
- Glass effect: background: rgba(255, 255, 255, 0.05), backdrop-filter: blur(10px).
- Dark Glass: background: rgba(0, 0, 0, 0.3), backdrop-filter: blur(12px).

ASSET MAP
- Hero BG: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/57356633-8b8e-481d-84eb-9b43ea8306e1_1600w.jpg
- Floating Card Image: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/309407a0-e40c-4d1d-b1f9-bf12967acf91_800w.jpg
- About Section Main: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/5afdad6c-7e1b-4657-b1dd-dfce19941dbf_1600w.jpg
- About Section Inset: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/03036a3c-54ad-4e0d-acc3-f208870cc961_800w.webp
- Stargazer Suite: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/02ec3fdf-4f8c-4433-b2c6-9793000d7100_1600w.webp
- Forest Spa: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/a3489106-d494-4dba-8d00-0a075d1b1f67_1600w.webp
- Wild Dining: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/6d06adc6-da59-4b96-80c3-e385d919c51b_1600w.webp

LAYER STACK / POSITIONING MAP
- NAVIGATION: Fixed top-0, z-index 50. Contains glass-style button.
- PROGRESSIVE BLUR: Fixed top-0, z-index 5. 12% height. Stack of 6 divs with mask-gradients for smooth blur transition.
- HERO: Relative, 110vh. Stacking: BG Image (z-0) < Gradient Overlay (z-0) < Floating Card (absolute, z-10) < Text Content (absolute bottom-32, z-20).

SECTION 1 - HERO
- Background: stone-900. Image has scale-105 and a 10s ease-in-out pulse animation.
- Floating Card: absolute top-[25%] left-[10%], glass-dark style. Features a play button overlay on a group-hover scale image.
- Headline: font-oswald, 9xl (desktop), "DISCONNECT" above "to RECONNECT".
- Buttons: Primary (bg-white text-stone-900), Secondary (glass).

SECTION 2 - TRUSTED BY
- Bg: white. Text: "Preferred retreat for visionaries from" (tracking-widest).
- Logos: SpaceX, Tesla, Uber, NASA, Apple, Notion (grayscale, 60% opacity, transition to full color on hover).

SECTION 3 - ROOTED IN NATURE
- Grid: 2-column. Left: oswald headings, leaf icon (solar:leaf-bold-duotone), text features with left border (stone-200).
- Right: Image composition. Large image (top right) with a smaller overlap image (bottom left, 8px white border). Green pulsing "Now Booking" badge.

SECTION 4 - FEATURED SUITES
- Bg: stone-900. Centered header.
- Main Card: 80vh height, rounded-2rem. Stargazer Suite text in oswald 8xl. Floating heart badge in top-right.
- Sub-grid: Two 400px height cards for "The Forest Spa" and "Wild Dining". White line (h-0.5) expands from w-0 on hover.

SECTION 5 - FOOTER
- Bg: stone-950. 4-column layout (Brand, Resort Links, Experiences Links, Newsletter).
- Newsletter: Input (bg-white/5) + Join button (bg-white text-stone-950).

GLOBAL ANIMATION / INTERACTION RULES
- All sections contain elements with `.animate-on-scroll`. Use an IntersectionObserver to add an `.animate` class that sets `animation-play-state: running` for the `animationIn` keyframe (0.8s ease-out).
- Image hover states: Most images should scale 1.05x or 1.1x with a transition-duration of 700ms-1000ms.

IMPLEMENTATION REQUIREMENTS
- Preserve the exact font families and CSS blur masks for the header.
- Use the exact SVG icons from the solar: and simple-icons: sets via Iconify.
- Ensure the 110vh height and specific grid spans (lg:col-span-8, etc.) are respected for the intended composition.