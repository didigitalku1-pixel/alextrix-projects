Recreate the website "3D Globe Card" with high visual fidelity as a Tailwind CSS and Vanilla JavaScript site.

The result must match the supplied reference website, not a cleaned-up reinterpretation.

Preserve source quirks:
- The globe uses an internal resolution of 1000x1000 pixels while being constrained to a 256px (h-64) high container.
- The animation uses a raw incrementing variable (phi) rather than a time-based delta.
- The card utilizes a combination of `bg-white/10` and `bg-black/40` which creates a distinct tiered transparency look.

CRITICAL FIDELITY CONSTRAINTS
- The 3D globe must be rendered using the `cobe` library via Skypack.
- The canvas must have exactly `width="1000"` and `height="1000"` attributes but styled with `width: 100%; height: 100%`.
- No additional interactive controls (zoom/drag) should be added as the source only uses auto-rotation.
- The text color transparency must match exactly (white/70, white/80, white/60).

TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN: https://cdn.tailwindcss.com)
- Cobe 3D Globe Library (Import: https://cdn.skypack.dev/cobe)
- Standard ES Modules for script execution.

GLOBAL STYLE
- Body: `bg-gray-900`, `min-h-screen`, `flex`, `items-center`, `justify-center`, `p-4`.
- Font: Default sans-serif.
- Colors: Deep gray background with white/translucent card elements.

ASSET MAP
- Script 1: `https://cdn.tailwindcss.com` (Layout/Styles)
- Script 2: `https://cdn.skypack.dev/cobe` (Globe rendering engine)

VECTOR / ICON SHAPES
- Status Indicators: Pure CSS circles using `w-3 h-3 rounded-full`. Colors: `bg-pink-500` (Main Hub) and `bg-blue-400` (Regional Office).

MEDIA BEHAVIOR
- Canvas Rendering:
  - `devicePixelRatio`: 2
  - `dark`: 1
  - `diffuse`: 1.2
  - `scale`: 1.1
  - `mapSamples`: 16000
  - `mapBrightness`: 6
  - `baseColor`: [0.3, 0.3, 0.6]
  - `markerColor`: [1, 0.5, 1]
  - `glowColor`: [0.7, 0.7, 1]
  - `phi` increment: 0.003 per frame.

LAYER STACK / POSITIONING MAP
- **Root Container**: Flex center.
- **Card (max-w-md)**: `relative`, `bg-white/10`, `backdrop-blur-xl`, `rounded-2xl`, `overflow-hidden`, `shadow-2xl`, `border border-white/20`.
- **Globe Layer (h-64)**:
  - Canvas: `absolute inset-0`, `z-0`.
  - Top Header: `absolute top-3 left-4 z-10`.
  - Bottom Legend: `absolute bottom-3 right-4 z-10`, `bg-black/30`, `backdrop-blur-md`.
- **Info Panel**: `p-5`, `bg-black/40` (below the globe container).

SECTION 1 - GLOBE DISPLAY
- **Canvas**: ID `cobe`. Positioned to fill the relative container.
- **Header Text**: "Global Network" (text-2xl, font-bold, white), subtitle "Interactive 3D visualization" (text-white/70, text-sm).
- **Legend**: Floating box with two items: "Main Hub" (Pink dot) and "Regional Office" (Blue dot). Flex layout with `space-x-3`.

SECTION 2 - LOCATION DETAILS
- **Location Row**: Flex-justify-between. Left: "San Francisco" (font-medium), "Headquarters" (text-xs, white/60). Right: "New York" (font-medium), "East Coast Office" (text-xs, white/60).
- **Description**: Border-t (white/10) separator. Text: "Our global presence spans key strategic locations, enabling us to serve clients worldwide with localized expertise and 24/7 support capabilities." (text-white/70, text-sm).

GLOBAL ANIMATION / INTERACTION RULES
- **Globe Rotation**: Continuous Y-axis (phi) rotation at 0.003 units per frame via `onRender` callback.
- **Globe Markers**: 4 specific locations:
  1. [37.7595, -122.4367] (size 0.06)
  2. [40.7128, -74.006] (size 0.03)
  3. [51.5074, -0.1278] (size 0.03)
  4. [35.6762, 139.6503] (size 0.03)

COMMON MISTAKES TO AVOID
- Do not use a standard image for the globe; it must be the live WebGL canvas.
- Do not forget the `backdrop-blur-xl` on the main card and `backdrop-blur-md` on the legend.
- Ensure the canvas size attributes (1000x1000) match the JS configuration exactly to prevent distortion.
- Do not omit the `overflow-hidden` on the card; otherwise, the canvas may bleed over rounded corners.

IMPLEMENTATION REQUIREMENTS
- Build the actual landing page as the first screen.
- Use the exact text, assets, and section order provided.
- Preserve layer order and stacking contexts exactly. Use explicit CSS for absolute layers.
- Final page should feel indistinguishable from the source HTML.