Recreate the website "NovaLearn Session Overview" with high visual fidelity using Tailwind CSS and the Solar icon set.

The result must match the supplied reference website exactly, including the specific three-column layout on desktop and the overlapping floating cards.

Preserve source quirks:
- The session status bar uses a hardcoded time "09:42".
- Some icons are duotone with specific 0.5 opacity paths.
- The central card uses a nested border-radius strategy (outer container 2.2rem, inner hero image 1.8rem).

CRITICAL FIDELITY CONSTRAINTS
- Background must be a fixed, saturated, blurred element with a linear-gradient mask (top/bottom transparency, black center).
- All interactive elements must include the specific emerald-500/70 or /80 focus-visible outline.
- Exact spacing for tracking (letter-spacing) on uppercase labels (0.16em to 0.22em) is mandatory.
- Floating cards (Project Tracks, Schedule, Instructor) must be hidden on mobile and positioned using absolute transforms on desktop as specified in the layer map.

TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN)
- Iconify (Solar set: `iconify--solar`)
- UnicornStudio.js (v1.4.29) for background effects
- Fonts: Default Sans (Inter-like) with tight tracking.

ASSET MAP
- Attendee 1: https://images.unsplash.com/photo-1525134479668-1bee5c7c6845?auto=format&fit=crop&w=200&q=80
- Attendee 2: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/dbf5085e-0341-4243-aa8f-73a531c46290_320w.webp
- Attendee 3: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/e57b7081-23fd-4dd7-981e-59fc4fda47dc_320w.webp
- Hero Image (Center): https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/89c17836-ca19-4c7c-9bb2-b8a36b6a0bde_800w.webp
- Instructor Portrait: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/aa213242-cfaa-4e7a-8277-f98114018a97_320w.webp

VECTOR / ICON SHAPES
- Use `solar:alt-arrow-left-bold-duotone` (Back button)
- Use `solar:settings-bold-duotone` (Settings gear)
- Use `solar:user-plus-bold-duotone` (Invite button)
- Use `solar:cloud-upload-bold-duotone` (Upload button)
- Use `solar:wifi-bold-duotone` (Status bar)
- Use `solar:menu-dots-bold-duotone` (Hero menu)
- Use `solar:play-bold-duotone` (Join button)
- Use `solar:phone-calling-rounded-bold-duotone` (Call button)
- Use `solar:widget-3-bold-duotone` (Grid button)
- Use `solar:star-bold-duotone` (Star icon)
- Use `solar:arrow-up-right-bold-duotone` (Enroll button)

LAYER STACK / POSITIONING MAP
- BODY: `bg-neutral-950`, flex center.
- BACKGROUND LAYER (z-10): Fixed, h-screen, `blur-sm`, `saturate-200`. Mask: `linear-gradient(to bottom, transparent, black 0%, black 80%, transparent)`.
- MAIN WRAPPER: `max-w-6xl`, `flex-col md:flex-row`, gap-16.
- SECTION 1 (Left): `flex-1`, `bg-gradient-to-b from-neutral-900 to-neutral-800`, `rounded-3xl`.
- SECTION 2 (Center): `max-w-md`, `bg-neutral-900`, `rounded-[2.2rem]`, `z-10` relative to others.
- SECTION 3 (Right): `flex-1`, `bg-gradient-to-b from-neutral-900 to-neutral-950`, `rounded-3xl`.
- FLOATING PROJECT CARD: Absolute bottom-0 left-0, `translate-x-[-3rem]`, `translate-y-[60%]`, `z-20`.
- FLOATING SCHEDULE CARD: Absolute bottom-0 left-1/2, `-translate-x-1/2`, `translate-y-[60%]`, `z-20`.
- FLOATING INSTRUCTOR CARD: Absolute bottom-0 right-0, `translate-x-[2rem]`, `translate-y-[40%]`, `z-20`.

SECTION 1 - EVENT DETAILS
- Header: Back button (left), Settings button (right).
- Title: "Collaborative Stats Workshop" (text-3xl).
- Info Grid: 3-column grid (Time, Location, Track) with uppercase labels and emerald-400 "Event" tag.
- Social: Overlapping avatar group + Emerald User-Plus button.
- Assignment Box: Dashed emerald border, gradient background, "Upload" button.

SECTION 2 - SESSION LIVE VIEW
- Status Bar: "09:42" and Wifi icon.
- Hero: Image with `object-cover` and black gradient overlay. Contains "48,210 learners synced" text.
- Action Bar: Large Emerald Play button, followed by two rounded-full neutral-800 buttons.
- Meta Grid: 3-column grid (Level, Length, Credits) with tracking-widest labels.

SECTION 3 - COURSE OVERVIEW
- Header: "Catalog" back button + Star button.
- Content: Lead text about "geometry and statistical modeling" (leading-relaxed).
- Schedule: Vertical list with Lesson 01-03, using thin neutral-800/70 separators.

FLOATING OVERLAYS (DESKTOP ONLY)
- Project Tracks: `bg-neutral-900/95`, backdrop-blur, containing two task rows with progress percentages.
- Schedule Card: Horizontal layout with "Wednesday, Mar 7th" and "Reserve seat" button.
- Instructor Card: Profile image (h-16), bio, stats grid (Courses, Projects, Rating), and full-width Enroll button.

IMPLEMENTATION REQUIREMENTS
- Use `backdrop-blur` on all floating cards.
- Ensure all text uses `font-sans` with `tracking-tight` on headings.
- Background script for UnicornStudio must be initialized exactly as in source.
- Do not substitute images or icons; use the exact URLs and Solar IDs provided.
- Final page must match the exact stacking order where cards overlap the main section borders.