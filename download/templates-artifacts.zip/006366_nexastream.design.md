---
version: 2.0.0
name: Nexastream
description: A premium dark-mode visual system using deep zinc shades, vibrant sky-blue accents, and complex SVG-driven animations.

colors:
  background:
    primary: "#020408"
    secondary: "#09090b"
    accent: "#0c0c0e"
  surface:
    glass: "rgba(255, 255, 255, 0.1)"
    card: "rgba(24, 24, 27, 0.9)"
    border: "rgba(255, 255, 255, 0.1)"
  accent:
    primary: "#0ea5e9"
    secondary: "#3b82f6"
    glow: "rgba(14, 165, 233, 0.4)"
  text:
    primary: "#ffffff"
    secondary: "#a1a1aa"
    muted: "#71717a"

typography:
  fontFamily:
    sans: "'Inter', sans-serif"
    serif: "'Newsreader', serif"
    mono: "ui-monospace, monospace"
  sizes:
    hero: { size: "8rem", lineHeight: "0.9", weight: "400" }
    sectionTitle: { size: "3.75rem", lineHeight: "1.0", weight: "400" }
    body: { size: "1.125rem", lineHeight: "1.75", weight: "300" }
    label: { size: "0.75rem", lineHeight: "1", weight: "600" }

spacing:
  xs: "4px"
  sm: "12px"
  md: "24px"
  lg: "48px"
  xl: "128px"

rounded:
  sm: "4px"
  md: "12px"
  lg: "24px"
  full: "9999px"

components:
  nav:
    style: "Floating pill with backdrop blur"
    position: "relative-z-50"
  hero:
    layout: "Split text/visualization stack"
    decoration: "Background grid lines and SVG flow paths"
  buttons:
    primary: "Conic gradient border with black background and white text"
    secondary: "Solid blue-to-indigo gradient with high-shadow presence"
  cards:
    standard: "Zinc-900 surface with subtle border and floating motion"
    preview: "Browser-chrome headers with internal code/graph snippets"
  badges:
    pulse: "Sky-blue text with animated status dot and outer glow"

motion:
  float: "6s ease-in-out infinite floating translation"
  beam: "10s dash-flow animation for SVG paths"
  gradient: "Subtle transition on hover for border gradients"
---
## Overview
Nexastream is defined by a 'Dark Cloud' aesthetic—combining technical precision with fluid, organic motions. It utilizes a predominantly black/zinc palette to allow vibrant sky-blue data visualizations and emerald status indicators to stand out.

## Colors
The system relies on `Zinc` scales (900-950) for depth. The primary brand color is `Sky-500`, often used in linear gradients toward `Blue-600`. Functional colors include `Emerald-500` for live status and `Orange-500` for ingestion labels.

## Typography
- **Primary Heading**: Newsreader Serif with italicized accent spans.
- **Interface Text**: Inter Sans for readability at small scales.
- **Data/Code**: Monospace fonts used for payload previews and latency labels.

## Spacing
A generous 8pt grid system. Hero sections use `128px` (32 units) of padding, while interactive components use `12px` (3 units) for internal grouping.

## Layout
- **Containment**: Large outer container with `2.5rem` rounded corners and a thin `white/10` border.
- **Background**: Vertical grid lines spaced across the viewport to provide structure.
- **Z-Index Layering**: Background (Grid) -> Midground (SVG Flows) -> Foreground (Floating UI Cards) -> Navigation.

## Elevation & Depth
Depth is achieved through `backdrop-blur-xl` and nested shadows. Floating cards use `shadow-black/50` with high blur radii to simulate hovering over the data highways.

## Shapes
Components are heavily rounded. Primary containers use large `24px-40px` radii, while buttons and navigation items are fully elliptical (`rounded-full`).

## Components
- **Interactive Node Cards**: Feature a numbering system (01, 02, 03) and specific Lucide icons corresponding to data actions.
- **Workflow Connectors**: Dotted vertical lines and animated SVG beams connecting various state cards.
- **Integration Grid**: Greyscale logos with hover-to-color transitions.

## Motion
- **The Beam**: Use `stroke-dasharray` and `animate-dash-flow` to simulate data packets moving through paths.
- **Subtle Float**: Hero cards use a `translateY` loop to feel light and reactive.
- **Pulse**: Status indicators use a 2s opacity loop.

## Do's and Don'ts
- **Do**: Use italics within serif headers for emphasis.
- **Do**: Apply `backdrop-blur` to any element overlapping the background visualization.
- **Don't**: Use solid bright backgrounds; all surfaces should be semi-transparent or dark zinc.
- **Don't**: Use sharp corners on interactive elements.

## Accessibility
- Use `antialiased` font rendering for all text on dark backgrounds.
- Maintain high contrast for primary labels (White on Zinc-900).
- Ensure animated paths do not move at frequencies that cause vestibular distress.