Recreate the website "Creative Platform" with high visual fidelity as a Tailwind CSS and Vanilla JavaScript site.

The result must match the supplied reference website, not a cleaned-up reinterpretation.

Preserve source quirks:
- Double-wrapped Intersection Observer logic (present in source).
- Explicit `.animate-on-scroll` classes that default to `paused` state via injected CSS.
- Redundant inline styles for the Inter font family on the body tag.
- Usage of specific UnicornStudio script for background effects.

CRITICAL FIDELITY CONSTRAINTS
- Background must use the specific multi-layer radial gradient aura fixed to the inset-0.
- Nav buttons use a custom `.border-gradient` class using a `::before` pseudo-element with `-webkit-mask-composite` for the stroke effect.
- The "Get started today" button contains a complex inner stack of 5 absolute span layers for gradients, glows, and sheen.
- Asset fidelity: Use exact Supabase storage URLs provided in the ASSET MAP.

TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN)
- Lucide Icons (https://unpkg.com/lucide@latest/dist/umd/lucide.js)
- Chart.js (https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js)
- Unicorn Studio (https://cdn.jsdelivr.net/gh/hiunicornstudio/unicornstudio.js@v1.4.29/dist/unicornStudio.umd.js)
- Google Fonts: Inter (300, 400, 500, 600, 700)

GLOBAL STYLE
- Colors: Background `#000000`, Text `#f5f5f5` (neutral-100).
- Typography: `font-family: Inter, ui-sans-serif, system-ui;`.
- Keyframes: `fadeSlideIn` (opacity 0 -> 1, transform translateY 30px -> 0, blur 8px -> 0).

ASSET MAP
- Logo: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/5e2bb527-bd5b-49c0-ab02-6df2869bcd3a_1600w.png`
- Hero Cards (0-5):
  - Card 0: `.../3d5923b9-321c-4e35-ac04-0d7fb5c483b1_320w.webp`
  - Card 1: `.../c5fb864f-cf3d-4942-9629-249d52477022_800w.webp`
  - Card 2: `.../58cdb928-9435-44fa-b69e-7acebfffa0f7_800w.webp`
  - Card 3: `.../3c4f1dea-f838-465a-bfd2-8fbbf334a6bc_320w.webp`
  - Card 4: `.../773cd99d-a5ac-4c9a-b312-b9b3e3a42002_800w.webp`
  - Card 5: `.../97837bc2-4cb4-44a3-8f15-444c524bd4c0_800w.webp`
- Community Marquee: 16 unique headshots (Indices `2f563338` through `7063bc06`). Use original URLs.

VECTOR / ICON SHAPES
- Use Lucide for `user`, `menu`, `arrow-up-right`, `external-link`.
- Custom SVG paths for "Discovery" section icons (Shield/Protect, Grid, Plus/Cross, Waveform, Diamond).

MEDIA BEHAVIOR
- Background: Unicorn Studio script initializes project `ILgOO23w4wEyPQOKyLO4`.
- Hero Image Cards: Hover `scale-105` with `transition-all duration-700`.
- Community Marquee: `@keyframes marquee-left` animating `translateX(0)` to `translateX(-50%)` over 80s.

LAYER STACK / POSITIONING MAP
- Fixed Nav: z-index 50.
- Fixed Gradient Blur Overlay: z-index 5, top 0, height 20%, 8 layers of nested blur (0.5px to 64px).
- Background Aura: z-index -10, fixed inset-0, opacity 60%.
- Hero Cards: Relative grid, z-index 1 (inactive) to 10 (active/focused).

SECTION 1 - NAVIGATION
- Logo is 100x40 container with `bg-cover`.
- Links: Features, Start Creating, Plans, Support.
- Profile button (hidden sm) and Menu button (always visible).

SECTION 2 - HERO
- Headline: "Showcase your work to the world." (Gradient text on "the world").
- Tag Badges: Absolute positioned "designer" (blue, left 12%) and "artist" (orange, right 10%) with 45-deg rotation arrow tails.
- Card Rail: 6-column grid, cards have varying rotations (-8, -2, 3, 0, -2, 6 degrees) and Y-translations.
- Interactive logic: Click card to blur/dim siblings and center target card with `scale(1.15)`.

SECTION 3 - HOW WE WORK
- Card 1 (Phase 1): Contains a Live Chart.js Radar chart (System, Process, Speed, Manual, Repetition) with purple gradient fill and 5 checklist rows.
- Card 2 (Phase 2): Code preview with `workflow_engine.py` (Python syntax highlighting colors: `#a855f7`, `#7dd3fc`, `#6ee7b7`).

SECTION 4 - COMMUNITY MARQUEE
- Headline: "Join 50,000+ creative professionals..."
- Marquee: Masked on edges via `linear-gradient` to transparent. Dual-row flexbox with infinite scroll.

SECTION 5 - TESTIMONIALS
- 4-card grid (lg:2cols).
- Design: `radial-gradient` background (purple 18% opacity) at bottom-right of cards.
- Rating: 5 stars in `#fbbf24` (amber-400).

SECTION 6 - PRICING
- 3 plans: Starter, Pro (Featured), Enterprise.
- Pro card: `scale-105`, shadow-violet-500/20, distinct gradient border.

GLOBAL ANIMATION / INTERACTION RULES
- Intersection Observer: Trigger `.animate` on `.animate-on-scroll` elements with 0.2 threshold.
- Custom Button Sheen: Span moves `translateX(-120%)` to `translateX(220%)` on hover.
- Smooth Scroll: `scroll-smooth` on html.

COMMON MISTAKES TO AVOID
- Do not use generic icons; must use Lucide matching source.
- Do not miss the fixed top gradient-blur component; it's critical for the header transparency effect.
- Do not normalize rotations in the hero section; keep the exact negative and positive skews.