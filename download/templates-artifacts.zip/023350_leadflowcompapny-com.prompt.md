Recreate the website "Lead Flow Company" with high visual fidelity as a Tailwind CSS-based site.

The result must match the supplied reference website, not a cleaned-up reinterpretation.

Preserve source quirks:
- The navigation bar uses `pointer-events-none` on the parent `<header>` while explicitly setting `pointer-events-auto` on the inner `<nav>` element.
- Wistia video player has a specific blur-filter fallback style for when it's not yet defined.
- The FAQ section uses the `<details>` and `<summary>` elements with custom CSS to hide default markers.
- Shared border gradients are applied using a `::before` pseudo-element with a complex `-webkit-mask-composite` setup.

CRITICAL FIDELITY CONSTRAINTS
- Background is strictly `#050505` (Body) and `#0A0A0A` (Sections).
- No stock images: Only use the Wistia embed for the video and the Solar icon set via Iconify.
- Layer stacking: Navigation must be `z-50`. Hero grid background must be `pointer-events-none` with 30% opacity.
- Form actions must use the exact `formsubmit.co` endpoints specified.

TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN: https://cdn.tailwindcss.com)
- Lucide Icons (https://unpkg.com/lucide@latest)
- Iconify-Icon (https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js)
- Wistia Player (https://fast.wistia.com/player.js and embed script for ID `ieii2teuvz`)
- Calendly Widget (https://assets.calendly.com/assets/external/widget.js)
- Fonts: 'Instrument Serif' (italic/normal), 'Inter' (300-600), 'Montserrat' (300-600) via Google Fonts.

GLOBAL STYLE
- Body: `antialiased`, text color `text-gray-400`, selection background `rose-500/30`.
- Utility `glass`: `bg-rgba(10, 10, 10, 0.7)`, `backdrop-filter: blur(12px)`, border `1px solid rgba(255, 255, 255, 0.08)`.
- Transitions: Use `cubic-bezier(0.16, 1, 0.3, 1)` for fade-up animations.

ASSET MAP
- Wistia Media ID: `ieii2teuvz`
- Calendly URL: `https://calendly.com/yahya-leadflowcompany/30min?hide_gdpr_banner=1&background_color=0a0a0a&text_color=ffffff&primary_color=e11d48`
- Form Endpoint: `https://formsubmit.co/yahya@leadflowcompany.com`

VECTOR / ICON SHAPES
- Use `iconify-icon` with these names: `solar:arrow-right-linear`, `solar:graph-down-linear`, `solar:users-group-rounded-linear`, `solar:danger-circle-linear`, `solar:target-linear`, `solar:chart-square-linear`, `solar:shield-check-linear`, `solar:phone-linear`, `solar:check-circle-linear`, `solar:alt-arrow-down-linear`.

MEDIA BEHAVIOR
- Wistia Player: `aspect="1.7777777777777777"`, auto-loading enabled.
- Background Grid: Radial mask using `[mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]`.

LAYER STACK / POSITIONING MAP
- Header: Fixed, Top-0, Z-50. Glass-morphic nav pill.
- Hero: Relative, background grid (Layer 0), content (Layer 10).
- Section Cards: Gradient borders using pseudo-elements with `inset: 0` and `padding: 1px`.
- CTA Overlays: Radial gradients from `rose-950/40` in top-right or top-left corners.

SECTION 1 - NAVIGATION
- Pill-shaped centered nav. Left: "Lead Flow Company" (Instrument Serif, Italic). Right: "Get Started" White button with `rose-600` hover state. Smooth scroll enabled.

SECTION 2 - HERO
- Headline: Instrument Serif, 5rem max, tight tracking.
- Video: 16:9 aspect ratio, 4px white/10 border, ring-1 ring-white/5.
- Copy: "We'll Build & Launch Your Cold Email Machine..."

SECTION 3 - PAIN POINTS
- 3-column grid. Cards have `bg-gradient-to-br from-[#121212] to-[#0a0a0a]`. Custom property `--border-gradient: linear-gradient(135deg, rgba(244,63,94,0.3), rgba(244,63,94,0.05))`.

SECTION 4 - BENEFITS
- Cards use large background icons (Solar set) positioned `mt-auto self-end` with 5% opacity that scale/color-shift to rose on hover.

SECTION 5 - PROCESS
- Numbers 1-2-3 in large circular outlines. Desktop-only connecting line: absolute `h-0.5` horizontal bar with `bg-gradient-to-r via-white/10`.

SECTION 6 - WHAT'S INCLUDED
- Large container with `bg-[#111]`. Checklist items use `solar:check-circle-linear`. Final item is highlighted with `border-rose-500/40 border-b-2`.

SECTION 7 - AUDIT FORM
- Section with `bg-[radial-gradient(circle_at_top_right,...)]`. Two inputs (Email, Website) and a white submit button.

SECTION 8 - FAQ
- `<details>` components with `border-white/5`. Summary contains text + chevron. Content revealed on `open` with `border-t pt-4`.

SECTION 9 - CALENDLY
- Inline widget embed at 700px height. Wrapped in `bg-[#0a0a0a]` rounded container.

SECTION 10 - ENQUIRY FORM
- 2-column grid for Name/Email. Textarea for message. Background blur-3xl rose glow in top-right corner.

SECTION 11 - FOOTER
- Border-t white/5. Left: Logo and tagline. Right: Vertical links (Services, About, Contact, LinkedIn). Bottom: Copyright text in 10px Montserrat.

GLOBAL ANIMATION / INTERACTION RULES
- `.animate-fade-up`: `translateY(20px)` to `0`, opacity 0 to 1.
- Marquee Mask: `linear-gradient(to right, transparent, black 10%, black 90%, transparent)`.
- Buttons: White bg scales to rose-600 on hover; text flips from black to white.

COMMON MISTAKES TO AVOID
- Do not use standard Tailwind borders for the cards; you must implement the `::before` pseudo-element mask for the gradient border effect.
- Do not omit the `pointer-events-none` on the header wrapper.
- Do not use a different video player than Wistia.

IMPLEMENTATION REQUIREMENTS
- Build the actual landing page as the first screen.
- Use the exact text, assets, section order, and IDs provided.
- Use explicit CSS for absolute/fixed/sticky layers.
- Preserve the exact font pairings: Serif for headings/logo, Montserrat for UI/buttons, Inter for body copy.