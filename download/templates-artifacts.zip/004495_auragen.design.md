---
version: 1.0.0
name: auragen
description: A dark, futuristic interface designed for AI creative tools, featuring glassmorphism, 3D transforms, and neon accents.

colors:
  background: "#020617"
  surface: "#0f172a"
  surface-elevated: "#1e293b"
  primary: "#e879f9"
  secondary: "#1d4ed8"
  accent: "#8484ff"
  border: "rgba(255, 255, 255, 0.1)"
  text-main: "#f8fafc"
  text-muted: "#94a3b8"
  selection: "rgba(217, 70, 239, 0.3)"

typography:
  headings:
    family: "Geist, sans-serif"
    weight: "500"
    tracking: "-0.05em"
  body:
    family: "Inter, sans-serif"
    weight: "400"
    lineHeight: "1.6"
  mono:
    family: "Geist Mono, monospace"
    weight: "400"
    size: "12px"

spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "32px"
  hero: "80px"

rounded:
  sm: "4px"
  md: "8px"
  lg: "12px"
  xl: "16px"
  full: "9999px"

components:
  nav:
    position: "sticky"
    blur: "8px"
    height: "72px"
  button-shiny:
    animation: "border-spin 2.5s linear infinite"
    border: "2px solid transparent"
    padding: "1.25rem 2.5rem"
  card-glass:
    bg: "rgba(255, 255, 255, 0.05)"
    border: "1px solid rgba(255, 255, 255, 0.1)"
    backdrop-filter: "blur(12px)"
  app-preview:
    perspective: "500px"
    rotation: "rotateX(5deg)"
    shadow: "2xl"
  badge:
    rounded: "9999px"
    bg: "rgba(255, 255, 255, 0.05)"
    border: "1px solid rgba(255, 255, 255, 0.1)"

motion:
  fade-in-up: " fadeInUp 0.6s ease-out forwards"
  marquee: "marquee-ltr 45s linear infinite"
  transition-fast: "0.3s ease"
---
## Overview
AuraGen is a sophisticated dark-themed design system optimized for generative AI products. It focuses on depth through layering, using a mix of CSS 3D transforms, background blurs, and animated borders to create a "high-tech" feel.

## Colors
The palette is rooted in deep slates and blacks (`#020617`), with vibrant neon accents in fuchsia and electric blue. All surfaces utilize low-opacity white borders (`rgba(255, 255, 255, 0.1)`) to define edges without adding visual weight.

## Typography
- **Geist** is used for display headings with tight tracking for a modern, architectural look.
- **Inter** handles high-legibility body text.
- **Geist Mono** is applied to prompt metadata and technical attributes.

## Spacing
A strict 8px grid system ensures alignment. High-impact areas like the Hero section utilize significant vertical padding (80px+) to allow the ambient background gradients to breathe.

## Layout
- **Layering:** The system uses a Z-index stack starting with ambient blurred gradients (background), glassmorphic cards (midground), and sticky/fixed nav elements (foreground).
- **Perspective:** The primary feature preview utilizes a 3D transform (`rotate-x-5`) to simulate physical depth within the viewport.
- **Containers:** Max-width restricted to 1280px (`max-w-7xl`) for content readability.

## Elevation & Depth
Depth is achieved through `backdrop-filter: blur()` and nested gradients rather than traditional drop shadows. The "Gradient Blur" component at the top of the viewport creates a soft transition for sticky elements.

## Shapes
Rounded corners are generous (`16px` for cards, `full` for buttons) to offset the sharp, technical nature of the typography and color palette.

## Components
- **Shiny CTA:** A primary action button with a conic-gradient border animation and radial-shimmer effects.
- **App Dashboard Preview:** A complex multi-panel layer consisting of a sidebar, main image grid, and settings panel, all housed in a container with MacOS-style title bar controls.
- **Masonry Gallery:** Uses `columns-1` to `columns-4` for organic image discovery.
- **Marquee Testimonials:** Infinite-scrolling horizontal bands for social proof.

## Motion
- **Entrance:** Content utilizes `animate-fade-in-up` with staggered delays (200ms, 300ms).
- **Interactivity:** Hovering over gallery images triggers a grayscale-to-color transition and a blur-reveal for action buttons.
- **Global:** Marquees provide constant, low-velocity movement to keep the page feeling active.

## Do's and Don'ts
- **Do:** Use `border-white/10` on all container edges to ensure visibility against the dark background.
- **Do:** Apply `backdrop-blur` to any element overlapping a gradient.
- **Don't:** Use solid bright backgrounds; all light colors should be treated as accents or text.
- **Don't:** Mix high-saturation colors outside of the primary fuchsia/blue spectrum.

## Accessibility
- Use `selection:bg-fuchsia-500/30` to ensure text remains readable during highlight.
- Maintain high contrast by using `text-zinc-100` on the slate background.
- All interactive SVG icons include `aria-hidden` or descriptive labels.