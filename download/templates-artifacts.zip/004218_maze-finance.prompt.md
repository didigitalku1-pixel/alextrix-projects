Recreate the website "Maze Bank Financial Services" with high visual fidelity as a Tailwind CSS and Vanilla JavaScript site.

The result must match the supplied reference website, not a cleaned-up reinterpretation.

### SOURCE QUIRKS
- The header logo uses a background image on an <a> tag instead of a standard <img> element.
- Multiple redundant `<style>` blocks for `.animate-on-scroll` are present in the source; preserve this implementation pattern.
- Mobile sliders use a combination of `mask-image` for fade-out effects and standard overflow-x-auto.
- The "Most Popular" tag on the pricing section is offset using a negative top value (`-top-3`).

### CRITICAL FIDELITY CONSTRAINTS
- **Border Gradients**: Use the custom `::before` pseudo-element with `-webkit-mask-composite: xor` as defined in the source to create the subtle 1px border highlights.
- **Animation**: All entrance animations MUST use the `fadeSlideIn` keyframes (30px Y-offset to 0, with blur 8px to 0).
- **Stacking**: Use fixed/absolute positioning for the aura background layers to ensure they remain behind all content without interfering with pointer events.
- **Typography**: The site uses a mix of fonts including Inter, Bricolage Grotesque, and Instrument Serif for specific brand names in the ticker.

### TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN)
- Lucide Icons (https://unpkg.com/lucide@latest)
- Google Fonts (Inter, Geist, Roboto, Montserrat, Poppins, Playfair Display, Instrument Serif, Merriweather, Bricolage Grotesque, Plus Jakarta Sans, Manrope, Space Grotesk, Work Sans, PT Serif, Geist Mono, Space Mono, Quicksand, Nunito)
- UnicornStudio.js (https://cdn.jsdelivr.net/gh/hiunicornstudio/unicornstudio.js@v1.4.29/dist/unicornStudio.umd.js)

### GLOBAL STYLE
- **Body**: `antialiased bg-gray-950 text-slate-100 min-h-screen`
- **Custom Border Utility**:
```css
.border-gradient::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: inherit;
  padding: 1px;
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask-composite: exclude;
  background: linear-gradient(225deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.2) 50%, rgba(255,255,255,0) 100%);
  pointer-events: none;
}
```

### ASSET MAP
- **Logo**: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/b60257bc-d9de-4c89-8ab5-de54c968f5e6_1600w.png`
- **Template Previews**:
  - Insights: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/4cf79132-dd2e-4d3e-bb75-0668745cf97a_800w.webp`
  - Gallery: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/79b9374b-8b95-4b65-884b-ba53e7e50db0_800w.webp`
- **Expert Showcases**:
  - Project 1: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/39d6bd74-d7eb-4a3c-afb3-43091ef38e3e_1600w.webp`
  - Project 2: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/8d8e9137-e6b2-450f-8d91-712da931fca8_1600w.webp`
  - Project 3: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/f2d01e24-ffb7-4d58-a555-a9e9ef285492_1600w.webp`
  - Project 4: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/dc7cd604-fbac-4a62-ba0e-15a549771b7e_1600w.webp`
- **Feature Images**:
  - Dashboard: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/a9e98a5a-74e8-416c-9719-83ad546f665a_1600w.webp`
  - Transfers: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/a4024872-3363-422c-a595-9375ac41ad79_1600w.webp`
  - Security: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/b5f25964-76fc-4770-8df8-c91609068d73_1600w.webp`

### VECTOR / ICON SHAPES
- Use Lucide icons: `play`, `menu`, `mail`, `arrow-right`, `shield-check`, `sparkles`, `zap`, `bell`, `search`, `wifi`, `shopping-bag`, `user`, `store`, `home`, `credit-card`, `pie-chart`, `settings`, `chevron-left`, `wallet`, `shield`, `plus`, `bar-chart-3`, `cog`, `rocket`, `book-open`, `globe`, `messages-square`, `twitter`, `github`, `linkedin`.

### LAYER STACK / POSITIONING MAP
- **Layer -10 (Background)**:
  - `aura-background-component`: Fixed `inset-0`. Contains three blur blobs: Top-left (indigo, h-80, w-80, blur-3xl), Top-right (fuchsia, h-96, w-96, blur-3xl), Bottom-center (gradient indigo/violet/fuchsia, w-[40rem], h-64, blur-3xl).
- **Main Content**: `max-w-7xl mx-auto` container for all major sections.
- **Hero Phones**: Stacked using `absolute` positioning. Left phone (`-rotate-6`), Center phone (z-10, centered), Right phone (`rotate-6`).

### SECTION-BY-SECTION DETAILS

**Header & Hero**
- Nav: Sticky/relative header. Links: Solutions, Protection, Plans, Help Center. CTA: "App Store" with `lucide-play` icon.
- Copy: H1 "Transform your financial future today" (tracking-tighter).
- Input: Email address field with `border-gradient` and `lucide-mail` icon.
- Badges: "Military-grade security", "Up to 5% rewards", "Lightning-fast payments".
- Interaction: Buttons have `hover:scale-[1.1]` and `-translate-y-[3px]` with 1000ms cubic-bezier transitions.

**Ticker Section**
- Animation: `ticker 40s linear infinite` with a hover:pause state.
- Content: Quantum Ventures, Stellar Digital (Bricolage), Velocity Group (Merriweather), Horizon Capital (Instrument Serif), Apex Solutions (Playfair), Prime Industries, Infinity Labs.
- Masking: `mask-image: linear-gradient(to right, transparent, black 15%, black 85%, transparent)`.

**Templates Section**
- Layout: 2-column grid.
- Visuals: Three stacked cards using `absolute` rotation and positioning. Front card is white with "Maze Boilerplate" text.

**Experts Slider**
- Controls: `experts-prev` and `experts-next` buttons (visible on MD+).
- Logic: Scroll-linked dots that update via `requestAnimationFrame` on slider scroll event.

**Pricing Section**
- Toggle Logic: Vanilla JS `data-billing-toggle` updates text contents of `data-price` spans (Monthly/Yearly) and toggles the "Save 17%" badge visibility.

### GLOBAL ANIMATION / INTERACTION RULES
- **Scroll Entrance**: Use `IntersectionObserver` to add the `.animate` class to `.animate-on-scroll` elements. Threshold: 0.2, rootMargin: "0px 0px -10% 0px".
- **Smooth Scroll**: Implement `scroll-smooth` on slider containers.

### IMPLEMENTATION REQUIREMENTS
- Preserve exact color codes (bg-gray-950, indigo-500/20, fuchsia-500/20).
- Do not substitute Lucide icons for others.
- Maintain the `border-gradient` pseudo-element logic for all cards and buttons.
- Ensure the mobile nav (hamburger menu) and mobile layout shifts (stacking hero inputs) match the responsive classes provided.