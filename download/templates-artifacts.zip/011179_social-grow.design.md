---
version: 1.0.0
name: Social Grow
description: A visual system for social media agencies focused on conversion, authority, and premium content presentation.
colors:
  background: "#E3DDD7"
  surface: "#EFEAE5"
  accent: "#D1C8C0"
  black: "#000000"
  white: "#FFFFFF"
  text-primary: "#111827"
  text-secondary: "#6B7280"
  text-muted: "#9CA3AF"
  border: "rgba(17, 24, 39, 0.05)"
typography:
  display:
    family: "Manrope"
    weight: "600"
    lineHeight: "0.95"
    letterSpacing: "-0.02em"
  accent:
    family: "Playfair Display"
    weight: "500"
    style: "italic"
  body:
    family: "Manrope"
    weight: "400"
    lineHeight: "1.5"
  label:
    family: "Manrope"
    weight: "600"
    size: "12px"
    transform: "uppercase"
spacing:
  xs: "8px"
  sm: "16px"
  md: "24px"
  lg: "48px"
  xl: "64px"
  section: "128px"
rounded:
  sm: "8px"
  md: "16px"
  lg: "32px"
  full: "999px"
components:
  navbar:
    position: "relative"
    z-index: "500"
    height: "auto"
  button-primary:
    bg: "black"
    text: "white"
    rounded: "999px"
    hover: "scale(1.05)"
  card-service:
    bg: "rgba(255, 255, 255, 0.4)"
    backdrop: "blur(8px)"
    rounded: "32px"
  phone-mockup:
    border: "8px solid white"
    rounded: "40px"
    shadow: "2xl"
    z-index: "10"
  testimonial-card:
    bg: "#EFEAE5"
    rounded: "40px"
motion:
  enter:
    animation: "slideUpBlur"
    duration: "800ms"
    easing: "cubic-bezier(0.16, 1, 0.3, 1)"
  hover:
    duration: "300ms"
    easing: "ease-out"
---
## Overview
The Social Grow visual system is designed to project a mix of professional data-driven agency results and high-fidelity creative content. It uses a warm neutral palette to differentiate from typical blue-hued SaaS templates.

## Colors
The palette is grounded in `#E3DDD7` (Background), providing a softer, more premium feel than pure white. High contrast is maintained via black text and buttons, while `#D1C8C0` is used for high-level badges and labels to denote secondary importance without introducing distracting vibrant colors.

## Typography
- **Primary Sans**: Manrope is used for utility and clarity in body text and navigation.
- **Secondary Serif**: Playfair Display provides editorial flair for emphasis, specifically targeting keywords to give a "boutique" feel.
- **Hierarchy**: Large display sizes (7xl+) use extremely tight line-height (0.95) for a modern, compact headline aesthetic.

## Spacing
Based on a loose 8px grid. Section padding is generous (128px) to allow visual elements like phone mockups to occupy significant white space without cluttering the layout.

## Layout
The system utilizes a 12-column grid. Key layouts involve split-screen hero sections where the left column handles typography and the right handles complex, layered visual components. Case studies utilize an alternating grid to maintain user interest.

## Elevation & Depth
Depth is achieved through:
- **Glassmorphism**: Service cards use `backdrop-filter: blur` and semi-transparent white backgrounds.
- **Layered Mockups**: Phone frames use heavy shadows (`shadow-2xl`) and are often positioned above blurred gradient backgrounds (`blur-3xl`).
- **Z-Indexing**: Navigation stays at 500, with modal menus at 300 to ensure clear priority.

## Shapes
Shapes are aggressively rounded. Containers and image wrappers typically use a 32px or 40px radius (`rounded-[2rem]` or `rounded-[2.5rem]`). Buttons and badges use fully pill-shaped rounding for a friendly, approachable interface.

## Components
- **Navigation**: Clean, sticky-ready bar with a high z-index and minimal desktop links.
- **Phone Slider**: A functional UI component containing nested cards that transition with `cardEnter` and `cardExit` animations.
- **Comparison Table**: A side-by-side block contrast component using high-contrast (Black/White) for the brand and low-contrast (Gray) for competitors.
- **FAQ Accordion**: Built using `<details>` elements with rounded corners and distinct background coloring for state changes.

## Motion
- **Entry**: Global `slideUpBlur` animation on page load for all major sections.
- **Micro-interactions**: Arrows and buttons utilize `scale-105` on hover for tactile feedback.
- **Continuous**: "Sonar" rings around CTAs in the mobile slider provide constant visual cues to user interactables.

## Do's and Don'ts
- **Do**: Use italics sparingly in headlines to emphasize emotional keywords.
- **Do**: Maintain generous whitespace between section blocks.
- **Don't**: Use vibrant primary colors like bright blue or green for primary branding; keep the palette neutral.
- **Don't**: Use sharp 90-degree corners on any card or container.

## Accessibility
- **Contrast**: Text primarily uses `gray-900` on light backgrounds to exceed AA standards.
- **Interaction**: Mobile menu buttons include `aria-label` and `aria-hidden` attributes for screen readers.
- **Focus**: Interactive elements like accordions use standard list markers and high-contrast focus states.