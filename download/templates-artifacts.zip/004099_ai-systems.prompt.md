Recreate the website "AI Systems" with high visual fidelity as a Tailwind-based landing page. The result must match the supplied reference exactly, preserving its dark, technical aesthetic and sophisticated layering.

Preserve source quirks:
- Mixed typography: Uses 'Inter' as the primary body font but relies on 'Geist' for headlines and specific UI components.
- Specific breakpoint logic: Horizontal grid lines and vertical dividers change visibility or position at md (768px) and lg (1024px).
- Parallax logic: Background elements and specific images (like the Generative Systems visual) use a unique scroll-timeline animation that translates Y position from -12% to 12%.

CRITICAL FIDELITY CONSTRAINTS
- Background Stacking: Use a z-10 mix-blend-screen overlay for the particles.js canvas.
- Glassmorphism: Backgrounds for cards must use `bg-slate-900/40`, `backdrop-blur-md`, and a `ring-1 ring-white/10` border.
- Gradient Borders: Dividers must use `bg-gradient-to-r from-transparent via-white/10 to-transparent` (horizontal) or `bg-gradient-to-b` (vertical).
- Animation: Every major section and card must use the `animate-on-scroll` class with the `fadeSlideIn` keyframe and progressive delays (0.1s to 0.5s).

TECH STACK / DEPENDENCIES
- CSS: Tailwind CSS (CDN), Custom Keyframes for `fadeSlideIn` and `parallaxElement`.
- Icons: Lucide Icons (unpkg).
- Particles: particles.js@2.0.0.
- Fonts: 'Inter' (300-600) and 'Geist' (300-700) via Google Fonts.

GLOBAL STYLE
- Page Background: `bg-slate-950`.
- Text: `text-slate-100` with `antialiased` rendering.
- Typography: Headlines use `tracking-tighter` and `font-geist`.

ASSET MAP
- Hero BG: https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/92a4234b-15fa-4d5f-8821-48d3f9f7e2f1_3840w.jpg
- Logo: https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/f7466370-2832-4fdd-84c2-0932bb0dd850_800w.png
- Face Scan: https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/863c6d3d-359c-471a-8fd8-543677b59c4c_800w.webp
- Team Portrait: https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/20253914-1507-436f-a56d-f7abbc5d0c73_800w.webp
- Generative Visual: https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/2bad1237-d4b7-4abc-a4ff-4bb6e105b47d_1600w.png
- Connection Overlay: https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/459579f4-e2d0-4218-a12d-f974a4b89651_800w.jpg

VECTOR / ICON SHAPES
- Use exact Lucide icons: `sparkles`, `zap`, `arrow-right`, `calendar`, `activity`, `smile`, `clock`, `check`.
- Custom SVG Path for logo/decorative elements if Lucide is missing specific shapes.

LAYER STACK / POSITIONING MAP
- Z-INDEX 0: Particles.js canvas (absolute inset-0) and decorative grid lines.
- Z-INDEX 1: Main background image (`object-cover`).
- Z-INDEX 5: Fixed `gradient-blur` container (65% height from bottom).
- Z-INDEX 10: Header, Main content sections, and interactive cards.

SECTION 1 - HERO
- Background: particles.js canvas with white circles, distance 150 connection lines.
- Layout: 12-column grid. Col 1-5 (Headline), Col 6 (Divider), Col 7-10 (Description), Col 11-12 (Buttons).
- Copy: "Next-Gen AI Solutions", "Transform Your Business with Intelligent AI".
- Interaction: Magnetic effect on header nav items and CTA buttons.

SECTION 2 - SOLUTIONS GRID
- Structure: 3-column grid on desktop.
- Card A (Metrics): Inline vertical bars (heights: 28px to 96px) in orange-400/80.
- Card B (Verification): Image with absolute "98% Face detection" label and "Live" dot.
- Card C (Success Rate): Progress bars with absolute white dot handles at 63%, 24%, and 13%.
- Card D (Latency): Gradient bar `from-orange-400/80 to-red-500/80`.
- Logo Ticker: Infinite loop animation (`translateX(0)` to `translateX(-100%)`) with TechFlow, Nexus Labs, DataSync, VisionCorp, CloudBase.

SECTION 3 - SHOWCASE / POINT OF VIEW
- Visual: Large 16:11 aspect image with `[animation-timeline:view()]` parallax effect.
- Layout: Left side visual (Col 7), Right side copy (Col 5).
- Copy: "Outcomes, Engineered with Intention".

SECTION 4 - KEY FEATURES
- Card 1: Mini transcript UI with "Live transcript" and list items.
- Card 2: Background image with `slate-950/80` gradient overlay and "Seamless Collaboration" text.
- Card 3: "Professional Template" preview box with date and session details.

SECTION 5 - PRICING
- Three tiers: Starter ($0), Professional ($49 - POPULAR badge), Enterprise (Custom).
- Style: Glassmorphic cards with blue-300 checkmark icons.

GLOBAL ANIMATION / INTERACTION RULES
- Intersection Observer: Trigger `animate` class when element is 20% in view.
- Keyframes: `fadeSlideIn` (opacity 0 + translateY 30px + blur 8px -> opacity 1 + translateY 0).
- Ticker: 40s linear infinite duration, paused on hover.

COMMON MISTAKES TO AVOID
- Do not use generic placeholders; use the Supabase URLs provided.
- Do not omit the grid background lines; they are critical for the "technical" feel.
- Ensure the `gradient-blur` in the header uses the multi-layer backdrop-filter approach defined in the source styles.