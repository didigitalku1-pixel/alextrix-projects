Recreate the website "MAD SOAPS" with high visual fidelity as a Tailwind CSS and Vanilla JavaScript site.

The result must match the supplied reference website, not a cleaned-up reinterpretation.

Preserve source quirks:
- The second hero slide link has a unique style override specifically forcing a gold/dark-yellow conic gradient even though the primary button style is blue.
- The navigation buttons for "Marine", "Auto", and "Plans" use a native `onclick` window location shift but also trigger dropdowns on hover.
- Hero section uses a mix of `<picture>` for the first slide and standard `<img>` for others.

CRITICAL FIDELITY CONSTRAINTS
- Background is not a flat color; the footer uses a complex three-part radial and linear gradient stack.
- Button hover states must include specific `translateY(-1px)` and custom shadow `0 8px 18px rgba(37,99,235,.25)`.
- Mobile menu must disable body scroll when active using `overflow: hidden` on the body tag.

TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN: https://cdn.tailwindcss.com)
- Iconify (CDN: https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js)
- Google Fonts: Inter (300, 400, 500, 600, 700)

GLOBAL STYLE
- Primary Color: `rgb(37, 99, 235)`
- Surface: `#ffffff`
- Text: `rgb(15, 23, 42)`
- Font: 'Inter', sans-serif
- Container Max-Width: `80rem` (1280px)
- Header Height: `5rem` (80px)

ASSET MAP
- Logo: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/76f42c4a-16c4-4f44-a952-cdbe9b73f8cc_320w.png
- Hero Slide 1 (Mobile): https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/5ab86840-40a4-470b-ba0d-a62bbc4a3e0e_1600w.jpg
- Hero Slide 1 (Desktop): https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/613ce0bc-20bf-4fef-b8bf-497e97eaaacc_3840w.png
- Hero Slide 2: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/050b3889-440b-4ef6-83e7-65100148e75c_3840w.jpg
- Hero Slide 3: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/5b8edd23-dadd-487c-88e4-cc9ac66c8088_3840w.jpg
- Hero Slide 4: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/be51fece-5116-4f75-9766-481acaa89b82_3840w.jpg
- Team Image: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/6b449261-0257-48af-922c-100ea2a69e5e_1600w.jpg

VECTOR / ICON SHAPES
- Use `iconify-icon` for all icons including `solar:alt-arrow-down-linear`, `solar:hamburger-menu-linear`, `solar:close-circle-linear`, `solar:arrow-right-linear`, `solar:cart-linear`, `solar:check-circle-linear`, `solar:shield-warning-linear`, `solar:anchor-linear`, `solar:map-point-linear`, `solar:ship-linear`, `solar:star-bold`, `solar:water-linear`, `solar:phone-calling-linear`.

LAYER STACK / POSITIONING MAP
- Header: `fixed`, `z-50`, `bg-white/90`, `backdrop-blur-md`.
- Hero Slideshow: Parent `absolute inset-0`, `z-0`. Individual slides `absolute inset-0`, `transition-opacity duration-1000`.
- Mobile Menu: Drawer `fixed inset-0`, `z-100`. Overlay `fixed inset-0` with blur. Content `absolute right-0` with `translateX(100%)` transition.
- Buttons (Conic Gradient): Use a nested div stack: `absolute inset-0 -z-20` for beam, `absolute inset-[1px]` for dark center, and `overflow-hidden` inner bg.

SECTION 1 - HEADER & NAVIGATION
- Desktop: Nav links with `h-full items-center`. Dropdown panels trigger on hover with `opacity: 1`, `visibility: visible`, and `translateY(0)`.
- Mobile: Hamburger toggle on right. Logo on left. Contact button hidden on small mobile.

SECTION 2 - HERO SLIDESHOW
- Logic: `setInterval` every 5000ms. On mobile, lock to Slide 1 only. On desktop, cycle through 4 slides with opacity cross-fade.
- Content: "Serving The East Coast" pulse badge. H1 with `bg-clip-text text-transparent bg-gradient-to-r from-blue-200 to-white`.
- Buttons: Two "beam" buttons with spinning conic gradients (`animation: beam-spin 3s linear infinite`).

SECTION 3 - SEO CONTENT (RESTORATION)
- Background: `bg-slate-50`. Eyebrow "Marine Restoration".
- Content: Centered header, then 3 paragraphs with `text-link` style (underlined with offset and 0.2 opacity underline color).

SECTION 4 - ENVIRONMENT & PROTECTION
- Layout: 2-column grid. Left: Paragraphs + icon list (`solar:check-circle-linear`). Right: Info card with top-right corner radius decoration (`rounded-bl-full opacity-50`).

SECTION 5 - LOCAL EXPERTISE & MARINAS
- Layout: 2-column grid. Left: Text + wrap flex-pill list of locations (Annapolis, South River, etc.). Right: Card listing Marinas with `solar:map-point-linear` icons.

SECTION 6 - RECENT PROJECTS
- Grid: `grid-cols-1 sm:grid-cols-2 lg:grid-cols-4`. Card style: `card-service` with hover transform `translateY(-2px)` and shadow.

SECTION 7 - TEAM & TESTIMONIAL
- Team: Image left, text right (reverses order on mobile).
- Testimonial: Centered five-star block (`solar:star-bold`). Large text blockquote with horizontal rule accents (`w-8 h-[1px] bg-slate-200`) around the citation.

SECTION 8 - FAQ
- UI: Native `<details>` and `<summary>` elements. Custom `faq-icon` rotation on `[open]`. Shadowed white cards with border-t on content.

FOOTER
- Background: `radial-gradient(1200px 600px at 20% 0%, rgba(37,99,235,0.18), transparent 55%)` combined with slate/dark linear gradients.
- Columns: Brand (Logo + Socials), Marine Services, Company/Automotive.
- Bottom: Copyright + Legal links on right.

GLOBAL ANIMATION / INTERACTION RULES
- Smooth scrolling enabled.
- Keyframes: `beam-spin` (360deg rotation).
- Header transition on scroll (300ms).
- Mobile menu cubic-bezier: `cubic-bezier(0.16, 1, 0.3, 1)`.

COMMON MISTAKES TO AVOID
- Do not use standard Tailwind buttons for the hero; they must have the conic-gradient beam effect and the custom HTML structure provided in the source.
- Do not forget the `backdrop-blur-md` on the header.
- Do not simplify the footer background to a single color.

IMPLEMENTATION REQUIREMENTS
- Use exact text and section order.
- Preserve object-fit/position for hero images.
- Final page should feel indistinguishable from the source HTML.