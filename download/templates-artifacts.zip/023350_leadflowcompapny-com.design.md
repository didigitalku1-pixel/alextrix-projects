---
version: 1.0.0
name: Lead Flow Design System
description: A premium B2B dark-mode aesthetic utilizing deep blacks, glassmorphism, and rose-gold highlights to convey authority and performance.
colors:
  background: "#050505"
  surface: "#0A0A0A"
  surfaceLight: "#111111"
  primary: "#E11D48"
  primaryHover: "#BE123C"
  accent: "#FB7185"
  textMain: "#FFFFFF"
  textMuted: "#9CA3AF"
  textDim: "#6B7280"
  border: "rgba(255, 255, 255, 0.08)"
typography:
  display:
    family: "Instrument Serif"
    weight: "500"
    style: "italic"
  heading:
    family: "Instrument Serif"
    weight: "500"
  body:
    family: "Inter"
    weight: "300, 400, 600"
  interface:
    family: "Montserrat"
    weight: "500, 600"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "32px"
  section: "80px"
rounded:
  sm: "8px"
  md: "12px"
  lg: "24px"
  xl: "32px"
  full: "999px"
components:
  navigation:
    position: "fixed"
    backdrop: "blur(12px)"
    background: "rgba(10, 10, 10, 0.7)"
  buttons:
    variants:
      primary: "bg-white text-black rounded-full transition-all"
      outline: "border border-white/10 text-white bg-transparent"
  cards:
    variants:
      gradient: "bg-gradient-to-br from-[#121212] to-[#0a0a0a] border-white/5"
      glass: "backdrop-blur-md border-white/10"
  forms:
    input: "bg-white/5 border-white/10 rounded-full focus:border-rose-500"
motion:
  fadeUp: "0.8s cubic-bezier(0.16, 1, 0.3, 1)"
  marquee: "40s linear infinite"
---
## Overview
Lead Flow Company uses a "Dark Luxury" B2B visual language. The system pairs professional high-contrast typography (Serif for trust, Sans for utility) with technical elements like grid overlays and glassmorphism to establish credibility in high-ticket outbound systems.

## Colors
The palette is rooted in `#050505` (True Black) to reduce eye strain and provide a canvas for the `#E11D48` (Rose) action color. Gradients are used sparingly for depth, moving from charcoal tones to deep blacks to define hierarchy.

## Typography
- **Serif (Instrument Serif):** Used for primary value propositions and section headings. Usually italicized in logos or key headlines to add a "boutique agency" feel.
- **Sans (Inter):** The primary engine for body copy, emphasizing readability with light (300) and regular (400) weights.
- **UI (Montserrat):** Reserved for buttons, eyebrows, and navigational elements to maintain a high-energy, modern interface feel.

## Spacing
The system relies on an 8px base grid. Section vertical spacing is generous (80px to 120px) to allow content-heavy value propositions to breathe and command attention.

## Layout
Layouts are structured using centered stacks for high-impact conversion sections. Grid layouts (3-column) are used for feature benefits and pain points. Components utilize `max-w-7xl` for main content and `max-w-3xl` for focused forms or FAQ sections.

## Elevation & Depth
- **Base Layer:** `#050505` background.
- **Midground:** `#0A0A0A` sections with subtle 1px borders.
- **Foreground:** Glass containers with 12px blur and white/8% transparency borders.
- **Overlays:** Grid patterns (`bg-[size:4rem_4rem]`) with radial mask gradients to create a sense of technical infrastructure.

## Shapes
The system is highly organic, favoring `rounded-full` for all active components (buttons, inputs, pills) and `rounded-[2.5rem]` for structural containers and section wrappers to soften the dark aesthetic.

## Components
- **Floating Nav:** A centered, glassmorphic pill containing the serif logo and a high-contrast white CTA.
- **Hero Video:** A wide aspect-ratio (`16:9`) container with heavy shadow and `ring-1 ring-white/5` to separate it from the dark background.
- **Accordion (FAQ):** Minimalist `details` tags with custom summary markers and thin horizontal separators.
- **Gradient Borders:** Uses pseudo-elements (`::before`) to create 1px gradient strokes that define card edges without being heavy.

## Motion
- **Entrance:** Content utilizes `fadeUp` animations with a `0.1s` to `0.5s` stagger to guide the user's eye from the headline to the CTA.
- **Interactivity:** Hover states for cards use `scale-110` on icons and rose-colored shadow glows (`shadow-rose-500/20`).

## Do's and Don'ts
- **Do:** Use Rose-500 for success indicators and primary calls to action.
- **Do:** Ensure serif headings have `tracking-tighter` or `tracking-tight` settings.
- **Don't:** Use solid grey backgrounds; always favor dark gradients or black.
- **Don't:** Use sharp 90-degree corners; everything must be rounded.

## Accessibility
- Contrast is maintained through white-on-black text with minimum 4.5:1 ratios.
- Focus states are highlighted with Rose-500 borders.
- `antialiased` font rendering is applied globally to ensure thin Inter weights remain legible on dark backgrounds.