---
version: "1.0.0"
name: "Aura Globe System"
description: "Glassmorphic interactive card system with integrated 3D WebGL rendering."
colors:
  bg-primary: "#111827"
  bg-card: "rgba(255, 255, 255, 0.1)"
  bg-drawer: "rgba(0, 0, 0, 0.4)"
  text-primary: "#FFFFFF"
  text-secondary: "rgba(255, 255, 255, 0.7)"
  text-muted: "rgba(255, 255, 255, 0.6)"
  accent-hub: "#EC4899"
  accent-office: "#60A5FA"
  border-light: "rgba(255, 255, 255, 0.2)"
  border-dim: "rgba(255, 255, 255, 0.1)"
typography:
  heading:
    family: "Inter, system-ui, sans-serif"
    size: "1.5rem"
    weight: "700"
  body:
    family: "Inter, system-ui, sans-serif"
    size: "0.875rem"
    weight: "400"
  label:
    family: "Inter, system-ui, sans-serif"
    size: "0.75rem"
    weight: "500"
spacing:
  xs: "4px"
  sm: "8px"
  md: "12px"
  lg: "16px"
  xl: "20px"
rounded:
  sm: "4px"
  md: "8px"
  lg: "16px"
  full: "999px"
components:
  globe_container:
    position: "relative"
    height: "16rem"
    overflow: "hidden"
  glass_card:
    backdrop_blur: "20px"
    border: "1px solid"
    shadow: "2xl"
  legend_chip:
    bg: "rgba(0, 0, 0, 0.3)"
    padding: "8px"
    blur: "12px"
motion:
  globe_rotation: "0.003 rad/frame"
  interaction: "smooth-scroll"
---
## Overview
The Aura Globe system is designed for immersive data visualization. It prioritizes the relationship between a high-contrast dark background and translucent foreground elements to create a sense of deep space and technical sophistication.

## Colors
The palette is rooted in a deep Slate base (#111827). Interactive and highlight colors use vibrant pinks and blues to stand out against the dark canvas. Transparency is used extensively to define hierarchy through opacity rather than just hex values.

## Typography
San-serif faces are required for technical clarity. Headings use bold weights to anchor the eye, while secondary data labels utilize reduced opacity (70% and 60%) to establish a clear information architecture.

## Spacing
A tight spacing scale ensures that data remains compact and dashboard-ready. The system uses a 4px base increment with primary inner padding set at 20px (1.25rem).

## Layout
Layouts use a stacked approach. The background layer contains the WebGL canvas, the midground contains floating UI controls or legends, and the foreground (bottom) contains contextual text descriptions. This Z-axis separation is critical for readability over dynamic backgrounds.

## Elevation & Depth
Depth is achieved through `backdrop-filter: blur()`. Standard containers use a 20px blur to separate interface elements from the moving 3D globe geometry behind them.

## Shapes
Containers use a 16px corner radius for a modern, friendly feel. Smaller interface elements like legend chips use an 8px radius. Indicator pips for the globe must be perfectly circular (999px).

## Components
- **Interactive Globe**: A full-bleed WebGL element that serves as the visual centerpiece.
- **Glass Card**: The primary wrapper using semi-transparent white backgrounds and blur effects.
- **Status Legend**: Floating indicators with colored pips to categorize map data.
- **Data Footer**: A high-contrast dark section (40% black) for textual details and summary data.

## Motion
The globe should maintain a constant, slow rotation (phi increment) to suggest live activity. Avoid jarring transitions; interactions with the globe should feel fluid and momentum-based.

## Do's and Don'ts
- **Do** use white text with variable opacity for hierarchy.
- **Do** ensure the 3D globe has sufficient contrast against its container.
- **Don't** use solid, opaque backgrounds for floating UI elements.
- **Don't** use borders thicker than 1px for glass components.

## Accessibility
Maintain a minimum contrast ratio for text labels against blurred backgrounds. Use ARIA labels on the canvas to describe the current state or focus of the visualization for screen readers.