Recreate the website "Creative Digital Designer Portfolio" as a high-fidelity Tailwind CSS and JavaScript landing page. The design is a dark, motion-rich, and premium portfolio template.

### CRITICAL FIDELITY CONSTRAINTS
- **Dark Mode Mandatory**: Page background must be literal `#000000`. Text must use white and shades of zinc/gray.
- **Animation System**: All sections must use the `animate-on-scroll` class coupled with the `fadeSlideIn` keyframe. Sections should initialize as `animation-play-state: paused` and switch to `running` via an IntersectionObserver when 20% visible.
- **Border Gradient Pattern**: Several components (Nav, Pricing Grid) use a custom `--border-gradient` implementation with a mask-composite technique to create high-definition 1px borders.
- **Asset Accuracy**: Use exact Unsplash URLs for testimonials and team profiles. Use Lucide icons and Simple Icons as specified.

### TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN)
- Lucide Icons (CDN)
- Iconify (CDN) for brand logos
- UnicornStudio.js (v1.4.29) for the main hero background effect
- Google Fonts: 'Inter', 'Geist', 'Manrope' (Main titles), 'Newsreader' (Strategic text)

### GLOBAL STYLE
- **Typography**: `font-family: 'Inter', sans-serif;`. Headers use `font-family: 'Manrope', sans-serif;` with tight tracking.
- **Selection**: `selection:bg-red-600/30 selection:text-red-200`.
- **Top Blur**: A `gradient-blur` fixed overlay at the top using 7 layers of increasing `backdrop-filter: blur()` values (0.5px to 64px).

### ASSET MAP
- **Hero Background**: [Unicorn Studio Project ID: sajpUiTp7MIKdX6daDCu]
- **Testimonial 1 (Sarah)**: https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop
- **Testimonial 2 (Michael)**: https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop
- **Testimonial 3 (David)**: https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop
- **Team (Sarah Park)**: https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop

### LAYER STACK / POSITIONING MAP
- **Background**: `aura-background-component` (absolute, z-index -10, 800px height) with a linear-gradient mask.
- **Nav**: `fixed`, z-index 50, top-0. Inner container `backdrop-blur-lg`, `bg-black/60`.
- **Hero Section**: `min-h-screen`, `pt-32`, relative.
- **Bento Grid**: `grid-cols-1 lg:grid-cols-6` with relative cards.

### SECTION-SPECIFIC DETAILS

**1. NAVIGATION**
- Floating pill shape. Includes link items: Work, Services, About, Contact.
- **CTA**: "Book Call" button with a `conic-gradient` red beam animation that rotates on hover (`animate-[spin_3s_linear_infinite]`).

**2. HERO SECTION**
- **Badge**: "Available for new projects" with a pulsing red dot.
- **Headline**: "Design your vision with creative excellence". Uses a 4-step gradient: `bg-gradient-to-b from-white via-white to-white/50`. Words are staggered in `<span>` tags for animation.
- **CTAs**: Two distinct buttons.
  - "View Portfolio": Uses a multi-layer radial gradient glow (Stroke vs Stroke Hover) that transitions opacity over 1200ms on hover.
  - "Contact Me": Uses a rotating gradient border and a skewed white sweep effect that slides across on hover.
- **Logo Scroller**: Infinite horizontal scroll of brand logos (git, npm, Wrike, etc.) using `animate-infinite-scroll` (40s linear). Grayscale by default, full color on hover.

**3. FEATURES (BENTO GRID)**
- Card 1 (Brand Identity): Large "Aa" text with an absolute positioned "Start Project" button containing a custom star SVG path.
- Card 2 (Web Design): Floating UI card component that translates -1rem on Y-axis on hover.
- Card 3 (Art Direction): Toggle-style UI showing "Cinematic" (active) vs "Minimalist" (40% opacity).
- Card 4 (Strategy): Blurred background text with an "Approve" button overlay.
- Card 5 (Content Production): Centered text "Create with passion" with a pulsing vertical red cursor bar.

**4. TESTIMONIALS (MASONRY)**
- Giant background text "REVIEWS" at 15vw with 2% opacity.
- Grid of 3 columns. Center column is offset `md:pt-12`.
- Cards use `backdrop-blur-sm` and `border-dashed` styles. Featured card (Michael Chen) uses a `text-xl` font and quotes icon.

**5. PRICING GRID**
- Three tiers: Growth ($7,500), Scale ($15,000), Custom ($10k+).
- "Scale" card is the "Most Popular" with a red label and subtle background glow.
- Toggle switch for Monthly/Quarterly (Stylistic only).

**6. CONTACT FORM**
- Minimalist inputs: Bottom-border only (`border-b`).
- Floating labels using Tailwind `peer-placeholder-shown` logic that shrink and turn red on focus.

**7. FOOTER**
- High-impact layout with a 14vw-wide "CREATIVE" text footer using `-webkit-text-stroke: 1px`.
- Custom logo icon: 2x2 grid of colored squares (Red, Zinc-700, Zinc-800, White).
- Links are categorized under "Map", "Company", and "Legal".

### GLOBAL ANIMATION / INTERACTION RULES
- **Scroll Scrubbing**: Use an IntersectionObserver to toggle the `.animate` class.
- **Hover States**: Every interactive element must have a `transition-all duration-300` or higher. Scale-down on active click (`active:scale-95`).
- **Shiny CTA CSS**: Implement `@property --gradient-angle` to allow CSS transitions on conic-gradient angles for the shiny border effect.

### IMPLEMENTATION REQUIREMENTS
- Build exactly as described with no deviations in color or spacing.
- Use the exact SVG paths for the rotating border and star icons provided in the source.
- Ensure all `border-dashed` classes use the `border-zinc-800` color for a subtle grid feel.