Recreate the website "Canvas - Visual Synthesis" with high visual fidelity as a Tailwind CSS and Vanilla JS site. The result must match the supplied reference website exactly, including its brutalist tech-aesthetic and parametric layout logic.

Preserve source quirks:
- The horizontal scroll container for "System 2.0" uses hidden scrollbars via `-ms-overflow-style: none` and `scrollbar-width: none`.
- The large "CANVAS" watermark in the footer uses `text-[20vw]` with a negative bottom margin of `-mb-12` to clip into the floor.
- The custom SVG logo uses a 10-second linear infinite spin animation.

CRITICAL FIDELITY CONSTRAINTS
- Background pattern must use the specific `.grid-bg` linear-gradient logic with a radial-gradient mask.
- All "floating-card" elements must have `perspective-[1000px]` on the parent and specific `rotate` transforms (e.g., -2deg, -6deg, 3deg, 12deg).
- Hover states on cards must include `scale(1.1) translateY(-10px)` and a z-index jump to 50.
- Navigation and Section transitions must use the `fadeSlideIn` keyframe animation (30px translateY to 0) with specific staggered delays (0s to 1s).

TECH STACK / DEPENDENCIES
- CSS: Tailwind CSS (CDN), Google Fonts (Inter, Space Grotesk).
- Icons: Iconify (solar, simple-icons).
- Animation: Custom CSS Keyframes, Intersection Observer for `.animate-on-scroll` triggers.

GLOBAL STYLE
- Body: `#050505` background, `text-neutral-300`, selection highlight `#F97316`.
- Typography: Headlines in `font-medium` white; Mono accents for Fig/SYS labels.
- Custom Beam Borders: `.beam-border-v` and `.beam-border-h` with pseudo-elements animating a gradient drop/slide using `cubic-bezier(0.4, 0, 0.2, 1)`.

ASSET MAP
- Hero Centerpiece: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/ba85e313-0a22-4811-b7e0-1e6a9943d09b_800w.webp
- Hero Float 1: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/1d62b373-cc7d-4f73-b0bd-e8a8ec3e260a_800w.webp
- Hero Float 2: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/63a6abea-fa7c-44e7-b134-9d70239f3d3f_800w.webp
- Hero Float 3: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/917d6f93-fb36-439a-8c48-884b67b35381_1600w.jpg
- Hero Float 4: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/43de405d-d7b1-490b-ae4b-52e1fa3e00f8_800w.webp
- Carousel 1: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/92f79571-c9ab-4ba6-827b-8845c8060486_800w.webp
- Carousel 3: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/3b89a5fb-be9e-41e8-8e44-6630812764c9_800w.webp

VECTOR / ICON SHAPES
- Primary Accent Color: `#F97316`.
- Custom Logo: `simple-icons:abstract` with mixed opacity paths.
- Download Button: `solar:file-download-bold-duotone` with shimmer effect.

LAYER STACK / POSITIONING MAP
1. Background Layer (z-10): `aura-background-component` with `saturate-0 brightness-50 mix-blend-screen` and the `.grid-bg` overlay.
2. Midground Layer (z-0): Floating cards with absolute positioning and 3D transforms.
3. Foreground Layer (z-20): Hero text, stats, and section headlines.
4. Overlay Layer (z-40): "Why is it free?" card.
5. Navigation Layer (z-50): Sticky-ready nav with beam border.

SECTION 1 - NAVIGATION
- Flex container, `px-6 py-6`. Logo on left, links center, Shimmer Button on right.
- Shimmer Button: Uses a `conic-gradient` rotating inside an inset-[-100%] container to create a border-beam effect.

SECTION 2 - HERO
- Grid: `lg:grid-cols-12`. Left (5 cols): H1 "Visual Synthesis" (7.5rem), P text, CTA with corner accents. Center (5 cols): Floating canvas stack. Right (2 cols): Stats with vertical beam border.

SECTION 3 - MANIFESTO & METRICS
- Background: `#050505` with large ambient blur circles (`blur-[120px]`).
- Text: Large leading manifesto. Metric grid with 4 items; items transition from `text-neutral-700` to `#F97316` on group hover.
- Footer: 5 specific tech brand icons (Adobe, Vercel, Stripe, Linear, Raycast) at 40% opacity grayscale.

SECTION 4 - SYSTEM 2.0 CAROUSEL
- Header: Title and interactive arrow buttons (Solar icons).
- Container: `flex overflow-x-auto` with `gap-6`.
- Cards: 4:3 aspect ratio, `grayscale group-hover:scale-110` image effects, mixed with abstract UI overlays (mono labels, progress bars).

SECTION 5 - FOOTER
- Newsletter Pill: Rounded-full, floating, transitions to `#F97316` border.
- "Build. Ship. Iterate." H2 at `text-[6rem]`.
- Bottom: Yellow card (`#F97316`) with black text, absolute-positioned `solar:code-square-bold-duotone` icon rotated 12deg.
- Watermark: "CANVAS" in `Space Grotesk`, `text-white/5` at the very bottom.

GLOBAL ANIMATION / INTERACTION RULES
- Intersection Observer: Adds `.animate` class to items with `.animate-on-scroll` to set `animation-play-state: running`.
- Hover Transforms: Cards must use `transition: transform 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94)`.

COMMON MISTAKES TO AVOID
- Do not use standard rounded corners; the style is brutalist/sharp except for specific pills.
- Do not substitute the grid background with a simple CSS grid; use the specific background-image + mask-image provided.
- Do not miss the corner accents on the "Start Creating" button.