---
version: 1.0.0
name: Luminous Visual System
description: A futuristic dark-mode system characterized by orange glows, translucent glass surfaces, and dynamic data visualizations.
colors:
  background: "#050505"
  surface: "#0A0A0A"
  surface-light: "#181824"
  primary: "#f97316"
  primary-glow: "rgba(249, 115, 22, 0.3)"
  accent-yellow: "#fde047"
  neutral-text: "#a3a3a3"
  white: "#ffffff"
  border: "rgba(255, 255, 255, 0.1)"
typography:
  display:
    family: "Bricolage Grotesque"
    weight: "300"
    tracking: "-0.02em"
  body:
    family: "Inter"
    weight: "400"
    size: "16px"
  label:
    family: "Inter"
    weight: "500"
    size: "12px"
    transform: "uppercase"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "40px"
  section: "96px"
rounded:
  sm: "4px"
  md: "8px"
  lg: "12px"
  xl: "16px"
  card: "32px"
  full: "999px"
components:
  nav:
    background: "rgba(255, 255, 255, 0.05)"
    backdrop: "blur(12px)"
    border: "1px solid rgba(255, 255, 255, 0.1)"
  glass-card:
    background: "#0A0A0A"
    border: "1px solid rgba(255, 255, 255, 0.1)"
    shadow: "0 20px 60px rgba(0, 0, 0, 0.8)"
  glow-button:
    gradient: "linear-gradient(to top, #fed7aa, #f97316, #ea580c)"
    shadow: "0 0 40px rgba(249, 115, 22, 0.6)"
  stat-pill:
    background: "rgba(249, 115, 22, 0.1)"
    text: "#f97316"
    rounded: "4px"
motion:
  entry: "fadeInUpBlur 1s cubic-bezier(0.2, 0.8, 0.2, 1)"
  hover: "scale(1.05) transition 300ms"
  orbit: "spin 60s linear infinite"
---
## Overview
Luminous is a high-contrast dark design system designed for AI-driven platforms. It emphasizes depth through tiered layering (background stars, midground glows, foreground glass) and a high-energy orange-to-amber primary palette.

## Colors
- **Core Palette**: The interface rests on a near-black `#050505` background. Primary actions use an orange-to-amber gradient.
- **Depth Glimmers**: Subtle orange blur effects (80px to 120px) are used behind major cards and hero sections to simulate localized light sources.
- **Status Colors**: Live indicators use Pulsing Green, while viral metrics use Orange.

## Typography
- **Headlines**: Use `Bricolage Grotesque` at light weights (300) with tight tracking to create a sophisticated, editorial tech aesthetic.
- **UI/Copy**: `Inter` handles all functional text, ensuring legibility on dark surfaces.
- **Data Mono**: Use monospace for code-style metric readouts in growth panels.

## Spacing
- Standardized 8px grid system.
- Section margins are generous (96px+) to allow the glowing background effects room to breathe without cluttering the UI.

## Layout
- **Layer Stack**:
  1. Fixed background (Stars/Radial Glows).
  2. Midground content panels with `backdrop-blur` and low-opacity borders.
  3. Floating overlays and CTA buttons with high z-index and inner shadows.
- **Dashboard Grid**: Uses a 12-column layout. Sidebars are `hidden` on mobile and flex to `col-span-2/3` on desktop.

## Elevation & Depth
- **The Electric Card**: Cards use a 2px padding container with a linear-gradient border and an inner `rgba(249, 115, 22, 0.3)` box shadow to create a "powered" appearance.
- **Grid Overlay**: A subtle `1px` white grid at 5% opacity is used in showcase sections to ground floating elements.

## Shapes
- **Hyper-Rounded**: Major cards use `32px` corner radii. UI buttons and secondary badges use `999px` (pill shape).
- **Geometry**: Asterisk-shaped logos and hexagonal/circular patterns represent AI nodes.

## Components
- **Orbital Menu**: A central logo surrounded by icons rotating at 60s intervals with counter-rotating children to maintain orientation.
- **Metric Sparklines**: SVG paths with linear-gradient fills (`f97316` to transparent) for real-time data visualization.
- **Interactive Plan Selector**: A three-way stack that uses animated dashed SVG paths to connect selection buttons to a central details card.

## Motion
- **Blur Entry**: Every major section must use an `animate-entry` which combines a translateY(20px) with a blur(10px) to opacity:1 transition.
- **Pulsing States**: Live metrics must include a pinging dot animation (`animate-ping`).
- **Flow Paths**: Dashed borders or connecting lines use `stroke-dashoffset` animation to show directional energy flow.

## Do's and Don'ts
- **Do**: Use inner shadows and border-top gradients to simulate top-down lighting on buttons.
- **Do**: Use `selection:bg-orange-500/30` for custom browser highlight styles.
- **Don't**: Use solid white borders; always use low-opacity white (5-10%) to maintain the dark-mode depth.
- **Don't**: Use heavy drop shadows; prefer blur-based glow effects in the background layers.

## Accessibility
- Maintain a minimum of 4.5:1 contrast ratio between `neutral-text` and background.
- Ensure all interactive buttons have `sr-only` labels for screen readers, especially custom toggle switches.
- Decorative animations (stars/orbits) should respect `prefers-reduced-motion` settings.