Recreate the website "Arcade AI / AuraGen" with high visual fidelity as a Tailwind CSS-based landing page.

The result must match the supplied reference website, not a cleaned-up reinterpretation.

Preserve source quirks:
- Unusual use of `mask-image` on almost every text container, often using linear gradients that fade sections out even when they are fully visible (e.g., `linear-gradient(290deg, transparent, black 0%, black 40%, transparent)` on the H1).
- 3D perspective distortion on the Feature/Dashboard section using a custom `rotate-x-5` class.
- Mix of multiple Google Font families (Geist, Roboto, Montserrat, Poppins, Playfair Display, Instrument Serif, Merriweather, Bricolage Grotesque, Plus Jakarta Sans, Manrope, Space Grotesk, Work Sans, PT Serif, Geist Mono, Space Mono, Quicksand, Nunito, Inter).
- Duplicate carousel groups for the seamless loop logo bar.

CRITICAL FIDELITY CONSTRAINTS
- The page uses a complex `gradient-blur` fixed overlay at the top composed of 6 nested `backdrop-filter: blur` divs with varying mask-image percentages.
- Background uses a Unicorn Studio project container (`data-us-project="1bY8o6HVTI1oxJxuCJEG"`) with a specific alpha mask.
- Selection color must be `selection:bg-fuchsia-500/30`.
- Every section title uses a specific `mask-image` linear gradient applied directly in the style attribute.

TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN: https://cdn.tailwindcss.com)
- Lucide Icons (CDN: https://unpkg.com/lucide@latest)
- Unicorn Studio (JS: https://cdn.jsdelivr.net/gh/hiunicornstudio/unicornstudio.js@v1.4.31/dist/unicornStudio.umd.js)
- Inter Font for specialized CTAs.

GLOBAL STYLE
- Body: `bg-slate-950`, `text-white`, `antialiased`, `font-geist` (default).
- Custom 3D Utilities: Implement `rotate-x-5` and `perspective-none` as defined in the source config.
- Shiny CTA: Implement the complex `@property` CSS for the `--gradient-angle` animated border button.

ASSET MAP
- Logo: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/d3473923-ebc4-44bd-a2b8-bcf5197f648b_800w.png`
- Dashboard Grid Images: `e230abf5-bdd2...`, `dbdc5b42-1ade...`, `d84e4a08-d7bc...`, `bd7142dc-e78f...` (from ASSET MAP).
- Partner Logos: `e5f2922d...`, `92287bc0...`, `8284c62f...`, `3764a6eb...`, `dea31d52...`, `b16a9cf6...`
- Gallery/Creation Images: Use the 10+ specific Supabase URLs for images like "Cyberpunk City", "Fantasy Landscape", "Zen Workspace", etc.

LAYER STACK / POSITIONING MAP
- Background: `aura-background-component` (absolute, z-10, h-900px) + Unicorn Studio canvas (absolute, w-full, h-full).
- Global Overlay: `gradient-blur` (fixed, z-5, top-0, h-12%).
- Nav: `sticky`, `z-20`, `top-0` with `backdrop-blur` on mobile drawer.
- Dashboard Section: `rotate-x-5` transform applied to the container with a nested `backdrop-blur-xl` panel.

SECTION 1 - NAVBAR
- Brand: 120x30px logo.
- Links: Features, Gallery, Reviews, FAQ.
- CTA: "Get Started" with Lucide `arrow-right`.
- Mobile: Slide-out drawer from right (`translateX(100%)`) with `backdrop-blur`.

SECTION 2 - HERO
- Heading: "Where imagination meets artificial intelligence" (mask-image: 290deg gradient).
- Buttons: Shiny CTA "Try AuraGen" + Ghost button "See Demo".
- Interactive: Hover-blur effects on images.

SECTION 3 - INTERACTIVE DASHBOARD
- Style: MacOS-style title bar with grey dots.
- Sidebar: Left nav with "Generate", "Gallery", "Community", and "Explore".
- Main Panel: 4-grid generation results with download/like buttons on hover.
- Prompt Bar: "Describe the image..." textarea with "Generate (4 credits)" button.
- Right Panel: Settings sidebar (Model, Aspect Ratio, Quality, Style Preset).

SECTION 4 - LOGO CAROUSEL
- Animation: `smoothCarousel` 40s linear infinite.
- Content: Two sets (Group A/B) of 6 partner logos with `mix-blend-screen` and `hover:scale-110`.

SECTION 5 - FEATURE SUITE
- Layout: 3-column grid followed by a 2-column grid.
- Content: Text to Image, Image to Image, API Access, Lightning Fast, Safe & Secure.
- Visuals: Lucide icons in rounded square badges.

SECTION 6 - STUNNING CREATIONS (MASONRY)
- Layout: `columns-1 sm:columns-2 lg:columns-3 xl:columns-4` gap-4 masonry.
- Hover State: `grayscale` images that turn full color on hover with a "Collect" button appearing top-right.

SECTION 7 - TESTIMONIALS (DOUBLE MARQUEE)
- Row 1: `marquee-ltr` (left to right).
- Row 2: `marquee-rtl` (right to left).
- Cards: 420px width, `bg-zinc-900/40`, specific user avatars.

SECTION 8 - FAQ & FOOTER
- FAQ: Grid layout with custom JS toggle (display: block/none) and plus/minus icons.
- Footer: 4 columns (Brand, Product, Company, Resources) + Newsletter signup.

GLOBAL ANIMATION / INTERACTION RULES
- Marquee speed: 45s per cycle.
- Hover state on creation cards: `transition-all duration-300`, `grayscale-0`.
- Menu transition: `transform 0.3s ease-out`.

IMPLEMENTATION REQUIREMENTS
- Build the landing page exactly as seen in the source.
- Use the provided SVGs for all custom paths (especially the divider line in Hero and complex icons).
- Maintain the exact image filter states (grayscale 100% on dashboard samples).
- Do not substitute Lucide icons with others.