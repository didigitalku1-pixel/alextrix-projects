---
version: "3.0.0"
name: "Gemini 3 Motion"
description: "Architecture-inspired monotone system with 3D transforms, glass panels, and kinetic typography."
colors:
  bg-deep: "#050505"
  neutral-950: "#0a0a0a"
  neutral-900: "#171717"
  neutral-800: "#262626"
  neutral-600: "#525252"
  neutral-500: "#737373"
  neutral-400: "#a3a3a3"
  neutral-300: "#d4d4d4"
  white: "#ffffff"
  glass-white: "rgba(255, 255, 255, 0.08)"
typography:
  display:
    family: "Inter"
    weight: "600"
    size: "6rem"
    tracking: "-0.05em"
  heading:
    family: "Inter"
    weight: "500"
    size: "3rem"
    tracking: "-0.025em"
  body:
    family: "Inter"
    weight: "300"
    size: "1rem"
    lineHeight: "1.625"
  mono:
    family: "Space Mono"
    weight: "400"
    size: "0.75rem"
    tracking: "0.25em"
spacing:
  none: "0px"
  xs: "8px"
  sm: "16px"
  md: "32px"
  lg: "48px"
  xl: "80px"
rounded:
  none: "0px"
  sm: "2px"
  md: "8px"
  lg: "16px"
  full: "9999px"
components:
  header:
    position: "fixed"
    z-index: "60"
    background: "rgba(0,0,0,0.4)"
    blur: "12px"
  slide-container:
    snap-type: "y mandatory"
    scroll-behavior: "smooth"
    size: "100vh"
  glass-card:
    aspect: "3/4"
    backdrop-filter: "blur(20px)"
    border: "1px solid rgba(255,255,255,0.1)"
  shimmer-button:
    shape: "pill"
    animation: "shimmer"
    interaction: "hover-rotate-beam"
  flashlight-panel:
    interaction: "mouse-follow-gradient"
    blend-mode: "overlay"
motion:
  in-view:
    animation: "animationIn"
    duration: "0.8s"
    timing: "cubic-bezier(0.16, 1, 0.3, 1)"
  infinite:
    name: "marquee"
    duration: "40s"
    timing: "linear"
---
## Overview
Gemini 3 is a monotone-first design system utilizing deep neutrals and high-contrast typography to emphasize motion physics. It focuses on the relationship between spatial depth (3D transforms) and transparency (glassmorphism).

## Colors
The palette is strictly grayscale, utilizing the neutral-950 and bg-deep (#050505) for background depth. Foreground elements use varying opacities of white and neutral-300 to create hierarchy without color.

## Typography
Features a high-contrast pairing of Inter (Sans-serif) and Space Mono (Monospaced). Large display text uses negative letter-spacing (-0.05em) and tight line-height (0.9) to appear architectural.

## Spacing
A rigid spacing scale based on 8px increments. Larger sections utilize 80px (xl) padding, while internal card components maintain 24px-32px containers.

## Layout
Layouts are structured around a centered 3:4 aspect ratio glass panel (max-width: 36rem). The system uses `snap-y mandatory` for full-screen vertical scrolling. Backgrounds use `object-fit: cover` and absolute positioning for layering depth.

## Elevation & Depth
Depth is achieved through `backdrop-filter: blur(20px)` and radial-gradients. Flashlight effects (radial-gradient following cursor) create a sense of tactile interaction with background layers.

## Shapes
Primary containers and layouts use square (0px) corners to maintain a brutalist/architectural feel. Interactive elements like buttons and navigation dots utilize pill/circle (9999px) shapes to distinguish touchpoints.

## Components
- **Fixed Header**: Sticky top navigation with 40% black opacity and high z-index (60).
- **Shimmer Button**: A pill-shaped CTA with a conic-gradient beam rotating at 2s duration.
- **Flashlight Card**: Interactive panels that reveal a light source on hover.
- **Marquee Logos**: An infinite horizontal ribbon for social proof using alpha masking for edge fading.
- **Vertical Scroller**: A custom scroll container with hidden scrollbars and navigation dot indicators.

## Motion
- **Entrance**: `animationIn` combines a 30px Y-translation with a 10px blur-to-zero transition.
- **Beam**: A 1px border shimmer using a conic-gradient spinning at linear speed.
- **3D Transform**: Active cards use `perspective-1000` with subtle `scale(1.02)` on hover.
- **Clip-Path**: Text reveals use vertical slide-downs with staggered delays.

## Do's and Don'ts
- **Do**: Use font-weight: light (300) for body descriptions.
- **Do**: Use 1px borders with white/10 opacity for glass definitions.
- **Don't**: Introduce accent colors; hierarchy must be achieved through font size and opacity.
- **Don't**: Use rounded corners on main section panels or structural glass cards.

## Accessibility
- Use `selection:bg-white/20` for text highlights to maintain contrast.
- Navigation dots must include `aria-label` for screen reader index identification.
- Motion should respect `prefers-reduced-motion` where possible, though the system is motion-centric.