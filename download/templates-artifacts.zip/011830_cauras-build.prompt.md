Recreate the website "Cauras" with high visual fidelity as a Tailwind CSS/HTML site. The result must match the supplied reference website, not a reinterpretation.

Preserve source quirks:
- Unusual use of multiple stacked mask-image linear gradients on nearly every major section heading to create a faded typography effect.
- The "UI Mockup" section uses a literal `rotate-x-5` transform and `perspective-none` to create a tilted canvas effect.
- Inconsistent icon usage: some Lucide icons are used while others are custom SVGs with hardcoded paths.
- The marquee animation in the testimonials section requires exact naming: `marquee-ltr` and `marquee-rtl`.
- A specific "Gradient Blur" fixed header component with 6 layers of progressive backdrop-filters (0.5px to 64px).

CRITICAL FIDELITY CONSTRAINTS
- Backgrounds: Use the exact absolute-positioned `aura-background-component` with the specific mask-image gradient for top-fade.
- Typography: Headlines must use the specific mask-gradient logic (e.g., `mask-image: linear-gradient(290deg, transparent, black 0%, black 40%, transparent)`).
- Pricing Toggle: Must include the JS logic for the sliding `translateX(100%)` indigo indicator.
- Testimonials: Must be a infinite marquee loop, not a static grid.

TECH STACK / DEPENDENCIES
- CSS: Tailwind CSS (CDN), Custom CSS for 3D transforms (`rotate-x-5`, `perspective-midrange`).
- Icons: Lucide Icons (`lucide@latest`), Custom SVG paths for brand-specific icons.
- Fonts: Geist, Inter, Roboto, Montserrat, Poppins, Manrope, Plus Jakarta Sans (via Google Fonts).
- Animation: UnicornStudio runtime script (`unicornStudio.umd.js`) for background effects.

GLOBAL STYLE
- Body: `bg-slate-950`, `text-white`, `antialiased`, `selection:bg-blue-500/30`.
- Headers: Font `font-geist`, `tracking-tighter`.
- Layout: Max-width containers at `max-w-7xl`.

ASSET MAP
- Logo PNGs:
  - https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/e5f2922d-4fb6-4f7c-8795-cd9ba63105a4_1600w.png
  - https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/92287bc0-bc70-4864-bf05-a89c1b99a218_1600w.png
  - https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/8284c62f-bfed-4d35-aaa2-956d0a8969b3_1600w.png
- Showcase Thumbnails:
  - Portfolio: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/286dcc4a-3b11-43d3-af80-a7b1c3aaaad1_800w.webp
  - SaaS: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/bb9b217e-05c2-4e6e-8f35-3fcb7f5b5e0c_800w.webp
- Avatars:
  - Ava: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/e0bbf4a4-5f58-4644-bea6-85d2fef73d4a_320w.jpg

LAYER STACK / POSITIONING MAP
- LAYER 1 (Bottom): `aura-background-component` (Absolute, -z-10, h-[840px]).
- LAYER 2: `gradient-blur` (Fixed, z-5, 6-div blur stack).
- LAYER 3: Main content sections (`relative`).
- LAYER 4: Navigation (Sticky, z-20).
- LAYER 5 (Top): Mobile Menu Drawer (Fixed, z-50).

SECTION 1 - NAVIGATION
- Sticky header with blur. Left: Text logo "Cauras". Center: Links (Features, Templates, Showcase, Pricing). Right: "Open App" pill button with `ring-1 ring-white/10`.
- Mobile: Hamburger menu (lucide-menu) triggers 80% width right-side drawer.

SECTION 2 - HERO
- Text: "Design and publish your dream site." (Size: 8xl, Geist font, 290deg linear mask).
- CTA: "Shiny CTA" button with custom @property animation (border-spin) and conic-gradient border.
- Interaction: Watch Video button with Lucide `play-circle` icon.

SECTION 3 - UI MOCKUP CANVAS
- Container: `rotate-x-5`, `perspective-none`.
- Visuals: Recreate a Figma-like interface with a Left Sidebar (Layers), Center Canvas (Editor), and Right Sidebar (Properties).
- Editor Layer: Absolute blue border with corner handles and a floating "H1 Heading" badge.
- Properties: Grid of input fields (X, Y, W, H) and Typography settings with white color picker swatch.

SECTION 4 - FEATURE CARDS
- 3-Column Grid: Visual Editing, Animation, Performance.
- Style: `bg-gradient-to-br from-neutral-900/80 to-neutral-950/90`, `border-white/10`.
- Special FX: Card 3 has a Radar Sweep animation (`animate-[radar81_4s_linear_infinite]`) using a `conic-gradient` mask.

SECTION 5 - PRICING
- Toggle: Custom JS-controlled switch with an indigo sliding background pill.
- Cards: 3 tiers. Middle card (Pro) has a purple/cyan background glow (`blur-3xl`) and "Popular" badge.
- Pricing Logic: JS must update `.pricing-amount` text content between $29/$24 based on isYearly state.

SECTION 6 - TESTIMONIAL MARQUEE
- Animation: CSS keyframes `marquee-ltr` moving from `translateX(-50%)` to `0`.
- Style: Articles use `bg-zinc-900/40` and `border-zinc-900`. Edge fading via absolute gradients (zinc-950 to transparent).

GLOBAL ANIMATION / INTERACTION RULES
- Nav Link Hover: Pseudo-element `::after` expands width from 0 to 100%.
- Card Glow: On hover, cards lift `translateY(-2px)` and inner glow opacities increase to 1.
- FAQ logic: Accordion style where `.faq-trigger` toggles visibility of `.faq-content` and swaps SVG innerHTML between plus/minus.

IMPLEMENTATION REQUIREMENTS
- Build as a single-page landing site.
- Use the exact IDs: `billing-toggle-container`, `toggle-indicator`, `menuBtn`, `closeMenuBtn`.
- Preserve the exact layout of the footer with 4 columns (Product, Company, Resources, Social Icons).
- Ensure all `mask-image` styles are preserved with `-webkit-` prefixes for Safari compatibility.