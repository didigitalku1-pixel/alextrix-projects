---
version: 4.0.2
name: Nexus-OS
description: Futuristic enterprise AI infrastructure branding with a focus on deterministic compute and synthetic cognition.
colors:
  accent: "#FF3B00"
  surface: "#0F0F0F"
  background: "#050505"
  border: "rgba(255, 255, 255, 0.08)"
  text-primary: "#FFFFFF"
  text-secondary: "#E0E0E0"
  text-muted: "#9CA3AF"
  success: "#22C55E"
  danger: "#EF4444"
typography:
  display:
    family: "Space Grotesk"
    weight: 700
    tracking: "-0.05em"
  sans:
    family: "Inter"
    weight: 400
    tracking: "normal"
  mono:
    family: "JetBrains Mono"
    weight: 500
    tracking: "0.1em"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "32px"
  xxl: "64px"
rounded:
  none: "0px"
  sm: "4px"
  md: "8px"
  lg: "12px"
  xl: "16px"
  full: "9999px"
components:
  nav: "Fixed top-0, 80px height, 80% opacity background with 12px blur."
  buttons: "Magnetic hover effects, 1px borders, uppercase text, monospace tracking."
  glass-panel: "1px solid white/8% border, 12px backdrop blur, relative positioning."
  spotlight-card: "Radial gradient follows mouse pointer, opacity transition on hover."
  bento-grid: "Responsive 4-column layout on desktop, variable row spans (1-2x)."
  code-block: "Gradient glow border (accent to purple), JetBrains Mono font, line-height 1.5."
motion:
  scramble: "Text character cycling on intersection for headings."
  marquee: "30s linear infinite horizontal translation for partner logos."
  scan-line: "3s vertical linear gradient animation for active processing panels."
  skew: "Liquid scroll effect applying 0.1x velocity as skewY degrees."
---
## Overview
Nexus-OS is a high-contrast, technical design system. It uses a "terminal-chic" aesthetic to convey reliability and speed. The system relies on deep blacks, sharp accents of high-energy orange, and microscopic typography detail.

## Colors
The palette is dominated by #050505 to ensure maximum contrast for the #FF3B00 accent color. Translucent layers (white/5% to white/10%) are used to create depth without introducing secondary gray hues.

## Typography
Hierarchy is established through font family shifts rather than just size. Space Grotesk is reserved for massive display headers. Inter handles readability for body copy. JetBrains Mono is utilized for all UI labels, system statuses, and navigation items.

## Spacing
A strict grid system is ignored in favor of large-scale section padding (24-32rem) and tight internal component spacing (8-16px) to mimic specialized hardware interfaces.

## Layout
Layouts utilize a "Bento Box" approach for features and a sticky split-view for process pipelines. Components are frequently positioned with absolute overlays (scan lines, noise, grids) to add texture.

## Elevation & Depth
Depth is achieved through backdrop filters and z-index stacking rather than shadows. The `glass-panel` class provides a consistent Z-axis layer. A fixed noise overlay at 4% opacity is used to unify the foreground.

## Shapes
Corner radii are mixed: container panels use `rounded-xl` (16px), while tactical elements like buttons and status badges use sharp `none` or `sm` (4px) radii to maintain a technical edge.

## Components
- **Nav**: Minimalist with 10px monospace status indicators.
- **Hero**: Scrambled text headers and absolute-centered 3D backgrounds.
- **Spotlight Cards**: Interactive containers with CSS variable-driven mouse tracking.
- **Pipeline**: Sticky left-column visual with a scrollable right-column narrative.

## Motion
Motion is purposeful and mechanical. Use `gsap` for scroll-triggered skewing and `lenis` for smooth inertial scrolling. Elements should fade and slide from `y: 30` on enter.

## Do's and Don'ts
- **Do**: Use uppercase and letter-spacing for all monospace labels.
- **Do**: Use 1px borders for separation instead of drop shadows.
- **Don't**: Use rounded corners on code blocks or terminal interfaces.
- **Don't**: Introduce soft colors like blues or pastels; stick to the binary black/orange/white palette.

## Accessibility
- Maintain 4.5:1 contrast ratio by using white text on the #050505 background.
- Use `aria-label` for all icon-only buttons.
- Ensure focus states are visible via the #FF3B00 accent ring.
- All motion effects must be respectful of `prefers-reduced-motion` settings.