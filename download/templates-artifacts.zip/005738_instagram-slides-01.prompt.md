Recreate the website "Gemini 3 Animations Landing Page Template" with high visual fidelity as a Tailwind CSS and Vanilla JS site.

The result must match the supplied reference website, not a cleaned-up reinterpretation.

Preserve source quirks:
- The horizontal scroll container uses a specific mask-image: `linear-gradient(90deg, transparent, black 5%, black 95%, transparent)` which must be preserved to fade out the edges.
- Some font assignments use the specific Geist and Space Grotesk imports alongside system defaults.
- The pagination dots rely on exact JS-based class swaps for active states.
- The "SYS.INIT" label and other mono text use uppercase tracking-widest styles.

CRITICAL FIDELITY CONSTRAINTS
- The layout is a horizontal scroll-snap container (`snap-x snap-mandatory`).
- Every slide must have a 3:4 aspect ratio (`aspect-ratio: 3/4`).
- Animations must only trigger when a section is in view using the `animate-on-scroll` class and the custom `@keyframes animationIn`.
- No standard vertical scrolling; the main interaction is horizontal swipe or arrow buttons.

TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN)
- Lucide Icons (https://unpkg.com/lucide@latest)
- Google Fonts: Space Grotesk and Geist
- Vanilla JavaScript for IntersectionObserver and scroll logic.

GLOBAL STYLE
- Background: `bg-black`
- Text: `text-white` with `antialiased` and `selection:bg-orange-500/30`.
- Custom CSS:
  - `@keyframes animationIn`: `0% { opacity: 0; transform: translateY(30px); filter: blur(8px); } 100% { opacity: 1; transform: translateY(0); filter: blur(0px); }`
  - `.bg-grid-pattern`: `radial-gradient(circle at 1px 1px, rgba(255,255,255,0.1) 1px, transparent 0)` with `24px` size.
  - `hide-scrollbar` utility to remove scrollbar visuals while keeping functionality.

ASSET MAP
- Slide 1 (Cover): https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/5071d056-5442-4e08-adcf-cea83397ba23_1600w.webp
- Slide 2 (Intro): https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/28c300b5-bd2f-449c-a915-f968ced09242_1600w.webp
- Slide 5 (Text): https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/aedd68a9-659a-45bf-ae0a-842c1d982c93_1600w.webp
- Slide 7 (Cards): https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/3612ae9b-1f08-4708-a499-958fde6cc95b_1600w.webp
- Slide 8 (CTA): https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/c4ad25ed-2717-4e73-8585-2438242e676c_1600w.webp

VECTOR / ICON SHAPES
- Use Lucide for: `aperture`, `arrow-right`, `arrow-left`, `move-horizontal`, `scissors`, `type`, `framer`, `figma`, `chrome`, `github`, `codepen`, `zap`, `arrow-up-right`.

MEDIA BEHAVIOR
- Background images are set via `bg-cover bg-center`.
- Cards in Slide 7 use a CSS animation `cardStackCycle` over 12s that alternates `z-index`, `transform`, and `filter` for a rotating stack effect.

LAYER STACK / POSITIONING MAP
- **Fixed Nav**: `z-50`, `fixed`, `backdrop-blur-md`.
- **Slider Main**: `overflow-x-auto`, `snap-x`.
- **Slide Cards**: `relative`, `overflow-hidden`, `border-white/10`.
- **Gradients/Grids**: `absolute inset-0`, `z-0`.
- **Content Layers**: `relative`, `z-10`.

SECTION 1 - COVER
- Heading: "Gemini 3 Animations" (5xl on mobile, 7xl on desktop).
- Label: `[01/08] // SYS.INIT` in mono.
- Quote: "The best model at creating animations. It's not even close." with orange left border.

SECTION 2 - INTRO & SCROLL
- Features a simulated skeleton card with `animate-pulse` inside a `backdrop-blur-xl` container.
- Text: "Animate on View".

SECTION 3 - CLIP ANIMATION
- Visual: 4 vertical bars (neutral-800 to orange-500) using `@keyframes clip-reveal` with staggered delays (0s, 0.2s, 0.4s, 0.6s).

SECTION 4 - INTERACTION
- CTA: "Request Demo" with a spinning border beam. Implementation: Conic-gradient inside a rotating span (`animate-[spin_3s_linear_infinite]`) visible only on hover.

SECTION 5 - TYPOGRAPHY
- Visual: "Reveal Typography" with two separate overflow-hidden divs for a clipping entry effect.

SECTION 6 - SOCIAL PROOF
- Component: Infinite marquee of logos (Framer, Figma, Chrome, GitHub, Codepen) using `animate-marquee` and edge-fading gradients.

SECTION 7 - CARDS / FLASHLIGHT
- Visual: Three stacked cards cycling positions via `cardStackCycle` keyframes.
- Interaction: Flashlight effect on mouse hover using CSS variable `--mouse-x` and `--mouse-y` for a radial-gradient mask.

SECTION 8 - CTA
- Heading: "Good Prompting Is Everything".
- Button: White pill "Get Prompts" with `arrow-up-right`.
- Footer: Avatar bubble (letter 'M') with "Meng To - Design Engineer".

GLOBAL ANIMATION / INTERACTION RULES
- **Scroll Logic**: IntersectionObserver must toggle the `.animate` class to trigger `animationIn` on sub-elements.
- **Navigation**: Dots must update index based on which `.slide-container` is intersecting the horizontal center.
- **Buttons**: `nextBtn` and `prevBtn` must use `scrollBy` with smooth behavior.

COMMON MISTAKES TO AVOID
- Do not use vertical scrolling for the page body.
- Do not miss the `mix-blend-color-dodge` or `mix-blend-screen` on header elements within cards.
- Do not approximate the aspect ratio; it must be exactly 3/4 for slides.
- Do not replace custom SVG paths or Lucide icon names.