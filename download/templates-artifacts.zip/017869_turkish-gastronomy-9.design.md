---
version: 1.0.0
name: Sultan Gastronomy System
description: Visual framework for DIVAN restaurant, focusing on Anatolian tradition meets modern luxury.
colors:
  black: "#0a0a0a"
  black-light: "#141414"
  black-lighter: "#1a1a1a"
  gold: "#c9a962"
  gold-light: "#e8d5a3"
  gold-dark: "#a08540"
  cream: "#f5f0e6"
  cream-dark: "#d4cfc5"
  red-accent: "#8b2635"
typography:
  heading:
    family: "'Cormorant Garamond', serif"
    weights:
      - 300
      - 400
      - 500
      - 600
  serif:
    family: "'Playfair Display', serif"
    weights:
      - 300
      - 400
  body:
    family: "'Inter', sans-serif"
    weights:
      - 300
      - 400
      - 500
spacing:
  xs: "0.5rem"
  sm: "1rem"
  md: "2rem"
  lg: "4rem"
  xl: "8rem"
  "2xl": "12rem"
rounded:
  none: "0px"
  small: "2px"
  circle: "999px"
components:
  nav:
    height: "80px"
    background: "rgba(10, 10, 10, 0.95)"
    z-index: 1000
  button-primary:
    padding: "14px 32px"
    letter-spacing: "0.2em"
    transform-hover: "translateY(-2px)"
  card-menu:
    width: "350px"
    aspect-ratio: "4/5"
    overlay-gradient: "linear-gradient(to top, rgba(10,10,10,0.95), transparent)"
  form-input:
    border: "1px solid rgba(201, 169, 98, 0.3)"
    focus-color: "#c9a962"
motion:
  ease-out-expo: "cubic-bezier(0.16, 1, 0.3, 1)"
  ease-in-out: "cubic-bezier(0.65, 0, 0.35, 1)"
  reveal-duration: "1s"
---
## Overview
The Sultan system (DIVAN) leverages a dark-mode palette to convey exclusivity and intimacy. It combines traditional Anatolian motifs with modern CSS techniques like glassmorphism and grain overlays to create a tactile, premium digital experience.

## Colors
- **Primary Base**: Deep Black (#0a0a0a) for core backgrounds.
- **Secondary Base**: Cream (#f5f0e6) for high-contrast legibility without the harshness of pure white.
- **Accents**: Gold (#c9a962) used for interactive elements, borders, and branding marks.
- **Functional**: Black-Light and Black-Lighter for structural layering and card backgrounds.

## Typography
- **Primary Headings**: Cormorant Garamond for an elegant, editorial feel.
- **Emphasized Text**: Playfair Display (italic) for a luxury "handcrafted" signature look.
- **Body/System**: Inter for crisp, modern legibility in forms and secondary info.

## Spacing
Based on a modular 8px scale ranging from 0.5rem (xs) to 12rem (2xl) for dramatic whitespace in luxury layouts.

## Layout
- **Layer Stacks**: Utilizes a grain overlay (z-index 9997) and a custom loader (z-index 9999) above all content.
- **Verticality**: Includes a fixed `background-text` with `writing-mode: vertical-rl` for decorative depth.
- **Containers**: Max-width of 1400px for desktop layouts.

## Elevation & Depth
- **Glassmorphism**: 10px blur on hero badges and chef cards.
- **Gradients**: Heavy use of bottom-to-top black fades on imagery to ensure text legibility.
- **Grain**: A global fixed grain SVG (3% opacity) provides a filmic, physical texture.

## Shapes
- Sharp, architectural edges (0-2px) dominate the system, reflecting formal dining precision.
- Circular shapes are reserved strictly for small icons and social links.

## Components
- **Hero**: Full-viewport height with absolute-positioned layers: background image (bottom), overlay, content (center), and scroll indicator (bottom center).
- **Menu Scroll**: A horizontal-scrolling row of cards that pins the section vertically on desktop using GSAP.
- **Experience Items**: Interactive grid items that use CSS variables (`--mouse-x`) to track movement and reveal decorative SVG patterns.
- **Reservation Form**: Grid-based inputs with transparent backgrounds and gold borders.
- **Image Strip**: Alternating vertical offsets (+40px on even items) to create a rhythmic, gallery-style flow.

## Motion
- **Reveals**: Elements default to `translateY(40px)` and `opacity: 0`, triggered via ScrollTrigger.
- **Hero Parallax**: The hero image undergoes a slow `scale(1.05)` to `scale(1)` transition upon load.
- **Interactive**: 0.3s transitions on all buttons and nav links using `ease-out-quart` curves.

## Do's and Don'ts
- **Do**: Use italics in headings for the word "Gastronomie" or key adjectives.
- **Do**: Maintain generous whitespace between sections (min 8rem).
- **Don't**: Use rounded corners larger than 2px for structural cards or images.
- **Don't**: Introduce vibrant colors outside the gold/cream/black spectrum.

## Accessibility
- Maintain a contrast ratio of at least 4.5:1 by using gold-on-black or cream-on-black.
- Use `aria-hidden` on decorative elements like the vertical background text and grain overlay.
- Interactive items like the menu navigation buttons must include clear hover and focus states.