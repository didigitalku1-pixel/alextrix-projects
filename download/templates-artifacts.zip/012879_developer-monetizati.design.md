---
version: 1.0.0
name: Ledger Financial Design System
description: A developer-centric design system for SaaS monetization and tax infrastructure using a dark palette, Geist typography, and emerald accents.
colors:
  background: "#000000"
  surface: "#0A0B0E"
  surfaceElevated: "#121317"
  primary: "#10B981"
  primaryHover: "#34D399"
  textPrimary: "#FFFFFF"
  textSecondary: "#94A3B8"
  border: "rgba(255, 255, 255, 0.1)"
  accentPurple: "#A855F7"
  accentRose: "#F43F5E"
typography:
  fontFamily: "'Geist', 'Inter', sans-serif"
  headings:
    weight: "300"
    letterSpacing: "-0.02em"
  body:
    weight: "400"
    lineHeight: "1.6"
  mono:
    fontFamily: "'Geist Mono', monospace"
    size: "11px"
spacing:
  base: "4px"
  container: "32px"
  section: "96px"
  gap: "16px"
rounded:
  small: "8px"
  medium: "12px"
  large: "24px"
  full: "9999px"
components:
  nav:
    style: "sticky rounded-full backdrop-blur-md"
    border: "1px solid rgba(255, 255, 255, 0.1)"
  buttons:
    primary: "bg-white text-black rounded-full transition-colors"
    shiny: "gradient-border with conic animation"
  cards:
    style: "bg-[#0A0B0E] border-white/10 shadow-2xl transition-all hover:border-emerald-500/20"
  dashboard:
    sidebar: "w-72 bg-[#0c0d10] border-r border-white/5"
    header: "h-20 backdrop-blur-md sticky top-0"
  charts:
    candles: "emerald and purple scaled bars with scaleY transitions"
    area: "emerald gradient fills with dashed line indicators"
motion:
  transition: "0.8s ease-out"
  animation: "animationIn (translateY + blur)"
  scroll: "IntersectionObserver with 20% threshold"
---
## Overview
Ledger's visual system communicates reliability and speed. It uses a high-contrast dark mode foundation with emerald green signals to indicate financial health and system status.

## Colors
The palette is dominated by pure black (`#000000`) and a custom deep navy surface (`#0A0B0E`). Emerald Green is the primary action color, used for success states and calls to action. A muted slate is used for secondary text to maintain hierarchy in data-heavy views.

## Typography
Geist is the primary typeface, utilized for its geometric precision and excellent readability in technical contexts. Headings use a Light (300) weight for a sophisticated, modern look, while functional data uses Medium or Semi-bold for emphasis.

## Spacing
The system adheres to an 8px grid. Section padding typically uses 24px (6 units) or 32px (8 units). Large sections are separated by 96px vertical margins to allow the dense data components room to breathe.

## Layout
Layouts use a fixed-width container maxing out at 1400px. The system utilizes a complex layering strategy:
- **Background:** SVG noise or Unicorn Studio animated shaders.
- **Midground:** Elevated cards with 1px borders and subtle radial glow effects.
- **Foreground:** Interactive buttons, tooltips, and fixed navigation bars.
- **Sticky/Fixed:** Navigation stays sticky with `backdrop-blur-md` for legibility against shifting background content.

## Elevation & Depth
Depth is achieved through "border-glow" techniques rather than heavy shadows. Cards use a `1px` border with `white/10` opacity. Dashboard components use high `z-index` (50+) for navigation and modal overlays. Perspective is emphasized through `perspective: 1200px` on testimonial stacks.

## Shapes
Rounded corners are significant. Interface containers use `rounded-3xl` (24px). Buttons and input fields use `rounded-full` or `rounded-lg` (8px). This softness contrasts with the "hard" data of financial metrics.

## Components
- **Nav:** Pill-shaped, floating, and sticky with low opacity borders.
- **Shiny Button:** Uses `@property` CSS variables for a rotating conic-gradient border animation.
- **Dashboard Sidebar:** Fixed-width with categorized icon-based navigation.
- **Interactive Charts:** Financial visualizations using CSS `scaleY` transitions and absolute-positioned tooltips.
- **Terminal Visualizer:** A typing animation component used to demonstrate API activity.
- **Pricing Toggle:** A slider that switches data context between monthly and annual values.

## Motion
Motion is purposeful. The `animationIn` keyframe combines a `30px` upward translation with an `8px` blur fade. Marquee animations are used for social proof (logos) to show scale. Testimonial cards use 3D transforms (`rotate-x`, `rotate-y`) to create a physical card-stack feel.

## Do's and Don'ts
- **Do:** Use 1px borders for all surface containers.
- **Do:** Keep heading weights light (300) for hero sections.
- **Don't:** Use solid grey backgrounds; prefer translucent overlays and gradients.
- **Don't:** Use sharp 90-degree corners for primary UI containers.

## Accessibility
- Use `antialiased` for improved font rendering on dark backgrounds.
- Maintain high contrast ratios for primary text (White on Black).
- All interactive elements should have defined focus states using `focus:outline-none` and `focus:border-emerald-500/30`.