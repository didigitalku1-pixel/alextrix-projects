Recreate the website "NeonGrid | Sign In" with high visual fidelity as a Tailwind CSS and Vanilla JavaScript site.

The result must match the supplied reference website, not a cleaned-up reinterpretation.

Preserve source quirks:
- The social sign-in buttons use the same icon set (solar:sparkles-bold-duotone) in their data attributes but render unique brand paths (Google-like, Apple-like, GitHub-like).
- Specific typo in social button padding: "py-2." instead of "py-2.5" on the third social button.
- Aura background component is fixed and desaturated (saturate-0 brightness-50).

CRITICAL FIDELITY CONSTRAINTS
- Background must be neutral-950 with a fixed UnicornStudio overlay.
- Stacking: Background (-10) -> Outer Circuit Nodes -> Card Component.
- Typography: Heading is exactly 22px with tight tracking.
- Forms: Inputs must use neutral-950/60 background with shadow-inner shadow-black/40.

TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN)
- Iconify (3.1.0)
- UnicornStudio.js (v1.4.34) for background animation

GLOBAL STYLE
- Body: min-h-screen, antialiased, bg-neutral-950, text-neutral-100.
- Focus states: emerald-500 for border and ring-1 emerald-500/70.
- Transition: standard ease-in-out on buttons and links.

ASSET MAP
- Icon: solar:sparkles-bold-duotone (Logo and Socials)
- Icon: solar:inbox-unread-bold-duotone (Email field)
- Icon: solar:lock-keyhole-bold-duotone (Password field)
- UnicornStudio Project: bmaMERjX2VZDtPrh4Zwx

VECTOR / ICON SHAPES
- Preserve exact path data for the Sparkle logo (2 paths: opacity 0.5 background and solid foreground).
- Preserve exact path data for the Email and Lock icons.
- Custom paths for the social buttons (Aurora ID/Google style, Orbit/Apple style, Vector/GitHub style) as provided in the source inventory.

LAYER STACK / POSITIONING MAP
- LAYER 1 (Fixed): `.aura-background-component` (-z-10, top-0, w-full, h-screen) with mask-image: linear-gradient(to bottom, transparent, black 0%, black 80%, transparent).
- LAYER 2 (Absolute): Circuit Layout (pointer-events-none, hidden on mobile).
    - Node A: top-1/4, left-4.
    - Node B: bottom-10, left-10.
    - Node C: top-1/5, right-4.
    - Node D: bottom-16, right-8.
- LAYER 3 (Relative): Main Auth Card (max-w-md, mx-auto).

SECTION 1 - OUTER CIRCUITRY
- Recreate four node groups using absolute positioning.
- Each group contains: a horizontal line (`h-px bg-neutral-800`), a rounded chip (`bg-neutral-900/80 shadow-[0_0_0_1px_rgba(82,82,91,0.4)]`), and a pulsing emerald dot (`animate-pulse bg-emerald-400`).

SECTION 2 - SIGN-IN CARD
- Container: `bg-gradient-to-b from-neutral-900 via-neutral-900 to-neutral-800`, `border-neutral-800`, `rounded-3xl`.
- Top Accents: Two horizontal pill shapes at the top (left-10 and right-10) in `neutral-700` with varying opacity.
- Logo Block: Nested flex containers. Inner block is `bg-neutral-950`, `w-10`, `h-10`, `rounded-2xl` containing the emerald sparkle SVG.
- Form Fields:
    - Email: Label (uppercase, tracking-[0.16em]), Icon (currentColor), Input (transparent).
    - Password: Flex header with "Forgot?" link. Input contains a "Show" button (text-[11px] font-medium).
- Primary Action: Submit button with `bg-emerald-500` and a specific high-intensity shadow: `shadow-[0_14px_35px_rgba(16,185,129,0.55)]`.
- Social Grid: Three-column grid using `bg-neutral-900` buttons with icons colored `rgb(52, 211, 153)`.

GLOBAL ANIMATION / INTERACTION RULES
- Pulsing dots on circuit nodes (CSS `animate-pulse`).
- Hover transitions on all buttons: `bg-emerald-400` for primary, `bg-neutral-800/80` for secondary.
- Form input focus transitions for border and rings.

COMMON MISTAKES TO AVOID
- Do not use standard Tailwind green; use Emerald-400/500 specifically.
- Do not forget the `shadow-inner shadow-black/40` on form inputs.
- Ensure the background component has the `saturate-0` and `brightness-50` filters applied.