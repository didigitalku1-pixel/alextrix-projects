Recreate the website "Finex - Modern Finance" with high visual fidelity as a Tailwind CSS and Vanilla JavaScript landing page. Use a dark-themed, sophisticated FinTech aesthetic.

Preserve source quirks:
- The navigation logo uses a Midjourney generated image link as a background-image inside a rounded-full link element.
- Inconsistent font usage: Headlines use 'Oswald', while body text and UI elements shift between 'Inter', 'Newsreader', and 'Sans'.
- The mobile phone mockups contain detailed internal UI logic (scrollable areas, progress bars) that must be recreated exactly.

CRITICAL FIDELITY CONSTRAINTS
- Background Noise: Must use the specific noise.svg from grainy-gradients as an overlay with 20% opacity and mix-blend-soft-light.
- Animation Triggers: Use an IntersectionObserver to set animationPlayState = 'running' for elements with the .scroll-item class.
- No External Assets: Use only the provided Unsplash, Midjourney, and Supabase URLs. Do not substitute.

TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN)
- Lucide Icons (https://unpkg.com/lucide@latest)
- Fonts: Inter (300, 400, 500, 600), Newsreader (400-800), Oswald (300-700)
- UnicornStudio.js (v1.4.29) for background effects

GLOBAL STYLE
- Body: bg-[#000000], text-white, antialiased, selection:bg-primary.
- Scrollbars: Hidden globally using ::-webkit-scrollbar { display: none; }.
- Keyframes: Define fadeInUp (translateY 30px to 0) and blurIn (blur 15px, scale 0.95 to 1).

ASSET MAP
- Logo: https://cdn.midjourney.com/405c2b1c-c585-45e3-be19-65cdcd2d9e46/0_0.png?w=800&q=80
- Testimonial Main: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/59c85ed7-9ae4-40eb-88bf-fa793ae1de22_1600w.webp
- User 1: https://images.unsplash.com/photo-1522529599102-193c0d76b5b6?q=80&w=1000
- User 2: https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1000
- User 3: https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1000

LAYER STACK / POSITIONING MAP
- Z-Index -10: aura-background-component with UnicornStudio project HzcaAbRLaALMhHJp8gLY.
- Z-Index 0: fixed inset-0 noise overlay (noise.svg).
- Z-Index 50: fixed top-0 navigation bar.
- Z-Index 10: Absolute positioned decorative blurs (primary/5 color, 120px blur).

SECTION 1 - NAVIGATION
- Layout: Max-width 5xl container, border-white/10, rounded-full, backdrop-blur-md.
- Links: Centered absolute group (Platform, Solutions, Pricing, Developers, Company) text-14px font-medium.
- CTA: "Get Started" button, white bg, black text, hidden on mobile.

SECTION 2 - HERO
- Headline: "Master Finance. Simply." (Oswald, font-light, 5xl/7xl). "Simply" in blue-500.
- CTAs:
  1. "Start free" button with a conic-gradient spinning border beam (#3b82f6) and internal repeating-linear-gradient vertical lines animation.
  2. "Watch Demo" button with border-blue-500 and lucide-play-circle icon.
- Visual: Phone Frame (380x720px) containing a "Stats" app interface.
  - Left/Right Floating Badges: Salary, Holidays, Netflix, Coffee, Dividend, Portfolio (animate with bounce/pulse).
  - Internal App: Chart card with bar-grow animation and tooltip-fade labels.

SECTION 3 - INTELLIGENCE GRID
- Grid Layout: 1 md:grid-cols-2 lg:grid-cols-3. Feature cards in bg-[#0A0A0C] with radial-gradient backgrounds.
- Features:
  - ROI Prediction: SVG line chart with draw-path-loop and scale-in-loop percentage badge.
  - Cashflow: Central Radar chart with Jan-Jun axis labels and dual purple/cyan paths.
  - Engagement Forecasting: Dual rotating squares (spin-slow / spin-slow-reverse) with central counter.
  - Conversion Probability: Large 100% width-grow-loop bar over large 10% opacity text.

SECTION 4 - MOBILE APP SHOWCASE
- Layout: Vertical flex. Sub-badge "02 Mobile App".
- Content: Phone mockup (Left) with a full "Portfolio" UI: Balance card, Quick actions (Send/Receive/Buy/Top up), and Asset list (BTC, ETH, SOL).
- Animation: Chart bars inside the phone must have hover:bg-indigo-500/50 transitions.

SECTION 5 - TESTIMONIALS
- Carousel: 3 items. quote, name, role, img.
- Behavior: Function window.nextTestimonial() updates img src, quote text, and handles opacity-fade transitions (300ms).

SECTION 6 - PRICING
- Card: "Pro Plan" $19/mo. Layout: Left col (Price/Title), Right col (Features list/Button).
- Features: AI-Powered Forecasting, Unlimited Sync, etc. Use 1.5px bullet circles.

GLOBAL ANIMATION / INTERACTION RULES
- Progress Bars: @keyframes progress-loop (0% width to var(--target-width)).
- SVG Path: @keyframes draw-path-loop (stroke-dashoffset 1000 to 0).
- Counter Logic: JS script to increment data-counter-target values from 0 to target over 1500ms.

COMMON MISTAKES TO AVOID
- Do not use standard rounded-lg; use rounded-[2rem] or rounded-[3rem] as per source for container cards.
- Ensure the "Stats" and "Portfolio" phone screens have status-bar 9:41 time and battery SVGs.
- Do not omit the -z-10 absolute noise grain; it is essential for the depth aesthetic.