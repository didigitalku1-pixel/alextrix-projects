Recreate the website "Aura - Engineered Comfort" with high visual fidelity as a Tailwind CSS and Vanilla JavaScript site. The result must match the supplied reference website, not a cleaned-up reinterpretation.

Preserve source quirks:
- The site uses a specific ASCII dither background script that creates a noisy texture overlay on the top viewport.
- The "Engineered for Rest" hero title uses a stagger-animation effect where each letter is wrapped in a clipping container.
- Some layout lines are fixed to the viewport with a `mix-blend-multiply` mode and low opacity (0.04).
- The hero image has a specific `mask-image` linear gradient applied to fade the bottom into the background.

CRITICAL FIDELITY CONSTRAINTS
- Do not substitute the custom cursor/hover effects. The "card-flashlight" effect must use the specific CSS variables (`--mouse-x`, `--mouse-y`) updated via JS.
- Preserve the precise font stack: 'Playfair Display', 'Bricolage Grotesque', 'Manrope', 'Plus Jakarta Sans', and 'Geist'.
- Asset URLs must remain exactly as provided in the ASSET MAP.
- The WebGL image reveal logic (4-column staggered slide-down) must be implemented for all `<img>` tags.

TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN: https://cdn.tailwindcss.com)
- Iconify-icon (https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js)
- ASCII Dither Script: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/exports/ascii-dither-background(3).js
- Google Fonts (Inter, Playfair Display, Bricolage Grotesque, Manrope, Plus Jakarta Sans, Geist)

GLOBAL STYLE
- Background: `#F2EFEA` (Cream)
- Text: `#2C2824` (Charcoal/Dark Brown)
- Accent: `#C48C56` (Bronze/Tan)
- Selection: `selection:bg-[#2C2824] selection:text-[#F2EFEA]`

ASSET MAP
- Hero Chair: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/687d701a-8748-4856-8c62-5627d113ee3e_1600w.webp
- Lifestyle (Relaxing): https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/b9fef1af-7076-41f8-94ac-87cf3a20563d_3840w.jpg
- Lounge Chair (Grid): https://images.unsplash.com/photo-1592078615290-033ee584e267?q=80&w=1000
- Accent Chair (Grid): https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?q=80&w=1000
- Interior Details: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/fe806415-0282-4b2f-b891-094e5725d386_1600w.jpg
- Person Relaxing: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/1eeba076-f2e1-49dd-b874-17afd258a4c9_1600w.jpg
- Chair Detail (Dark): https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/62ec4789-2963-4666-aa09-20586e294364_800w.webp
- Consultant: https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=200
- Bespoke Config: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/226163af-42a4-443b-977d-7e18fe3f4d61_1600w.webp

LAYER STACK / POSITIONING MAP
- BACKGROUND LAYER: Fixed lines container (`inset-0`, `z-50`, pointer-events-none) containing 4 vertical `w-px` lines.
- NAVIGATION: Absolute top, `z-40`, containing logo (armchair icon) and nav links.
- HERO SECTION: `min-h-screen`, relative, `z-10`. Central text is foreground, large chair image is midground (`z-[-1]`, absolute inset).
- CARDS: `card-flashlight` class uses `::before` and `::after` pseudo-elements for radial gradient highlights on hover.
- MARQUEE: `z-10`, `overflow-hidden`, uses `mask-image` for edge fading.

SECTION 1 - HERO
- Text: "Engineered for Rest" with a light font-weight and tight tracking.
- Sub-text: Left-aligned technical description; right-aligned material description.
- Animation: Letters slide up from hidden overflow containers with 0.05s increments.
- Bottom Border: 3-column grid showing "Kinetic Support", "Bespoke Textiles", "Architectural Form" with numbers.

SECTION 2 - LOGO BAR
- Logos: NASA, SpaceX, Uber, Visa, Bose, Discover, DJI, Sony icons.
- Styles: `opacity-40`, `grayscale`, `hover:grayscale-0`, `transition-all duration-700`.

SECTION 3 - FULL WIDTH IMAGE
- Overlay: `bg-black/20`, transitions to `/10` on hover.
- Text: Centered "Engineered around human mechanics..." with white lines flanking the sub-text.

SECTION 4 - THE SCIENCE OF POSTURE
- Layout: 12-column grid. Col 1-4: Text content + Sonar Ring asterisk. Col 5-12: 2 asymmetric cards.
- Card 1: Square aspect ratio chair. Card 2: 4/5 aspect ratio chair, offset vertically (`lg:-mt-24`).

SECTION 5 - DARK PRECISION SECTION
- Background: `#26221E`. Text: `#F2EFEA`.
- Centerpiece: `h-[500px]` card containing high-detail chair macro.
- Interaction: Lists on either side (Series Classification vs Material Synthesis) with hover-state border color transitions.

SECTION 6 - MARQUEE & BESPOKE
- Marquee: Infinite loop of "ENGINEERED COMFORT • ARCHITECTURAL DESIGN • STRUCTURAL INTEGRITY".
- Bespoke: Split section. Left: Bulleted "Consultation Protocols" and an "Elena R." testimonial badge. Right: Large vertical chair configuration image.

GLOBAL ANIMATION / INTERACTION RULES
- Flashlight Effect: `mousemove` listener on `.card-flashlight` elements updates `--mouse-x` and `--mouse-y`.
- Sonar Rings: Infinite scaling animation on absolute circles behind asterisks.
- WebGL Reveal: Images must use a Fragment Shader that reveals the texture using a 4-column stagger and cubic-out easing when entering the viewport.

COMMON MISTAKES TO AVOID
- Do not use standard CSS hover for the card highlights; they must follow the mouse coordinates.
- Do not use different icons; use the exact `solar:` and `simple-icons:` sets via Iconify.
- Do not normalize the tracking; keep it `tracking-tighter` on headings.
- Do not omit the vertical lines overlay; it is a core branding element.