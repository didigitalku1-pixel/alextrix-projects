---
version: 1.0.0
name: WhatsApp Control Center
description: Dark-mode landing page system for AI and automation workshops.
colors:
  background: "#030303"
  surface: "#0a0a0a"
  primary: "#10b981"
  primary-muted: "rgba(16, 185, 129, 0.2)"
  text-main: "#d4d4d4"
  text-heading: "#ffffff"
  text-muted: "#737373"
  border: "rgba(255, 255, 255, 0.05)"
  accent-blue: "#60a5fa"
  accent-purple: "#c084fc"
  accent-orange: "#fb923c"
  accent-pink: "#f472b6"
typography:
  sans:
    family: "Inter, sans-serif"
    weights: [300, 400, 500, 600]
  display:
    family: "Inter, sans-serif"
    weights: [500, 700]
    tracking: "-0.05em"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "40px"
  section: "80px"
rounded:
  sm: "4px"
  md: "8px"
  lg: "12px"
  xl: "16px"
  full: "999px"
components:
  nav:
    background: "rgba(0, 0, 0, 0.5)"
    blur: "12px"
    height: "64px"
    sticky: true
  announcement-bar:
    background: "rgba(6, 78, 59, 0.2)"
    height: "40px"
    text-size: "12px"
  hero:
    alignment: "center"
    padding-top: "160px"
    max-width: "896px"
  card-bento:
    background: "conic-gradient(from 180deg, rgba(16, 185, 129, 0.05), rgba(23, 23, 23, 0.1))"
    border: "1px solid rgba(255, 255, 255, 0.1)"
  pricing-card:
    background: "rgba(23, 23, 23, 0.8)"
    blur: "20px"
    shadow: "0 25px 50px -12px rgba(0, 0, 0, 0.5)"
motion:
  transition: "all 300ms ease"
  hover-transform: "translateX(4px)"
---
## Overview
A technical, high-performance visual system for AI-focused workshops. It utilizes a deep black foundation with emerald green highlights and subtle grid overlays to evoke a "Control Center" or developer-environment aesthetic.

## Colors
- **Deep Foundation**: Uses `#030303` as the base to ensure high contrast for text and emerald glows.
- **Emerald Accents**: Primary action color is `#10b981`. Used for indicators, primary buttons, and status icons.
- **Semantic Gradients**: Multi-color accents (blue, purple, orange, pink) are reserved specifically for module categorization.
- **Typography Gradients**: Headings use a vertical linear gradient from White to Neutral-500 to create depth.

## Typography
- **Hierarchy**: Large display titles use `-0.05em` tracking and leading of `1.1` for a compact, modern feel.
- **Clarity**: Secondary text uses Inter at `14px` or `16px` with relaxed line-height (`1.6`) for readability against dark backgrounds.
- **Mono-Style**: Small labels use uppercase with wider tracking for a technical look.

## Spacing
- **Grid Foundation**: Based on an 8px scale.
- **Section Breaths**: Vertical padding of 80px to 96px between major content blocks.
- **Content Gaps**: 16px for small grouped items, 40px for block-level separation.

## Layout
- **Layering**: Three distinct z-layers: Background (Grid/Glow), Midground (Bento cards/Content), Foreground (Fixed Nav/Announcement).
- **Constraints**: Main content containers are capped at 1024px (max-w-5xl) for readability.
- **Responsive Strategy**: Single column on mobile switching to 3-column bento grids at 768px.

## Elevation & Depth
- **Glow Effects**: Radial gradients (`rgba(16, 185, 129, 0.15)`) placed behind key assets to simulate light emission.
- **Glassmorphism**: Backdrop blur of `12px` to `20px` used on floating navigation and the pricing card.
- **Borders**: Thin, 1px semi-transparent borders (`rgba(255, 255, 255, 0.05)`) define containers without heavy shadows.

## Shapes
- **Containers**: Large radii (16px to 24px) for cards and sections.
- **Buttons**: Medium radii (8px) for a balanced professional look.
- **Badges**: Pill-shaped (999px) for status indicators.

## Components
- **Announcement Bar**: Fixed to top, uses emerald-900 transparency and subtle bottom border.
- **Integration Hub**: A centralized visual node system using SVG lines and floating icons to explain technical architecture.
- **Bento Grid**: Combined 3-column and 2-column layout with internal borders rather than external gaps.
- **Pricing Panel**: Features a high-contrast white button to signify the primary conversion point.

## Motion
- **Transitions**: Global 300ms duration for hover states.
- **Micro-interactions**: Subtle `translateX` on button arrows and background opacity shifts on card hover.
- **Presence**: Use of pulse animations on status dots to indicate "Live" or "Active" states.

## Do's and Don'ts
- **Do**: Use high-contrast white text for primary headings.
- **Do**: Keep grid backgrounds subtle; they should be felt, not seen first.
- **Don't**: Use solid bright colors for backgrounds; always prefer gradients or dark neutrals.
- **Don't**: Overuse the emerald green; keep it for functional cues and branding.

## Accessibility
- **Text Contrast**: Use emerald-400 or lighter for text on dark backgrounds to meet AA standards.
- **Touch Targets**: Buttons maintain a minimum height of 48px.
- **Selection**: Custom selection colors (`bg-emerald-500/30`) ensure visibility during text highlighting.