---
version: 1.0.0
name: Fluxora
description: A futuristic dark visual system using high-contrast typography and subtle light-leak effects to represent edge computing and AI speed.
colors:
  background: "#0a0a0a"
  foreground: "#ffffff"
  primary: "#3b82f6"
  secondary: "#60a5fa"
  neutral-300: "#d1d5db"
  neutral-400: "#9ca3af"
  neutral-600: "#4b5563"
  neutral-950: "#050505"
  border-white-10: "rgba(255, 255, 255, 0.1)"
  accent-glow: "rgba(59, 130, 246, 0.25)"
typography:
  fontFamily: "Inter, system-ui, sans-serif"
  h1:
    size: "72px"
    weight: "700"
    letterSpacing: "-0.05em"
  h2:
    size: "48px"
    weight: "600"
    letterSpacing: "-0.03em"
  body:
    size: "16px"
    weight: "400"
    lineHeight: "1.6"
  caption:
    size: "12px"
    weight: "500"
    letterSpacing: "0.05em"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "32px"
  section: "96px"
rounded:
  sm: "8px"
  md: "12px"
  lg: "16px"
  xl: "24px"
  full: "9999px"
components:
  nav:
    style: "sticky top-0 z-50 py-5 bg-neutral-950/80 backdrop-blur-md"
  button-primary:
    background: "white"
    text: "#0a0a0a"
    rounded: "9999px"
    padding: "12px 24px"
  card-glass:
    background: "linear-gradient(225deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.05) 50%)"
    border: "1px solid rgba(255,255,255,0.1)"
    shadow: "drop-shadow(0 20px 60px rgba(0,0,0,0.6))"
  pill-badge:
    background: "rgba(255, 255, 255, 0.05)"
    border: "border-gradient"
    rounded: "9999px"
motion:
  curve: "ease-out"
  duration: "0.8s"
  initial: "translateY(30px) opacity(0) blur(8px)"
---
## Overview
Fluxora is a premium dark-mode system designed for developer-centric products. It uses a "layered shadow" approach where content feels elevated above a deep neutral grid background through the use of subtle border gradients and glassmorphism.

## Colors
The palette is rooted in `neutral-950` black. Primary actions use vibrant Blue-500/400. Text hierarchy is strictly enforced via neutral shades: White (headings), Neutral-300 (body), and Neutral-400 (secondary info).

## Typography
Relies exclusively on the Inter font family. High contrast is achieved through large, tight-tracking headings and small, uppercase tracking for labels and eyebrow tags.

## Spacing
A strict 8px grid system. Section padding is aggressive (96px+) to give complex AI infrastructure concepts room to breathe.

## Layout
Uses a sophisticated Bento-grid architecture for feature displays. Layouts prioritize centered hero sections followed by multi-column grids that adapt from 12-columns on desktop to single-column on mobile. Backgrounds feature fixed SVG grids at low opacity (3%).

## Elevation & Depth
Depth is created using `border-gradient`. This effect mimics a light source hitting the edges of 3D planes. Background elements use `blur-3xl` with low-opacity blue gradients to suggest a volumetric atmosphere behind the content.

## Shapes
Highly rounded corners define the brand. Most cards use `24px` or `28px` radii, while interactive buttons and pill indicators use `9999px` (fully rounded) to soften the technical nature of the content.

## Components
- **Nav**: Minimalist with glass backdrop-blur.
- **Bento Card**: Diverse heights containing code blocks, avatars, or charts, unified by the `border-gradient` class.
- **Testimonial Slider**: Focused center-stage quote with large-scale typography and grayscale-to-color avatar selectors.
- **Code Blocks**: Embedded in cards with Next.js/React-inspired syntax highlighting and window-style chrome.

## Motion
All elements use a signature `fadeSlideIn` entrance animation triggered on scroll. The curve is a smooth `ease-out` with a 30px vertical travel and an 8px blur reduction to simulate focusing optics.

## Do's and Don'ts
- **Do**: Use border-gradients on all major cards.
- **Do**: Maintain high letter-spacing on small labels.
- **Don't**: Use solid bright backgrounds; maintain the neutral-950 depth.
- **Don't**: Use sharp 0px corners.

## Accessibility
Text contrast is maintained at 4.5:1 or higher by using pure white or neutral-300 on black. Interactive elements include `transition-all` to provide immediate hover feedback. Semantic tags like `<article>`, `<section>`, and `<nav>` are required.