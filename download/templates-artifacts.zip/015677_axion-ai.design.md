---
version: 4.2.0
name: Axion Industrial AI Grid
description: A futuristic, technical interface utilizing grid-based layouts, monospace typography, and high-contrast orange accents to represent autonomous system infrastructure.
colors:
  background: "#050505"
  background-elevated: "#080808"
  surface: "#18181b"
  primary: "#ea580c"
  primary-muted: "rgba(234, 88, 12, 0.1)"
  border: "#27272a"
  text-primary: "#ffffff"
  text-secondary: "#a1a1aa"
  text-muted: "#52525b"
  status-success: "#22c55e"
typography:
  headings:
    family: "Inter, sans-serif"
    weight: "500"
    transform: "uppercase"
    letterSpacing: "-0.02em"
  mono:
    family: "JetBrains Mono, Geist Mono, monospace"
    weight: "400"
    transform: "uppercase"
    letterSpacing: "0.1em"
  body:
    family: "Inter, sans-serif"
    weight: "400"
    size: "14px"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "32px"
  xl: "64px"
rounded:
  none: "0px"
  sm: "2px"
components:
  header:
    height: "64px"
    border: "1px solid #27272a"
    sticky: true
  button:
    padding: "16px 32px"
    font: "mono"
    borderRadius: "0px"
    transition: "all 0.3s cubic-bezier(0.16, 1, 0.3, 1)"
  card:
    bg: "rgba(24, 24, 27, 0.2)"
    border: "1px solid #27272a"
    padding: "32px"
  terminal-panel:
    bg: "rgba(5, 5, 5, 0.9)"
    font: "mono"
    fontSize: "10px"
  status-badge:
    padding: "4px 8px"
    border: "1px solid currentColor"
    display: "inline-flex"
motion:
  duration-reveal: "1.8s"
  easing-reveal: "cubic-bezier(0.16, 1, 0.3, 1)"
  scanline-pulse: "flicker 2.4s linear"
---
## Overview
The Axion design system is a "Command-and-Control" visual language. It uses a strict 40px grid, high-contrast borders, and technical data overlays to convey precision, security, and real-time autonomous processing.

## Colors
The palette is rooted in absolute black (#050505) with Zinc-based grayscale for structural elements. International Orange (#ea580c) is used exclusively for primary actions and system alerts. Status greens are used for successful validation logs.

## Typography
- **Inter**: Used for high-level headlines with tight tracking and for standard body text.
- **JetBrains Mono**: The structural font for all UI metadata, system logs, labels, and navigation. Monospace usage is essential for the technical aesthetic.

## Spacing
A strict grid system based on multiples of 8. Major sections are separated by 64px (xl) or 128px. Internal component padding typically uses 16px (md) or 32px (lg).

## Layout
- **Fixed Grid Background**: A subtle 40x40px grid pattern persists in the background at 0.03 opacity.
- **Modular Stacking**: The interface is divided into columns (12-column grid) with explicit vertical and horizontal borders (#27272a) creating a blueprint-like appearance.
- **Sidebars**: A 64px fixed vertical track on the left is used for system status labels rotated -90 degrees.

## Elevation & Depth
- **Flat Architecture**: No drop shadows are used for standard elements. Depth is achieved through border nesting and opacity layers.
- **Glowing Highlights**: Primary buttons and active status indicators use subtle blurs (15px) of orange or green to simulate LED luminescence.

## Shapes
- **Hard Edges**: All buttons, inputs, and primary containers use 0px border-radius (rounded-none).
- **Structural Accents**: Use 4x4px L-shaped corner brackets in container corners to reinforce the technical/scoped look.

## Components
- **Navigation**: Top-aligned sticky bar with numbered monospace labels (e.g., 01. Platform).
- **Telemetry Stats**: Data displays showing percentages with bottom-aligned bar fills and pulsing status dots.
- **Validation Console**: A multi-column panel showcasing system health with log-style text rows.
- **Pricing Tiers**: Scoped boxes with level indicators (Level_01, Level_02) and feature lists with check-iconify markers.

## Motion
- **System Reveal**: Elements use a slow 1.8s rise and blur-in effect on scroll.
- **Telemetry Pulse**: Status dots and bar fills utilize a 2.4s cubic-bezier animation to simulate live data flow.
- **CRT Scanlines**: A background linear-gradient animation creates a subtle flickering overlay to mimic physical monitors.

## Do's and Don'ts
- **Do**: Use uppercase for all monospace labels.
- **Do**: Prefix technical labels with system notation (e.g., // CMD_SEARCH, FIG. 01).
- **Don't**: Use rounded corners larger than 2px.
- **Don't**: Use vibrant colors outside of Orange and Green.

## Accessibility
- Contrast ratios must remain high; text is primarily Zinc-400 on Black-950.
- Focus states must be explicitly highlighted with Orange (#ea580c) borders.
- All motion should respect `prefers-reduced-motion` settings via CSS media queries.