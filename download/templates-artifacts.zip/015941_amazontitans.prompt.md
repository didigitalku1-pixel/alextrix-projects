Recreate the website "Amazon Titans" with high visual fidelity as a conversion-focused landing page. The result must match the supplied reference exactly, using a dark-mode aesthetic with stone-textured accents.

Preserve source quirks:
- Single-page application logic using a hidden/active CSS toggle system for sections (#home, #services, #pricing, #casestudies, #about, #contact).
- Responsive text shifts (e.g., Hero title at 4xl scaling to 6xl on desktop).
- Precise font weights ranging from light (300) to extra bold (800).
- Mix of Serif (Playfair Display) for the "FAO Schwarz" logo and Sans-Serif (Inter) for global UI.

CRITICAL FIDELITY CONSTRAINTS
- Background: Use the fixed "aura-background-component" with a linear-gradient alpha mask (transparent to black 80%).
- Color Palette: Deep black (#000000) backgrounds, stone-tinted borders (#1c1917), and slate-toned primary text (#f1f5f9).
- Navigation: Fixed header with backdrop-blur-md and a specific z-index of 100.
- Form Logic: All forms must point to https://formspree.io/f/xqeqpobz and include the custom loading spinner animation upon submission.

TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN version)
- Iconify (3.1.0) for Lucide icons
- Google Fonts: Inter, Playfair Display, Geist, Roboto, Montserrat, Poppins, Instrument Serif, Merriweather, Bricolage Grotesque, Plus Jakarta Sans, Manrope, Space Grotesk, Work Sans, PT Serif, Geist Mono, Space Mono, Quicksand, Nunito, Newsreader, Oswald, DM Sans, Cormorant Garamond.
- UnicornStudio.js (v1.4.29) for the animated background.

GLOBAL STYLE
- Body: bg-black, text-slate-100, font-family 'Inter'.
- Icons: Global stroke-width override of 1.5px.
- Transition: 0.2s ease-in-out for section visibility; 0.4s fadeIn for active content.

ASSET MAP
- Client Logos: Use Iconify with specific companion text (e.g., lucide:check-circle for "That's it.", lucide:globe-2 for "Discovery Kids", lucide:gamepad-2 for "BACKBONE").
- Background Animation: Script source: https://cdn.jsdelivr.net/gh/hiunicornstudio/unicornstudio.js@v1.4.29/dist/unicornStudio.umd.js. Project ID: ZHhDKfVqqu8PKOSMwfuA.

VECTOR / ICON SHAPES
- Use lucide:menu for mobile navigation.
- Custom chart icons in Case Studies: lucide:cpu, lucide:apple, lucide:rocket.
- Checkmarks: lucide:check for pricing lists.

LAYER STACK / POSITIONING MAP
1. BACKGROUND: .aura-background-component (fixed, h-screen, z-[-10]).
2. NAV: header (fixed, top-0, z-[100], bg-black/90).
3. MAIN: .flex-grow (pt-16 relative).
4. SECTION LAYERS: .page-section (display: none, opacity: 0).
5. ACTIVE SECTION: .page-section.active (display: block, opacity: 1, animation: fadeIn).

SECTION 1 - HERO (HOME)
- Title: "We Scale Amazon Brands With Data — Not Guesswork."
- Subtext: "Amazon PPC, listing optimization... brands doing $50K–$40M/year."
- Trust Strip: 4-item horizontal list with lucide:bar-chart-2, lucide:target, lucide:award, lucide:file-text.

SECTION 2 - CLIENT LOGOS
- Layout: flex flex-wrap, gap-x-12, grayscale with 0.7 opacity. On hover: grayscale-0, opacity-100.
- Clients: That's it., Discovery Kids, BACKBONE, Sharper Image, FAO Schwarz, Pimax, Simucube, CaseYard, ThreeSixty.

SECTION 3 - SERVICES
- Layout: 3-column grid (md:grid-cols-3).
- Components: Card items with 10x10 rounded icon containers that flip to white background on group-hover.
- Items: Full Service, PPC, Listing Optimization, DSP, Brand Support, Inventory Mgmt, Google Ads, Customer Service, Recovery, SEO, Photography, Reporting.

SECTION 4 - PRICING
- Card 1: Starter ($5,000/mo) - Border stone-800.
- Card 2 (POPULAR): Scale ($7,500/mo) - Transform translate-y-[-1rem], bg-stone-100, text-black.
- Card 3: Market Leader (Custom) - Border stone-800.

SECTION 5 - CASE STUDIES
- Metrics: $350M+ Revenue, 72x ROI, 9yr Tenure.
- Data Viz: Custom bar charts for Consumer Electronics (+7,085%), Grocery (+5,814%), and Toys (+7,245%) using stone-900 to stone-100 height increments.
- Performance Ledger: Table with transition hover:bg-stone-950.

SECTION 6 - ABOUT
- Content: Founder & Principal narrative. High-density text layout with a stone-100 separator (w-20 h-1).
- Comparisons: "Most Amazon Agencies" (lucide:x) vs "Amazon Titans" (lucide:check).

GLOBAL ANIMATION / INTERACTION RULES
- Router: Custom route(event, pageId) function to toggle .active class and update window.location.hash.
- Forms: handleFormSubmit function targeting #home-form-container and #main-contact-form-container. Replaces form with an Emerald-themed success message upon fetch success.

IMPLEMENTATION REQUIREMENTS
- Do not use generic images; preserve the exact icon-based branding.
- Maintain the high-contrast stone-on-black UI (borders must be visible but subtle).
- Ensure the UnicornStudio background script is properly initialized.