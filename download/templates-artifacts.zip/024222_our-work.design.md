---
version: "1.0.0"
name: "Stacked Marketing"
description: "Editorial-style B2B growth agency template utilizing a blend of high-contrast serif typography and soft gold accents."
colors:
  background: "#FAFAFA"
  surface: "#FFFFFF"
  primary: "#c9a646"
  primary-hover: "#b89539"
  text-main: "#111827"
  text-muted: "#6B7280"
  border: "#E5E7EB"
  accent-light: "#FAF8F3"
  dark-section: "#111827"
typography:
  serif:
    family: "Instrument Serif"
    weight: "400"
    style: "italic-primary"
  sans-main:
    family: "Inter"
    weights: ["300", "400", "500", "600"]
  sans-accent:
    family: "Montserrat"
    weights: ["500", "600", "700"]
spacing:
  base: "4px"
  xs: "8px"
  sm: "16px"
  md: "24px"
  lg: "48px"
  xl: "80px"
rounded:
  none: "0px"
  sm: "8px"
  md: "12px"
  lg: "16px"
  xl: "24px"
  full: "999px"
  section: "40px"
components:
  nav: "Glassmorphism rounded-full pill"
  hero: "Centered layout with radial masked background grids"
  button: "Pill-shaped with soft drop shadows and gold hover states"
  card: "Large border-radius containers with subtle 1px borders"
  badge: "All-caps tracking-widest with light background fills"
  faq: "Accordions with custom clean borders and subtle icon rotations"
motion:
  fadeUp: "0.8s cubic-bezier(0.16, 1, 0.3, 1)"
  marquee: "40s linear infinite horizontal scroll"
---
## Overview
Stacked Marketing is a sophisticated, trust-oriented visual system designed for high-ticket B2B services. It balances traditional editorial authority (serifs, ample whitespace) with modern SaaS aesthetics (glassmorphism, radial gradients).

## Colors
The palette is grounded in a clean white/off-white (#FAFAFA) base with a luxury gold accent (#c9a646) used for brand-specific interactions. Dark sections (#111827) provide high-contrast moments for key guarantees and calls to action.

## Typography
- **Headlines**: Use *Instrument Serif* for a premium, boutique agency feel. Tracking should be tight (-0.02em).
- **Body**: Use *Inter* for maximum legibility in long-form sales copy.
- **UI/CTAs**: Use *Montserrat* for buttons, labels, and eyebrow text to provide a technical, robust counterpoint to the serif headers.

## Spacing
The system relies on an 8px grid but prioritizes generous vertical rhythm (80px to 120px) between major sections to prevent visual fatigue during sales pitch reading.

## Layout
- **Header**: Fixed top, centered glassmorphism pill. Uses `z-index: 50` and `backdrop-filter: blur(12px)`.
- **Hero**: Stacked vertical orientation with an absolute-positioned grid layer (`opacity: 50`) and radial mask.
- **Containers**: Max-width of 1200px (7xl) for content blocks to maintain line-length readability.

## Elevation & Depth
- **Surface**: Uses `shadow-sm` for standard cards and `shadow-xl` for high-importance items like video embeds.
- **Interaction**: Buttons use `hover:shadow-lg` with a color-matched shadow (`#c9a646/20`).

## Shapes
- **Cards**: Highly rounded corners (2rem to 2.5rem) give the system a friendly yet professional appearance.
- **Buttons**: Exclusively `rounded-full` (pills) for primary navigation and CTAs.
- **Icons**: Contained in `rounded-xl` or `rounded-full` light-tinted backgrounds.

## Components
- **Navigation**: Centered pill floating at the top with a distinct separation of logo (left) and info/CTA (right).
- **Trust Bar**: Infinite scrolling marquee for logos with a linear-gradient mask to fade edges.
- **Case Study**: Dual-column layout featuring an image with a floating metric badge and a detailed result breakdown.
- **Comparison Grid**: 3-column pain-point grid using gradient backgrounds from accent-light to white.
- **Checklist**: Symmetrical 2-column list using custom SVG icons for high-density feature lists.

## Motion
- **Entry**: Content follows an `animate-fade-up` pattern with sequential delays (100ms, 200ms, 300ms) to create a sense of flowing information.
- **Marquee**: Smooth, continuous translation of the X-axis for partner logos.
- **Attention**: The main strategy CTA uses a soft pulse animation to draw focus without being intrusive.

## Do's and Don'ts
- **Do**: Use italics in serif headlines for brand personality.
- **Do**: Maintain generous whitespace around section headers.
- **Don't**: Use sharp 0px corners; every container must be rounded.
- **Don't**: Use the primary gold color for body text; keep it for accents and CTAs only.

## Accessibility
- Use `selection:bg-rose-100` for high-contrast text selection.
- All functional icons must include `aria-hidden="true"` when paired with labels.
- Ensure `details/summary` FAQ tags remain keyboard-navigable.