---
version: 1.0.0
name: Aura Design System
description: A skeuomorphic visual system for AI personal assistants and SaaS products, emphasizing clarity, soft depth, and organized information flow.
colors:
  bg-primary: "#f3f5f8"
  text-base: "#0f172a"
  text-muted: "#64748b"
  blue-primary: "#3b82f6"
  blue-deep: "#1d4ed8"
  blue-soft: "#eff6ff"
  surface-glass: "rgba(255, 255, 255, 0.84)"
  border-light: "rgba(255, 255, 255, 0.9)"
  border-slate: "#e2e8f0"
  dark-surface: "#101827"
typography:
  display:
    family: "Inter"
    weight: 300
    tracking: "-0.075em"
  heading:
    family: "Inter"
    weight: 400
    tracking: "-0.04em"
  body:
    family: "Inter"
    weight: 300
    size: "16px"
  mono:
    family: "JetBrains Mono"
    weight: 500
    tracking: "-0.08em"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "32px"
  section: "80px"
rounded:
  sm: "8px"
  md: "12px"
  lg: "16px"
  xl: "24px"
  full: "999px"
components:
  navigation: "Floating pill-shaped nav with 2xl backdrop-blur and inset white highlight."
  hero: "Large display type with a gradient-filled 'Move faster' capsule and floating bubble-stack orbit."
  cards: "Skeuomorphic tiles with 1px white inset borders, soft outer shadows, and bottom-heavy gradients."
  stats: "Grid-based metric cards with large display values and descriptive light-weight labels."
  pricing-toggle: "Inset grey track with a skeuomorphic white pill transition using cubic-bezier."
  forms: "Rounded inputs with subtle internal shadows to simulate depth."
motion:
  drift: "Slow ambient drift for background blobs (26s-32s cycle)."
  float: "Soft vertical translation (8px) for floating UI bubbles."
  reveal: "Cubic-bezier entry (0.22, 1, 0.36, 1) with slight translate-y and blur-to-focus."
---
## Overview
Aura is defined by its 'Calm Skeuomorphism'—a visual language that uses physical cues like inner highlights (1px white top borders), soft drop shadows, and layered transparency to organize complex AI context without creating visual noise.

## Colors
The palette is rooted in a soft grey-blue base (#f3f5f8) to reduce eye strain. Accents use a vibrant blue-500 for actions, while surfaces utilize varying levels of white alpha transparency (60% to 90%) to create depth against the ambient background blobs.

## Typography
Inter is the primary workhorse, used in light weights (300) for body and display to maintain a 'premium document' feel. JetBrains Mono is used as a utility typeface for labels, tags, and brand identifiers to signal technical precision.

## Spacing
A consistent 8px grid is used. Larger section padding (20 units/80px) ensures that information-dense AI cards have enough breathing room to be processed individually.

## Layout
Layouts rely on Z-index stacking. The 'aura-background-component' sits at -10, content at base level, and floating notifications/bubbles at +20. Responsive changes involve shifting from 3-column grids to single-column stacks while maintaining rounded corner ratios.

## Elevation & Depth
Depth is achieved through the 'Aura Sandwich':
1. Background: Fixed ambient blobs with 120px blur.
2. Midground: Glassy surfaces with backdrop-filter: blur(24px).
3. Foreground: 1px white border (top) + 1px slate-200 border (outer) + soft blue-tinted drop shadow.

## Shapes
Radius values are extremely generous. Primary containers use 2rem (32px), while internal components use 1.5rem (24px). Pill shapes are used for navigation and status tags to reinforce the soft, approachable aesthetic.

## Components
- **The Daily Brief:** A structured stack using icon-led rows, emphasizing 'Priorities' through gradient backgrounds and 'Secondary Context' through slate-50 tiles.
- **Input-to-Action Pipeline:** A visual map using dashed connection lines and animated flow-states to illustrate data processing.
- **Pricing Cards:** Featured plans use a blue-to-deep-blue gradient (#3b82f6 to #2563eb) to separate them from the standard white/slate tiers.

## Motion
Motion is purposeful. Ambient background movement is nearly imperceptible to avoid distraction. Interactive elements use a 300ms transition with a -0.5rem translate-y lift on hover to signal clickability.

## Do's and Don'ts
- **Do:** Use inset white borders on the top edge of all cards to simulate a light source from above.
- **Do:** Use JetBrains Mono for all uppercase labels and micro-copy.
- **Don't:** Use sharp 0px corners; everything must be rounded.
- **Don't:** Use pure black (#000) for text; use Slate-950 for high contrast.

## Accessibility
Contrast is maintained by backing semi-transparent glass layers with a 36% opacity white underlay to prevent dark background patterns from bleeding through text. Reduced motion queries are implemented for all ambient animations.