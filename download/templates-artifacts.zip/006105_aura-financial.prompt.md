Recreate the website "Aura Financial" with high visual fidelity as a Tailwind CSS/HTML site. The result must match the supplied reference website, not a reinterpretation.

Preserve source quirks:
- Italic font treatment in the main H1 and the H2 of Section 3 and 4.
- Inconsistent icon sizes (some 24px, some 1em).
- Overlapping layout in the mobile view for the feature grid if not explicitly handled.
- Mixture of Newsreader (serif) and Inter (sans-serif) within single phrases.

CRITICAL FIDELITY CONSTRAINTS
- Background: Fixed #030303 with a grid-bg utility using linear-gradients and radial-gradient mask.
- Glassmorphism: Heavy use of backdrop-blur-xl/3xl and border-white/10 on floating elements.
- Color Palette: #38BDF8 (brand-sky), #050505 (brand-dark), #0F110E (brand-panel).
- Selection: selection:bg-brand-sky selection:text-black.
- Absence: No traditional external hero images; use the provided abstract SVG nodes and UnicornStudio canvas element.

TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN).
- Iconify (code.iconify.design) for Solar and Lucide icons.
- Google Fonts: Inter (300, 400, 500) and Newsreader (italic, 300, 400).
- UnicornStudio.js (v1.4.29) for the project "FixNvEwvWwbu3QX9qC3F".

GLOBAL STYLE
- Body: bg-[#030303], text-white, antialiased.
- Utility .text-glow: text-shadow: 0 0 25px rgba(56, 189, 248, 0.4).
- Utility .grid-bg: background-size: 100px 200px; mask-image: radial-gradient(circle at center, black 40%, transparent 100%).
- .shiny-cta: Complex CSS animation using @property for --gradient-angle, isolation: isolate, and nested ::before/::after for particles and shimmer.

ASSET MAP
- Hero Background Canvas: UnicornStudio project ID "FixNvEwvWwbu3QX9qC3F".
- Portrait Image: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/346c8983-c047-4169-902a-df1305819be6_800w.jpg
- Noise Texture: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/c55b9091-b0ca-4842-92d7-7be239f76440_1600w.webp
- Icons: solar:layers-minimalistic-bold-duotone, solar:arrow-right-bold-duotone, lucide:sparkles, lucide:zap, lucide:layers, lucide:gem, lucide:credit-card, ri:twitter-x-fill, ri:github-fill, ri:linkedin-fill, ri:discord-fill.

VECTOR / ICON SHAPES
- Logotype SVG: Path d="M4.929 4.929c-3.905 3.905..." with #38bdf8 fill.
- Marquee SVGs: Exact SVG paths for Logos:Vercel, Amplitude, and Airbnb (Monotone/White).
- Beams: SVG paths with stroke-dasharray: 80 1000 and .animate-beam keyframes.

LAYER STACK / POSITIONING MAP
- Background: fixed inset-0 grid-bg (z-0) + aura-background-component (z-10).
- Nav: fixed top-6 left-1/2 -translate-x-1/2 (z-50) pill-shaped.
- Content: relative container (z-10).
- Section Dividers: absolute top-0 w-full h-px gradient-to-r via-white/10.

SECTION 1 - HERO
- Left: h4 with animate-ping dot. H1 "Architect your wealth with absolute precision." (Newsreader italic for top line). P font-light. CTAs: .shiny-cta and glass-pill button.
- Right: SVG viewBox="0 0 600 600" containing central node with .animate-sonar rings and .animate-beam connecting paths. Labels "ZERO LATENCY" and "DEFI NATIVE".
- Bottom: Infinite marquee section with 40s linear animation and mask-gradient-fade. Trusted by label with [ ✓ ] indicator.

SECTION 2 - CAPABILITIES GRID
- Layout: 3-column grid of .spotlight-card elements. Each has a JS mouse-move listener for dynamic --mouse-x/y radial-gradient background.
- Card 1: Chat/Terminal UI with AURA_OS v2.1 header and pulse-animating progress bar.
- Card 2: Orbit visualization. Multiple absolute circles with spin-slow and spin-slow-reverse. Central glass panel with lucide-layers icon.
- Card 3: Multi-Sig Governance dashboard. Team avatars (JD, AS), 75% approval slider with absolute-positioned bounce-animating tooltip.

SECTION 3 - TESTIMONIAL
- Layout: 12-column grid. Col-span-4: Portrait image with grayscale mix-blend-luminosity. Col-span-8: Large blockquote with Newsreader font. Metric pill: "Portfolio Volume Up 17%".

SECTION 4 - EXCHANGE INFRA
- Card: #080808 background with border-white/10. Right side features an isometric device composition with device panels at rotate-x-6 rotate-y-[-6deg].

GLOBAL ANIMATION / INTERACTION RULES
- Spotlight Effect: JS mousemove listener on .spotlight-card updating CSS variables.
- Beams: strokeDashoffset animation from 1000 to 0.
- Sonar: @keyframes sonar-wave expanding 'r' from 10px to 80px with opacity fade.
- Marquee: translateX(0) to translateX(-50%) linear loop.

COMMON MISTAKES TO AVOID
- Do not substitute the specific .shiny-cta CSS for a basic hover effect.
- Do not forget the backdrop-blur on the fixed navigation.
- Do not use standard <img> tags for the SVG technical diagrams; use inline SVG to preserve animations.