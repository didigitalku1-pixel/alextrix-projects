Recreate the website "Minimalist Digital Studio UI" with high visual fidelity as a Tailwind CSS-based site.

The result must match the supplied reference website exactly, including the glassmorphism effects and the 3D background integration.

Preserve source quirks:
- The Spline 3D background is loaded via a fixed-position iframe that fills the entire viewport.
- The central "app preview" container has a hard-coded width of 768px on desktop but lacks explicit mobile scaling rules in the source classes; preserve the `w-[768px]` but ensure it handles overflow appropriately.
- The logo consists of two nested circles within a 24x24 SVG.

CRITICAL FIDELITY CONSTRAINTS
- The page must use a black background (`bg-black`) with white text.
- The background must be the specific Spline scene provided in the ASSET MAP.
- Do not add section scrolling or scroll animations unless explicitly described; the layout is a single-screen overflow-hidden hero concept.
- Use exact padding values: `pt-32 pb-32` for mobile hero, `pt-40 md:pb-40` for desktop.

TECH STACK / DEPENDENCIES
- Framework: HTML/Tailwind CSS
- Styling: Tailwind CDN (`https://cdn.tailwindcss.com`)
- Fonts: Google Fonts (Inter, IBM Plex Serif, IBM Plex Mono)
- External: Spline Viewer (via iframe)

GLOBAL STYLE
- Colors: dark: #000000, light: #ffffff, subtle: rgba(255,255,255,0.1)
- Font Family: Inter (primary), IBM Plex Serif, IBM Plex Mono
- Body: `bg-black text-white font-sans`

ASSET MAP
- 3D Background: `https://my.spline.design/thresholddarkambientui-v0gkZCfi6zXm69kE0wccy70f/`
- Google Fonts: `https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=IBM+Plex+Serif:wght@300;400;500;600;700&family=IBM+Plex+Mono:wght@300;400;500;600;700&family=Inter&display=swap`

VECTOR / ICON SHAPES
- Logo SVG: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="white" stroke-width="2" fill="none" /><circle cx="12" cy="12" r="3" fill="white" /></svg>`

MEDIA BEHAVIOR
- Spline Background: Contained in a `fixed inset-0 z-0` div. The iframe must have `frameborder="0"`, `width="100%"`, and `height="100%"`.

LAYER STACK / POSITIONING MAP
- Background (z-0): Spline iframe (fixed, inset-0).
- Navigation (z-50): Floating glass pill-shape navbar (fixed, top-6, left-1/2, -translate-x-1/2).
- Hero Content (z-10): Relative flex container with `min-h-screen`.
- Glow Layer (within z-10): Absolute circle `w-[600px] h-[600px]` with `blur-[100px]` and `opacity-5` centered behind text.

SECTION 1 - NAVIGATION
- Layout: Fixed top, rounded-full, backdrop-blur-md, bg-white bg-opacity-5, border-white border-opacity-10.
- Links: "Work", "Studio", "Process", "Journal", "Contact" (hidden on mobile, flex on md:).
- CTA: "Start Project" button (bg-white, text-black, rounded-full).

SECTION 2 - HERO SECTION
- Badge: "Design Studio" text in a small pill-shaped border `border-white border-opacity-20`.
- Heading: `md:text-6xl text-4xl` font-medium with `tracking-tighter`. Text: "Crafting digital experiences through minimalist design".
- Subtext: `text-neutral-300` max-width 2xl.
- CTAs: Primary (White bg, black text), Secondary (Transparent bg, white border, backdrop-blur).

SECTION 3 - APP PREVIEW (MOCKUP)
- Outer: `w-[768px] h-[400px]` black box, 40% opacity, backdrop-blur-md, rounded-lg.
- Window Chrome: Top bar with 3 decorative circles (w-3 h-3, bg-white/30).
- Internal Layout: Sidebar (w-48) and Main Content (flex-1), both with `bg-white bg-opacity-5` and `backdrop-blur-sm`.
- Content Elements: Abstract UI bars and a central circular shape with nested borders to simulate a dashboard interface.

GLOBAL ANIMATION / INTERACTION RULES
- All links/buttons use `transition-colors` or `transition-all` with `duration-300`.
- Primary buttons: `hover:bg-gray-200`.
- Glass buttons: `hover:bg-opacity-20`.

COMMON MISTAKES TO AVOID
- Do not forget the `backdrop-blur-md` on the navbar and mockup container.
- Do not use a solid background for the mockup; it must be semi-transparent to show the Spline background through it.
- Ensure the glow effect (`blur-[100px]`) is `pointer-events-none` so it doesn't block interactions.