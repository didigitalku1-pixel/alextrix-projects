---
version: 1.0.0
name: Sense Design System
description: A visual language for global community support and charitable impact.
colors:
  bg-primary: "#FFFFFF"
  bg-secondary: "#F5F5F5"
  text-primary: "#171717"
  text-secondary: "#525252"
  accent-blue: "#2563EB"
  accent-blue-dark: "#1D4ED8"
  accent-green: "#16A34A"
  accent-amber: "#D97706"
  surface-dark: "#0A0A0A"
  border-neutral: "rgba(0, 0, 0, 0.05)"
  glass-white: "rgba(255, 255, 255, 0.1)"
  glass-black: "rgba(0, 0, 0, 0.7)"
typography:
  font-family-sans: {"name": "Geist", "fallback": "Inter, sans-serif"}
  h1: {"size": "64px", "weight": "500", "tracking": "-0.05em", "leading": "1.05"}
  h2: {"size": "48px", "weight": "500", "tracking": "-0.025em", "leading": "1.05"}
  body-lg: {"size": "18px", "weight": "400", "leading": "1.625"}
  body-sm: {"size": "14px", "weight": "400", "leading": "1.5"}
  label: {"size": "12px", "weight": "500", "tracking": "0.05em"}
spacing:
  xs: "4px"
  sm: "12px"
  md: "24px"
  lg: "40px"
  xl: "80px"
  container-max: "1280px"
rounded:
  sm: "8px"
  md: "12px"
  lg: "16px"
  xl: "24px"
  huge: "32px"
  full: "9999px"
components:
  button-primary: {"bg": "#171717", "text": "#FFFFFF", "rounded": "9999px", "shadow": "0 100px 80px rgba(0,0,0,0.12)"}
  card-impact: {"bg": "#FFFFFF", "border": "1px solid rgba(0,0,0,0.05)", "rounded": "24px", "padding": "24px"}
  glass-pill: {"bg": "rgba(0,0,0,0.6)", "blur": "12px", "border": "1px solid rgba(255,255,255,0.1)"}
  input-field: {"bg": "#FFFFFF", "border": "1px solid #E5E5E5", "rounded": "16px"}
motion:
  curve: "cubic-bezier(0.4, 0, 0.2, 1)"
  duration-entry: "700ms"
  stagger-delay: "150ms"
---
## Overview
The Sense system is designed to convey trust, transparency, and global scale. It uses a clean white base with high-contrast neutral text, accented by deep blues and vibrant success greens to emphasize social impact.

## Colors
- **Neutral Palette**: Pure white backgrounds paired with Zinc/Neutral 900 for text. Secondary surfaces use Neutral 50 or 100.
- **Action Colors**: Primary buttons use a solid Neutral 900. Status and impact areas utilize Blue 600, Green 600, and Amber 600.
- **Translucency**: Extensive use of black-tinted glassmorphism (black/70) with backdrop-blur (12px-16px) for media overlays.

## Typography
- **Primary Heading**: Geist Sans is used for its geometric yet approachable character. Large headers (64px+) use tight tracking (-0.05em).
- **Body**: Inter serves as the secondary sans-serif for high readability in impact reports and form fields.

## Spacing
- **Grid**: Standard 12-column grid for desktop with 24px-40px gutters.
- **Vertical Rhythm**: Large sections are separated by 80px to 120px (mt-32 or mt-40) to maintain a premium, airy feel.

## Layout
- **Layer Stacks**: Media cards utilize a 'stacked' approach: Background Image -> Masking Gradient -> Marquee Layer -> Fixed Glass UI elements.
- **Floating UI**: Navigation and CTA elements often use absolute positioning with high z-indexes (z-20 to z-50) over background assets.
- **Containers**: Content is constrained to a 1280px (7xl) max-width with responsive padding (px-6 to px-8).

## Elevation & Depth
- **Multi-layered Shadows**: Specifically uses a 6-layer soft shadow for primary cards and buttons to simulate deep elevation over the white canvas.
- **Blur Masks**: Vertical marquees and media panels use linear-gradient masks (transparent to black) to create soft entry/exit points for scrolling content.

## Shapes
- **Extreme Rounding**: Elements use either a 'Huge' radius (32px) for sections/cards or 'Full' radius (999px) for buttons and status chips.
- **Ring Borders**: Low-opacity rings (ring-1 ring-black/5 or ring-white/10) provide definition without heavy visual weight.

## Components
- **Hero Panel**: A split-screen layout with text copy on the left and a complex media stack (scrolling marquee and glass cards) on the right.
- **Training Grid**: Interactive module buttons with hover-state transitions and right-aligned icons.
- **Impact Tier Cards**: Pricing-style cards with varied heights; the 'Champion' tier is emphasized using a solid Blue 700 background and inset shadows.
- **Partnership Form**: A rounded-rect container (32px) utilizing an internal grid to separate inputs from social proof highlights.

## Motion
- **Reveal Animations**: Page elements utilize a three-part entry: `opacity-0`, `translate-y-8`, and `blur-md` transitioning over 700ms.
- **Vertical Marquee**: Continuous linear animation (`marquee-vertical`) for testimonial and program grids, running at 40s per cycle.
- **Hover Transitions**: Smooth color and shadow shifts for all buttons and interactive module cards.

## Do's and Don'ts
- **Do**: Use backdrop-blur on all overlays placed on top of photography.
- **Do**: Maintain generous whitespace between section headers and content grids.
- **Don't**: Use sharp corners; every interactive or container element must have at least an 8px radius.
- **Don't**: Use heavy borders; prefer light 'ring' utilities and shadow-based depth.

## Accessibility
- **Contrast**: Maintain a minimum 4.5:1 ratio for text on white or glass backgrounds.
- **Interactive states**: All buttons and links must include `transition-colors` and visible focus rings.
- **Labels**: Use helper text and required field indicators (red/neutral asterisks) in all partnership forms.