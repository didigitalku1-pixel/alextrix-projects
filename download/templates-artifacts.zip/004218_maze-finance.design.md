---
version: "1.0.0"
name: "Maze Finance"
description: "A premium financial services landing page with a focus on depth, motion, and trust."
colors:
  background: "#030712"
  surface: "rgba(255, 255, 255, 0.05)"
  primary: "#6366f1"
  secondary: "#d946ef"
  text-main: "#f8fafc"
  text-muted: "#cbd5e1"
  accent-success: "#10b981"
  accent-warning: "#f59e0b"
  border: "rgba(255, 255, 255, 0.1)"
typography:
  display:
    family: "Inter, sans-serif"
    weight: 500
    tracking: "-0.05em"
  body:
    family: "Inter, sans-serif"
    weight: 400
    size: "16px"
  label:
    family: "Inter, sans-serif"
    weight: 600
    size: "12px"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "48px"
  section: "96px"
rounded:
  sm: "4px"
  md: "8px"
  lg: "12px"
  xl: "16px"
  full: "999px"
components:
  nav: "Fixed top, transparent background with blur, centered links."
  button-primary: "Linear gradient (Indigo/Violet/Fuchsia), shadow-lg, rounded-xl."
  card-glass: "bg-white/5, backdrop-blur-sm, border-gradient overlay."
  input: "bg-white/5, border-gradient, focus:ring-indigo-400."
  phone-mockup: "Layered z-index stack, rotated transforms, gradient inner panels."
motion:
  standard-fade: "fadeSlideIn 1s ease-out both"
  ticker: "Continuous translateX(-100%) linear"
---
## Overview
Maze Finance utilizes a 'Dark Glass' aesthetic. It relies on deep indigo/fuchsia background glows (blur-3xl) to create depth without using solid lines, and uses a custom `border-gradient` technique to simulate light catching on glass edges.

## Colors
- **Base**: Gray-950 for backgrounds to ensure high contrast for text.
- **Depth Glows**: Indigo-500/20 and Fuchsia-500/20 used as absolute-positioned blurs.
- **Action**: A 3-step gradient (Indigo-500 -> Violet-500 -> Fuchsia-500) for primary CTAs.
- **Status**: Emerald for positive growth; Rose for expenditures.

## Typography
- **Headings**: Inter font with 'tracking-tighter' and font-medium to maintain a professional, dense financial look.
- **Body**: Slate-300 for readability against dark backgrounds, preventing eye strain from pure white text.

## Spacing
- **Section Padding**: Standardized `py-24` (96px) for desktop and `py-10` (40px) for mobile.
- **Grid Gaps**: `gap-12` (48px) for major layout sections; `gap-3` (12px) for button groups.

## Layout
- **Container**: Max-width of 1280px (`max-w-7xl`) centered with `mx-auto`.
- **Layering**: -z-10 for background blobs, z-0 for content, and z-10 for interactive elements like the fixed header.
- **Responsive**: 1-column layout on mobile switching to 2-column or 3-column grids at the `lg` (1024px) breakpoint.

## Elevation & Depth
- **Glassmorphism**: Achieved via `bg-white/5` combined with `backdrop-blur`.
- **Border Gradient**: A pseudo-element technique using `-webkit-mask` to create 1px strokes that look like metallic or glass edges.

## Shapes
- **Cards**: Large 24px-32px rounding for outer containers; 12px-16px for inner components.
- **Indicators**: Pill-shaped buttons and status chips for a friendly, modern tech feel.

## Components
- **Pricing Cards**: Features a 'Most Popular' badge with an indigo-to-fuchsia gradient shadow.
- **Ticker**: An infinite-loop horizontal scroll for partner logos with a linear-gradient mask for soft edges.
- **Mobile Mockups**: Nested containers simulating phone screens with internal dashboards and mini-cards.

## Motion
- **Scroll Entrance**: Elements use `animate-on-scroll` which triggers `fadeSlideIn` (opacity 0 + translateY 30px to full visibility).
- **Hover States**: Interactive elements use `hover:-translate-y-1` and `hover:scale-[1.1]` for tactile feedback.

## Do's and Don'ts
- **Do**: Use high-blur background glows to define section areas.
- **Do**: Apply the `border-gradient` class to any component using a dark glass background.
- **Don't**: Use solid bright backgrounds; stay within the dark mode spectrum.
- **Don't**: Use sharp 90-degree corners; maintain a minimum of 8px rounding.

## Accessibility
- **Contrast**: Maintain Slate-300 or higher on Gray-950 for body text.
- **Focus**: All inputs must have an explicit `focus:ring` in a contrasting color (Indigo-400).
- **Screen Readers**: Use `sr-only` labels for icon-only buttons or decorative inputs.