Recreate the website "Luminous - AI Social Automation" with high visual fidelity as a Tailwind CSS and Vanilla JS site. The result must match the supplied reference exactly, preserving the dark futuristic aesthetic, precise layer ordering, and interaction logic.

### Preserve Source Quirks:
- Headings use mixed case and line breaks (e.g., "SOCIAL REACH [space] AUTOMATED [br] GROWTH VIRAL [br] RESULTS").
- The logo consists of two overlaid Lucide asterisk icons, one rotated 45 degrees.
- Some sections feature a "01.", "02.", "03." large background-style numbering in 5% opacity white.
- The pricing section uses a complex SVG "animate-flow" connector system between plan buttons and the detail card.

### CRITICAL FIDELITY CONSTRAINTS
- Background must be exact hex `#050505` with specific radial gradients and a star pattern created via multiple `radial-gradient` backgrounds on a single `stars` class.
- No images should be substituted; use the exact URLs provided in the ASSET MAP.
- Stacking contexts must be strictly followed (fixed background < absolute glows < relative content < relative z-50 nav).
- The Bricolage Grotesque font must be applied to headings, while Inter is used for body copy.

### TECH STACK / DEPENDENCIES
- CSS: Tailwind CSS (CDN: `https://cdn.tailwindcss.com`)
- Icons: Lucide Icons (`https://unpkg.com/lucide@latest`)
- Fonts: Google Fonts (Inter, Bricolage Grotesque)
- Animation: CSS Keyframes (fadeInUpBlur, animationIn, flow, spin)
- Interactive: Vanilla JS for Intersection Observer (animate-on-scroll), Testimonial state management, and Pricing plan selection.

### GLOBAL STYLE
- **Page Background:** `#050505` with `overflow-x-hidden`.
- **Selection Color:** `selection:bg-orange-500/30`.
- **Custom Effects:** `.electric-card` with specific box-shadows and `.grid-bg` with 1px white/5 lines at 24px intervals.

### ASSET MAP
- **Testimonial 1 / Default:** `https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/649a17f7-ce90-412e-bc8c-6227953b3ba4_1600w.webp`
- **Testimonial 2:** `https://images.unsplash.com/photo-1640906152676-dace6710d24b?w=2160&q=80`
- **Testimonial 3:** `https://images.unsplash.com/photo-1629946832022-c327f74956e0?w=2160&q=80`
- **Footer Background:** `https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/f5347579-34d0-43b9-99d3-126f6193d19d_1600w.jpg`

### VECTOR / ICON SHAPES
- **Hero Chart Path:** `<path d="M0 50 C 40 50, 60 30, 100 35 C 140 40, 160 10, 200 15 C 240 20, 260 5, 280 0 V 60 H 0 Z" fill="url(#chartGradient)">`
- **Pricing Paths:** Use ID `path-creator`, `path-pro`, and `path-agency` with `stroke-dasharray="8 8"` and `animate-flow` class.

### LAYER STACK / POSITIONING MAP
- **Global Background Layer:** `fixed z-0`. Contains `.stars` (inset-0) and two blurred blobs: orange-900/10 (top-0, left-1/2, -translate-x-1/2) and orange-950/20 (bottom-0, right-0).
- **Section Structure:** Every major section is a `max-w-7xl mx-auto` container with `relative` positioning and specific entrance animations.

### SECTION 1 - HERO
- **Layout:** 12-column grid. Left span-7 (text), Right span-5 (electric-card).
- **Electric Card:** Inner background `#0A0A0A`, absolute orange-300 gradient border, inner glow gradient (top-0, h-40).
- **Stat:** "+842%" using `bg-clip-text` and `bg-gradient-to-r from-white via-orange-200 to-orange-400`.

### SECTION 2 - APP SHOWCASE
- **Dashboard Shell:** `bg-neutral-900/80` with `backdrop-blur-sm` and `ring-white/10`.
- **Sidebar:** Left sidebar `bg-white/5` with exact Lucide icons (zap, layout-grid, trending-up, users).
- **Interaction:** One metric card features a progress bar with `w-[67%]` and a pulse animation on the "Live" indicator.

### SECTION 3 - FEATURES ORBIT
- **Orbit Animation:** Central asterisk icon with three rotating rings (180px, 340px, 500px).
- **Social Orbitals:** 6 platforms (Twitter, Facebook, Instagram, TikTok, YouTube, LinkedIn) placed using `rotate(deg) translateY(-170px) rotate(-deg)` and a counter-rotation animation `animate-[spin_60s_linear_infinite_reverse]`.

### SECTION 4 - TESTIMONIALS
- **Carousel Logic:** Javascript-driven. On `nextTestimonial()`, fade out `t-quote`, `t-author`, `t-role`, and `t-image` (opacity 0), update content from array, then fade in (opacity 1) after 300ms.

### SECTION 5 - PRICING
- **Interactive Tabs:** Plan selection updates the `selectPlan(planKey)` state. Active button gets `bg-gradient-to-r from-orange-500 to-amber-500`. Inactive buttons get `bg-[#181824]`.
- **SVG Flow:** The path connecting the active button to the detail card changes color to `#f97316`, gains a shadow, and activates the `animate-flow` dash-offset animation.

### GLOBAL ANIMATION / INTERACTION RULES
- **Intersection Observer:** Use `window.__inViewIO` with a 0.2 threshold to add the `.animate` class to elements with `animate-on-scroll`.
- **Keyframes:**
  - `animationIn`: translateY 30px -> 0, blur 8px -> 0, opacity 0 -> 1.
  - `flow`: stroke-dashoffset 24 -> 0.
  - `spin`: 360deg rotation over 60s.

### IMPLEMENTATION REQUIREMENTS
- Build the landing page as the first screen.
- Use exact text, asset URLs, and section order.
- Use explicit CSS for absolute/fixed/sticky layers.
- Preserve exact custom SVG paths and media attributes.
- Final page should feel indistinguishable from the source HTML.