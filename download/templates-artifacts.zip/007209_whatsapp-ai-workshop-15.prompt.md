Recreate the website "WhatsApp Control Center" with high visual fidelity as a Tailwind CSS and HTML site.

The result must match the supplied reference website, not a cleaned-up reinterpretation.

Preserve source quirks:
- The navigation bar is offset by `top-10` because of the fixed announcement bar.
- The grid background uses a linear gradient mask that fades to transparent at 100% height.
- Several sections use `bg-neutral-900/10` or `bg-black/50` for subtle layering.

CRITICAL FIDELITY CONSTRAINTS
- Backgrounds: Use the exact `#030303` body color. The `grid-bg` must use 40px sizing with `#171717` lines and a `linear-gradient` mask.
- Typography: Primary font is 'Inter'. Secondary fonts 'Geist', 'Roboto', etc., are imported but Inter is the active body family.
- Interaction: The CTA button in the Hero must have a hover state that translates the arrow icon: `group-hover:translate-x-1`.
- Spacing: Hero top padding must be exactly `pt-40` to account for the double-header (Announcement + Nav).

TECH STACK / DEPENDENCIES
- CSS: Tailwind CSS (CDN: https://cdn.tailwindcss.com)
- Icons: Iconify (CDN: https://code.iconify.design/3/3.1.0/iconify.min.js) and custom SVGs.
- Fonts: Google Fonts (Inter, Geist, etc.) as listed in SOURCE INVENTORY.

GLOBAL STYLE
- Body: `background-color: #030303; color: #d4d4d4; font-family: 'Inter', sans-serif;`.
- Selection: `selection:bg-emerald-500/30 selection:text-emerald-200`.
- Custom Classes:
  - `.glow-green`: `radial-gradient(circle at center, rgba(16, 185, 129, 0.15) 0%, rgba(0, 0, 0, 0) 70%)`
  - `.glow-center`: `radial-gradient(circle at center, rgba(16, 185, 129, 0.3) 0%, rgba(0, 0, 0, 0) 60%)`
  - `.grid-bg`: `linear-gradient(to right, #171717 1px, transparent 1px), linear-gradient(to bottom, #171717 1px, transparent 1px); background-size: 40px 40px; mask-image: linear-gradient(to bottom, black 40%, transparent 100%);`.

ASSET MAP
- Main CTA: `https://tally.so/r/XxLeKV`
- Icons: `lucide:check-circle-2`, `lucide:bot`, `lucide:play-circle`, `lucide:arrow-right`, `lucide:zap`, `lucide:message-circle`, `lucide:sparkles`, `lucide:file-text`, `lucide:calendar`, `lucide:users`, `lucide:credit-card`, `lucide:cable`, `lucide:git-fork`, `lucide:mic`, `lucide:database`, `lucide:webhook`, `lucide:film`, `lucide:clock`, `lucide:file-json`, `lucide:play`, `lucide:download`, `lucide:help-circle`.

VECTOR / ICON SHAPES
- Preserve the complex path for the WhatsApp logo icon (SOURCE INVENTORY Item 12) inside the Central Node of the Ecosystem section.
- Preserve all custom SVG paths for connectors (SVG Items 33-37).

LAYER STACK / POSITIONING MAP
- Announcement Bar: `fixed top-0`, `z-[60]`, `h-10`, `bg-emerald-900/20`, `backdrop-blur-md`.
- Navigation: `fixed top-10`, `z-50`, `h-16`, `bg-black/50`, `backdrop-blur-md`.
- Background 1: `.grid-bg`, `fixed inset-0`, `-z-10`.
- Background 2: `.glow-green`, `fixed top-0`, `max-w-3xl`, `h-96`, `-z-10`, `blur-3xl`, `opacity-50`.
- Pricing Card: `relative z-10`, `bg-neutral-900/80`, `backdrop-blur-xl`, `shadow-2xl`.

SECTION 1 - ANNOUNCEMENT BAR
- Content: "Disponibilité : Replay et Template accessibles immédiatement" with link "Accéder maintenant".
- Style: Emerald theme, border-b `border-emerald-500/20`.

SECTION 2 - HERO
- Layout: `pt-40`, `max-w-4xl`, center-aligned.
- Copy: "Construisez l'IA qui pilote votre business." with gradient text on the second line.
- Button: White background, black text, `hover:bg-neutral-200`, with `lucide:arrow-right`.

SECTION 3 - ECOSYSTEM (HUB CENTRAL)
- Layout: Graphic with connector lines.
- Center Node: Emerald glow, custom WhatsApp SVG.
- Floating Nodes: Absolute positions (Top 15%, Top 30% L/R, Bottom 30% L/R), `bg-neutral-900/80`, `backdrop-blur-sm`.

SECTION 4 - FEATURES BENTO GRID
- Layout: `md:grid-cols-3` top row, `md:grid-cols-2` bottom row.
- Style: `conic-gradient` container, individual cells with `hover:bg-white/5` and specific color accents (Emerald, Blue, Purple, Orange, Pink).

SECTION 5 - PRICING (PACK REPLAY)
- Container: `max-w-md`, shadow-black/50, `border-emerald-500/20`.
- Badge: `absolute top-0 right-0`, emerald, "DISPONIBLE".
- Button: `bg-white`, black text, link to Tally.

GLOBAL ANIMATION / INTERACTION RULES
- All buttons use `transition-colors` or `transition-all`.
- Icons in hover-parent containers use `group-hover:translate-x-1`.
- Scroll behavior is `scroll-smooth`.

COMMON MISTAKES TO AVOID
- Do not skip the `top-10` offset for the Nav bar; it will overlap the Announcement bar.
- Do not use solid backgrounds; the grid and glow layers must remain visible through `backdrop-blur` and transparency.
- Ensure the specific `conic-gradient` is used for the features grid wrapper.