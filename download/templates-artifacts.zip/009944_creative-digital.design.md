---
version: 1.0.0
name: Creative Digital Designer System
description: A premium visual language for digital creators featuring stark dark aesthetics, crimson accents, and heavy motion-based reveals.
colors:
  background: "#000000"
  surface: "#1a1818"
  primary: "#ef233c"
  primaryShine: "#dc2626"
  textMain: "#ffffff"
  textSecondary: "#9ca3af"
  textMuted: "#52525b"
  border: "#27272a"
  borderDashed: "#3f3f46"
typography:
  headings:
    family: "Manrope"
    weight: "500"
    letterSpacing: "-0.05em"
  body:
    family: "Inter"
    weight: "400"
    lineHeight: "1.6"
  accent:
    family: "Geist"
    weight: "600"
  utility:
    family: "Space Mono"
    weight: "400"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "40px"
  hero: "128px"
rounded:
  none: "0px"
  sm: "4px"
  md: "8px"
  lg: "12px"
  full: "9999px"
components:
  nav:
    background: "rgba(0, 0, 0, 0.6)"
    blur: "12px"
    border: "linear-gradient(135deg, rgba(255, 255, 255, 0.2), transparent)"
  hero:
    alignment: "center"
    mask: "linear-gradient(180deg, transparent, black 0%, black 95%, transparent)"
  shinyButton:
    gradientAngle: "0deg"
    borderSpin: "2.5s linear infinite"
    activeTransform: "translateY(1px)"
  featureCard:
    borderStyle: "dashed"
    hoverBorder: "rgba(255, 255, 255, 0.2)"
    background: "rgba(24, 24, 27, 0.4)"
  input:
    borderBottom: "1px solid rgba(255, 255, 255, 0.1)"
    focusColor: "#ef233c"
motion:
  fadeSlideIn: "1s ease-out both"
  columnReveal: "1.4s cubic-bezier(0.16, 1, 0.3, 1)"
  shimmer: "4s linear infinite"
---
## Overview
The Creative system is designed for maximum visual impact in high-traffic landing pages. It uses a pure black canvas to allow red accents and white typography to pop. The system relies heavily on "Progressive Blur" layers and complex conic-gradient borders to simulate high-end hardware design aesthetics.

## Colors
The palette is minimal, dominated by Black and Zinc grays. The primary accent is a vibrant Red (#ef233c), used specifically for interactive states and primary call-to-actions. Background glows use low-opacity versions (10% or less) of red and blue to provide depth without breaking the dark-mode immersion.

## Typography
- **Manrope** is used for large headings to provide a modern, structural feel.
- **Inter** handles high-readability body copy.
- **Geist** is used for specialized UI elements requiring a technical, developer-centric look.
- Text scaling follows a tight hierarchy with heavy use of `tracking-tighter` on large display items.

## Spacing
A hybrid spacing system is used. Sections are separated by large gaps (80px to 128px), while interior component spacing (like feature cards) uses a strict 8px-based grid. Navigation uses fixed paddings to maintain a slim, floating bar profile.

## Layout
- **Layering**: High use of `z-index` to separate fixed navigation (50), progressive blurs (5), and background components (-10).
- **Bento Grid**: Features are displayed in a 6-column or 12-column CSS grid that collapses gracefully on mobile.
- **Masonry Reviews**: Testimonials use staggered column heights to create a dynamic vertical flow.

## Elevation & Depth
Depth is achieved through `backdrop-blur-lg` rather than traditional drop shadows. Borders often use `mask-composite: exclude` gradients to create thin, crisp glass edges. Fixed "Progressive Blur" strips at the top of the viewport create a seamless transition during scrolling.

## Shapes
- **Sharp vs. Round**: The system mixes hard `rounded-none` edges for cards and structural containers with `rounded-full` for utility badges and primary action buttons.
- **Dashed Borders**: Secondary containers use `border-dashed` to evoke a blueprint or "work-in-progress" creative aesthetic.

## Components
- **Nav**: A floating, glassmorphic pill with a gradient border.
- **Shiny CTA**: A complex button component with a rotating conic-gradient border and internal radial glow.
- **Review Cards**: Semi-transparent panels with top-aligned star ratings and bottom-aligned attribution.
- **Pricing Cards**: Three distinct tiers including a "Scale" (Most Popular) tier with an enhanced red glow effect.
- **Contact Form**: Minimalist, peer-labeled inputs with animated bottom-border transitions.

## Motion
- **Reveal Animations**: Sections use a `fadeSlideIn` keyframe triggered by intersection observers.
- **Infinite Scroll**: Partner logos move in a seamless horizontal loop with a `grayscale` to `color` hover transition.
- **3D Transforms**: Utilities are defined for perspective and X/Y rotation for subtle card tilt effects.

## Do's and Don'ts
- **Do**: Use high-contrast gradients for borders to simulate light hitting glass.
- **Do**: Maintain a 100% black background for the body to ensure glow effects work.
- **Don't**: Use heavy solid backgrounds for cards; stick to low-opacity zinc with blurs.
- **Don't**: Use standard blue links; prefer white text with red-accented underlines or arrows.

## Accessibility
- Use `selection:bg-red-600/30` for branded yet readable text highlights.
- Ensure form labels are always present, even if positioned as placeholders initially.
- High contrast ratios are maintained by using pure white or high-zinc gray on black backgrounds.