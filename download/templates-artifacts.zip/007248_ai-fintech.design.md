---
version: 1.0.0
name: Fabric Design System
description: A futuristic, dark-themed visual language for AI financial protocols and machine-to-machine commerce.
colors:
  background: "#000000"
  surface: "#050505"
  surface-elevated: "#0a0a0a"
  primary: "#22d3ee"
  primary-muted: "#0e7490"
  secondary: "#0ea5e9"
  accent: "#6366f1"
  text-primary: "#ffffff"
  text-secondary: "#9ca3af"
  text-muted: "#4b5563"
  border: "rgba(255, 255, 255, 0.05)"
typography:
  sans:
    family: "Inter, sans-serif"
    weights: [200, 400, 500, 600]
  serif:
    family: "Newsreader, serif"
    weights: [300, 500, 700]
  mono:
    family: "Geist Mono, monospace"
    weights: [400]
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "32px"
  section: "128px"
rounded:
  sm: "4px"
  md: "8px"
  lg: "12px"
  xl: "16px"
  full: "999px"
components:
  nav: "Sticky top-0 backdrop-blur-md background-black/60 with 1px border-bottom white/5"
  hero: "Bipartite serif headline layout with absolute background grid lines and vertical beam animations"
  button-primary: "High-saturation cyan gradient with bottom shadow offset and glow blur background"
  button-secondary: "Pill-shaped with white/3 border-gradient and hover background white/5"
  card: "Glassmorphism effect using white/2 background, spotlight-border gradients, and internal padding lg"
  feature-grid: "Responsive 3-column layout with hover-activated spotlight-card radial gradients"
  pricing-table: "Monolithic dark blocks with cyan highlights and fixed-width comparison columns"
motion:
  speed: "40s linear marquee, 8s linear beam"
  transition: "0.8s ease-out scroll reveal with 30px translate and 8px blur"
---
## Overview
Fabric is a high-contrast visual system designed for the "Agent Economy." It emphasizes technical precision, cryptographic security, and financial authority through the use of dark surfaces, serif typography, and motion-heavy interactive states.

## Colors
The palette is rooted in deep blacks (`#000000` to `#0a0a0a`) to simulate terminal environments. Cyan and Sky Blue serve as the primary action colors, symbolizing "liquidity" and "intelligence," while Indigo and Amber are used sparingly for status states like governance and warnings.

## Typography
- **Serif (Newsreader):** Used for headlines and quotes to convey prestige and trust. Often rendered in italics for the "liquidity" concept.
- **Sans (Inter):** Used for UI controls, body text, and navigational elements for maximum legibility.
- **Mono (Geist Mono):** Applied to technical labels (e.g., `01_PROTOCOL`) and transaction IDs to emphasize the programmatic nature of the platform.

## Spacing
Based on a 4px baseline. Section spacing is aggressive (128px) to provide focus on individual value propositions. Content cards use consistent 24px (lg) padding for a breathable, premium feel.

## Layout
The layout uses a fixed 12-column grid background as a decorative element. Sections are constrained to a max-width of `7xl` (1280px). Layering is critical: background grid lines reside at `z-0`, primary content at `z-10`, and sticky navigation at `z-40`.

## Elevation & Depth
Depth is created through light rather than shadow. Radial gradients (spotlights) that track the mouse cursor provide a sense of illumination on dark surfaces. Border gradients and subtle sheen lines (1px) are used to define component boundaries without heavy fills.

## Shapes
Rounded corners are used to soften the technical edge. Large containers use 16px (xl) or 12px (lg) radii, while interactive buttons and badges use full (999px) pill rounding for a modern, fluid aesthetic.

## Components
- **Navigation:** Transparent, sticky bar with subtle text hover states and a high-contrast pill button for primary CTA.
- **Hero Section:** Split-headline design utilizing a mix of serif italics and sans-serif light weights for high-impact visual storytelling.
- **Spotlight Cards:** Background-neutral cards that reveal a radial cyan glow on hover, utilizing `mask-composite` for refined border effects.
- **Status Chips:** Small, mono-spaced tags with translucent backgrounds (e.g., `cyan-950/50`) and high-contrast text.

## Motion
- **Marquee:** Constant linear movement for partner logos to suggest global reach.
- **Beams:** Vertical light trails that move at varying speeds (6s to 11s) along background grid lines.
- **Entrance:** Content utilizes a `0.8s` ease-out animation that combines a vertical slide, opacity fade, and a blur-to-focus effect triggered by scroll visibility.

## Do's and Don'ts
- **Do:** Use Newsreader Italic for emotional or high-value messaging.
- **Do:** Use primary cyan for active states and data visualization.
- **Don't:** Use heavy drop shadows; prefer inner borders and glow effects for elevation.
- **Don't:** Introduce vibrant background colors; the system must remain strictly dark-mode.

## Accessibility
- Minimum contrast for primary body text is maintained at `gray-300` against black.
- Interactive elements must include `transition-colors` and `duration-200` to provide feedback for users with motor sensitivities.
- Critical information (e.g., transaction status) must include both an icon and a text label to support color-blind users.