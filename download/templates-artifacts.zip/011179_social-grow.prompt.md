Recreate the website "Social Grow" with high visual fidelity as a Tailwind CSS and vanilla JavaScript landing page.

The result must match the supplied reference website exactly, including its warm aesthetic and precise layout.

### SOURCE QUIRKS
- The page uses a mix of multiple Serif and Sans fonts (Manrope, Playfair Display, and others) but the primary body is `font-sans` with a specific background hex of `#E3DDD7`.
- One section (Theo Case Study) uses an inline style for `Brush Script MT` which differs from the global font stack.
- The "Scaling a beauty brand" heading has a minor HTML syntax quirk in the source (`leading-[0.95]="" mb-6""`) which should be normalized to standard Tailwind classes: `text-4xl md:text-6xl font-semibold tracking-tight text-gray-900 leading-[0.95] mb-6`.

### CRITICAL FIDELITY CONSTRAINTS
- Background color: `#E3DDD7` must be applied to the body.
- Animations: All sections must use the `animate-enter` class (custom keyframe `slideUpBlur`) with staggered delays (`delay-100` to `delay-500`).
- Exact image URLs and Iconify icon names must be used.
- The mobile menu must be a fixed overlay with an opacity transition.

### TECH STACK / DEPENDENCIES
- CSS: Tailwind CSS (via CDN: https://cdn.tailwindcss.com)
- Icons: Iconify (via CDN: https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js)
- Fonts: Google Fonts (Manrope, Playfair Display, Instrument Serif)

### GLOBAL STYLE
- Body: `text-gray-900 font-sans antialiased overflow-x-hidden bg-[#E3DDD7]`
- Custom Animations:
  - `slideUpBlur`: 0% (opacity 0, Y: 30px, blur 10px) to 100% (opacity 1, Y: 0, blur 0).
  - `sonarWave`: scale 0.9/opacity 0.8 to scale 2.5/opacity 0.
  - `cardEnter`: Scale 0.95/X: 20px to Scale 1/X: 0.

### ASSET MAP
- Hero Phone Card 1: `https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1000&auto=format&fit=crop` (Avatar: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80`)
- Hero Phone Card 2: `https://images.unsplash.com/photo-1550009158-9ebf69173e03?q=80&w=1000&auto=format&fit=crop`
- Hero Phone Card 3: `https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?q=80&w=1000&auto=format&fit=crop` (Avatar: `https://images.unsplash.com/photo-1504754524776-8f4f37790ca0?auto=format&fit=crop&w=100&q=80`)
- Case Study 1: `https://images.unsplash.com/photo-1616683693504-3ea7e9ad6fec?q=80&w=800&auto=format&fit=crop`
- Case Study 2: `https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=800&auto=format&fit=crop`
- Testimonial Visual: `https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/917d6f93-fb36-439a-8c48-884b67b35381_1600w.jpg`
- Team: Sofia (`...photo-1524504388940-b1c1722653e1`), James (`...photo-1506794778202-cad84cf45f1d`), Maya (`...photo-1531746020798-e6953c6e8e04`)

### VECTOR / ICON SHAPES
- Section Divider Path: `<path d="M150,20 C300,80 500,-40 650,20 C800,80 1000,-40 1150,20" stroke="currentColor" stroke-width="2" fill="none" stroke-dasharray="8 8"></path>`

### MEDIA BEHAVIOR
- Phone Carousel: Cards transition using `.card-active` (display: block + cardEnter) and `.card-hidden` (display: none). Auto-slides every 4000ms. JS must handle `setInterval` and `clearInterval` on manual click.

### LAYER STACK / POSITIONING MAP
- Navbar: `z-[500]`, Mobile Overlay: `z-[300]`, Navigation Arrows: `z-20` on Hero.
- Phone Mockup: `8px border-white`, `ring-1 ring-gray-900/5`, contains a `z-30` Dynamic Island and `z-20` reaction icons on the right.
- "Difference" Section: `z-10` container, Glowhaus Case Study: `order-1 lg:order-2` (Reverse on desktop).

### SECTION DETAIL HIGHLIGHTS
- **Hero**: Headline "Content that converts" with "converts" in italic serif. Stats section at bottom with 250M+ and 3.5x ROAS. Phone mockup uses absolute positioning for UI overlays ( Jessica_style label, sonar view shop button).
- **Services**: 3-column grid. Cards use `bg-white/40 backdrop-blur-sm`. Hover state transforms icons with `group-hover:scale-110`.
- **Process (How we work)**: Features the dotted SVG path behind three steps. Step 2 (Create & Manage) is the only black card in the set.
- **Difference Section**: Comparison between "Other Agencies" (gray/muted) and "Social Grow" (white card with a black top border and `solar:check-circle-bold` icons).
- **FAQ**: Uses HTML `<details>` and `<summary>` elements. Custom transition: `group-open:rotate-45` on the plus icon.
- **Footer**: Split into a CTA card (left) and a decorative phone illustration (right). Social links and navigation columns at the very bottom.

### IMPLEMENTATION REQUIREMENTS
- Recreate the exact animation timings: `0.8s cubic-bezier(0.16, 1, 0.3, 1)`.
- Preserve the precise `rotate-[-12deg]` transform on the footer phone mockup that rights itself on hover.
- Maintain all responsive breakpoints (`md:`, `lg:`) exactly as defined in the source classes.