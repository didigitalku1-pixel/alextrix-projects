---
version: 1.0.0
name: PulseBoard Global
description: A premium dark-mode system utilizing technical schematics, 3D depth, and motion-heavy layouts.
colors:
  background: "#030303"
  surface: "#0a0a0a"
  surface-glass: "rgba(255, 255, 255, 0.03)"
  primary: "#ffffff"
  secondary: "#525252"
  accent: "#3b82f6"
  border: "rgba(255, 255, 255, 0.1)"
  muted: "#171717"
typography:
  display:
    family: "Space Grotesk"
    weight: "700"
    letterSpacing: "-0.05em"
  body:
    family: "Manrope"
    weight: "400"
    letterSpacing: "normal"
  mono:
    family: "Geist Mono"
    weight: "400"
    letterSpacing: "0.1em"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "32px"
  xl: "64px"
  section: "160px"
rounded:
  sm: "2px"
  md: "8px"
  lg: "16px"
  full: "999px"
components:
  nav:
    layout: "fixed sticky top-0"
    background: "glass"
    radius: "999px"
    padding: "16px 32px"
  hero:
    alignment: "center"
    mask-reveal: "overflow-hidden with translateY(110%)"
    background: "canvas-animated"
  cards-3d:
    perspective: "1000px"
    transform: "preserve-3d"
    depth-element: "translateZ(40px)"
  button:
    base: "rounded-full uppercase font-bold text-[10px]"
    padding: "8px 24px"
motion:
  smooth-scroll: "Lenis 0.8s duration"
  parallax: "GSAP ScrollTrigger with custom speed data-attributes"
  hover: "Custom circle cursor with mix-blend-mode exclusion"
---
## Overview
PulseBoard is a visual language defined by "Engineering Perfection." It balances high-density technical information (monospaced labels, data grids) with expansive, breathable layouts and smooth, physics-based motion.

## Colors
The palette is monochromatic with a focus on depth. It uses `#030303` as the base, layering semi-transparent whites for borders and glass effects. Neutral grays (`#525252`) are used for secondary information to maintain a strict visual hierarchy.

## Typography
- **Display**: Space Grotesk is used for headlines to convey a technical, modern edge.
- **Interface**: Manrope provides a legible, friendly counterpoint for body copy.
- **System Data**: Geist Mono or Space Mono is strictly for labels, code snippets, and metrics.

## Spacing
A generous spacing scale is used to define boundaries. Hero sections utilize `160px` vertical padding, while UI components like the Navbar use `16px` internal padding within a floating `999px` capsule.

## Layout
Layouts are constructed using high-contrast layer stacks:
- **Background**: Canvas streams or SVG noise textures at low opacity (5%).
- **Midground**: Absolute positioned gradient glows and radial grids.
- **Foreground**: High-density 3D cards and mask-revealed typography.
- **Overlay**: Fixed navigation and a custom cursor with `z-index: 9999`.

## Elevation & Depth
Depth is not achieved through drop shadows but through 3D transforms (`perspective: 1000px`) and `backdrop-filter: blur(10px)`. Elements use `translateZ` to pop internal components out of their parent containers during interaction.

## Shapes
Primary shapes are either strictly geometric (rectangles for containers) or organic capsules (rounded-full for buttons and nav). Small `2px` rounded corners on icons provide a "blueprint" aesthetic.

## Components
- **The Portal**: A scroll-triggered image expander that pins the viewport and scales from 30% to 100% width.
- **3D Service Cards**: Interactive containers with nested layers that respond to mouse movement.
- **Testimonial Columns**: Vertical stacks that move at different speeds (`data-speed`) to create a parallax scrolling effect.
- **Status Badges**: Small, bordered capsules with a pulsing dot to indicate "active" states.

## Motion
Motion is purposeful and connected to the scroll position. Mask reveals for text should use `power3.out` easing. The custom cursor must transition between a border-only state and a solid circle (`mix-blend-mode: exclusion`) when hovering over interactive targets.

## Do's and Don'ts
- **Do**: Use grayscale images with hover-to-color transitions.
- **Do**: Maintain high contrast between primary text and secondary labels.
- **Don't**: Use traditional drop shadows; use borders and blurs for separation.
- **Don't**: Use vibrant colors outside of small terminal-style syntax highlighting.

## Accessibility
Ensure all glassmorphic components maintain a minimum `1px` border to define boundaries against the black background. All interactive elements must have a `hover-trigger` class to communicate state changes to the custom cursor system.