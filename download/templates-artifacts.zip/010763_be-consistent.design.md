---
version: 1.0.0
name: Sakura Productivity System
description: A premium enterprise SaaS landing page system featuring dark mode aesthetics, high-contrast typography, and fluid glow effects.
colors:
  background: "#050505"
  foreground: "#FFFFFF"
  neutral-primary: "#A3A3A3"
  neutral-secondary: "#525252"
  accent-blue: "#2563EB"
  accent-indigo: "#4F46E5"
  success-green: "#4ADE80"
  warning-orange: "#FB923C"
  border-low: "rgba(255, 255, 255, 0.05)"
  border-high: "rgba(255, 255, 255, 0.15)"
typography:
  display:
    family: "Oswald"
    weight: "300"
    lineHeight: "1.05"
  body:
    family: "Inter"
    weight: "400"
    lineHeight: "1.625"
  mono:
    family: "monospace"
    weight: "400"
    letterSpacing: "0.05em"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "48px"
  section: "96px"
rounded:
  sm: "4px"
  md: "8px"
  lg: "12px"
  xl: "16px"
  panel: "24px"
  card: "32px"
  full: "999px"
components:
  nav:
    position: "sticky"
    top: "16px"
    backdropBlur: "xl"
    border: "1px solid rgba(255,255,255,0.1)"
  hero:
    headlineSize: "76px"
    alignment: "left"
  cards:
    variant: "electric"
    glow: "0 0 30px rgba(59, 130, 246, 0.3)"
    innerPadding: "32px"
  buttons:
    primary: "bg-blue-600 rounded-full"
    secondary: "bg-white/5 border-white/10 rounded-full"
  workspace_preview:
    layout: "12-column grid"
    sidebar_width: "col-span-2"
    main_width: "col-span-7"
motion:
  entry: "fadeInUpBlur 1s cubic-bezier(0.2,0.8,0.2,1)"
  hover_scale: "1.02"
  glow_pulse: "breathe-glow 4s ease-in-out infinite"
---
## Overview
Sakura is a visual system designed for high-performance enterprise tools. It combines a deep black background with vibrant blue/indigo glow effects to create a "focused" environment. The system uses Oswald for high-impact headlines and Inter for legible data management.

## Colors
The palette is rooted in an absolute black background (#050505). Interactive elements use an Indigo-to-Blue gradient. Success and warning states are handled via semantic emerald and orange shades, often accompanied by a matching 10% opacity background glow and a subtle outer-glow (drop-shadow).

## Typography
- **Display Typography**: Oswald (Light/300) is used exclusively for H1 and H2 elements to provide a professional, architectural feel.
- **Interface Typography**: Inter (Regular/Medium) is used for all UI text, labels, and paragraph content.
- **Status Labels**: Use monospaced fonts at very small sizes (10px-11px) with tracking to simulate system outputs.

## Spacing
The system relies on an 8px grid. Section headers use a standard 40px bottom margin. Grid gap defaults are typically 24px (gap-6) for feature grids and 32px-40px for large layout sections.

## Layout
- **Container**: Max width of 1280px (7xl) with 24px horizontal padding on mobile.
- **Z-Index Layers**: Background (Stars/Glows) -> Midground (Section Grids) -> Foreground (Sticky Nav/Overlays).
- **Layer Stacks**: Features are organized in a 12-column responsive grid that collapses to a single column on mobile.

## Elevation & Depth
Depth is achieved through `backdrop-blur` and `ring` borders (1px) rather than traditional drop shadows. Panels often use a subtle `bg-white/5` to create a semi-translucent glass effect against the dark background.

## Shapes
Rounded corners are aggressive. Standard buttons and secondary tags use `rounded-full`. Content cards use `rounded-[32px]` or `rounded-[2rem]`. The Workspace UI uses `rounded-2xl` to distinguish functional app areas from marketing sections.

## Components
- **Electric Card**: A specific card type with a top-weighted blue gradient border and an inner glow effect.
- **Status Badge**: A pill-shaped component containing a 8px pulsing dot (`animate-ping`) and uppercase mono text.
- **Animated Connections**: SVG paths used to connect visual nodes, utilizing `stroke-dasharray` animations to simulate data flow.
- **Workspace Panel**: A fixed-height container mimicking a desktop application, with a 3-column layout (Navigation, Task List, Activity Feed).

## Motion
- **Entry**: Content uses a custom `fadeInUpBlur` keyframe that resolves from a blur(10px) to clear as it slides up.
- **Scroll Activation**: JavaScript-driven `animate-on-scroll` class that toggles `animation-play-state: running` when elements enter the viewport.
- **Glow Loops**: Subtle pulse animations on indigo circles to maintain a "living" feel.

## Do's and Don'ts
- **Do**: Use thin 1px borders with low opacity (10%) for section containers.
- **Do**: Maintain high contrast between headlines (White) and subtext (Neutral-400).
- **Don't**: Use solid bright backgrounds; all depth should be dark or semi-transparent.
- **Don't**: Mix different corner radii in the same component group.

## Accessibility
- Focus states must be clearly defined using `ring-blue-500` or `outline-offset`.
- Large text uses a minimum contrast ratio of 4.5:1 against the dark background.
- Interactive SVG icons include `aria-hidden` when purely decorative, while primary buttons maintain legible text labels.