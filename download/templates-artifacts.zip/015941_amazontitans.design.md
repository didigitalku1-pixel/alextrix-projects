---
version: 1.0.0
name: AmazonTitans
description: A conversion-focused agency template for high-ticket Amazon services with a focus on data and professional scaling.
colors:
  background: "#000000"
  surface: "#0c0a09"
  primary: "#f5f5f4"
  secondary: "#a8a29e"
  accent: "#fb923c"
  border: "#1c1917"
  text-primary: "#f5f5f4"
  text-secondary: "#78716c"
  brand-pink: "#f472b6"
typography:
  fontFamily:
    sans: "'Inter', sans-serif"
    serif: "'Playfair Display', serif"
  fontSize:
    hero: { size: "3.75rem", weight: "500", letterSpacing: "-0.025em" }
    heading: { size: "1.875rem", weight: "500", letterSpacing: "-0.025em" }
    body: { size: "1rem", weight: "400", lineHeight: "1.625" }
    nav: { size: "0.875rem", weight: "500" }
    label: { size: "0.75rem", weight: "600", letterSpacing: "0.1em" }
spacing:
  xs: "4px"
  sm: "16px"
  md: "24px"
  lg: "32px"
  xl: "80px"
rounded:
  sm: "4px"
  md: "6px"
  lg: "8px"
  xl: "12px"
  full: "9999px"
components:
  nav:
    background: "rgba(0, 0, 0, 0.9)"
    blur: "12px"
    border: "#1c1917"
    height: "64px"
  button-primary:
    background: "#f5f5f4"
    text: "#000000"
    hover: "#e7e5e4"
  card-surface:
    background: "#000000"
    border: "#1c1917"
    hover: "#292524"
  input:
    background: "#000000"
    border: "#1c1917"
    ring: "#1c1917"
  stat-card:
    border-left: "1px solid #d6d3d1"
    value-size: "1.875rem"
motion:
  transition: "0.2s ease-in-out"
  fadeIn: "0.4s ease-out forwards"
---
## Overview
Amazon Titans is built on a high-contrast 'Titan' aesthetic—dark, monolithic surfaces paired with crisp white typography. The system emphasizes authority and technical precision through data visualizations and minimal ornamentation.

## Colors
The palette is dominated by Stone (Neutral) scales on a Pure Black base. We use #f5f5f4 (Stone 100) for primary interactions and #78716c (Stone 500) for body text to maintain high legibility without harsh glare. Accents are rare, reserved for specific data growth indicators (#fb923c).

## Typography
Inter is the workhorse for UI and data, providing a clean, modern feel. Playfair Display is used sparingly for legacy/luxury cues (e.g., specific high-end client logos) to provide a contrast of tradition vs. modern technology.

## Spacing
We follow a standard 4-8px grid. Large vertical padding (80px to 128px) is used to separate high-level sections, creating a 'breathable' premium feel despite the dark background.

## Layout
The layout uses a standard 12-column max-width container (1280px). Major sections alternate between Pure Black and Stone-950 surfaces to create subtle visual rhythm. Use absolute positioning for background grain and gradient masks to ensure depth without cluttering the content layer.

## Elevation & Depth
Depth is achieved through `backdrop-blur` on the navigation bar and subtle border differences rather than shadows. Most components use a 1px solid border (#1c1917) to define their footprint in the dark space.

## Shapes
Component corners use a medium-soft rounding (8px to 12px) for cards, while primary call-to-action buttons use 8px. This creates a professional but approachable geometric language.

## Components
- **Nav**: Sticky at top, 10% opacity border, blur effect.
- **Growth Cards**: Feature a mini-bar chart visualization at the bottom to reinforce the 'Data' claim.
- **Performance Ledger**: A minimal table with mono-spaced numbers to suggest financial accuracy.
- **Trust Strip**: A grayscale logo gallery with 50% opacity and 100% saturation on hover.

## Motion
Sections utilize a vertical translate-and-fade animation (`translateY(10px)` to `0`) to guide the user's eye downward as they scroll. Hover states on cards involve a border-color transition to #44403c.

## Do's and Don'ts
### Do
- Use mono-spaced fonts for currency and growth percentages.
- Keep borders thin (1px) and dark.
- Align text-heavy sections to the center for hero areas but left for service details.

### Don't
- Use bright primary colors (Blue/Green) for CTA buttons.
- Add heavy box-shadows; let borders define the edges.
- Overuse the serif font; it should only appear in brand identifiers.

## Accessibility
- Maintain a minimum color contrast of 4.5:1 for all body text.
- Focus rings must be Stone-800 or brighter.
- Ensure all Iconify elements have appropriate aria-hidden attributes or descriptive labels.