---
version: 1.0.0
name: Creative Portfolio Showcase
description: A dark, premium aesthetic focusing on contrast, high-end typography, and layered interactive components.
colors:
  background: "#000000"
  surface: "rgba(23, 23, 23, 0.6)"
  primary: "#3b82f6"
  secondary: "#f97316"
  accent: "#a855f7"
  foreground: "#f5f5f5"
  muted: "#a3a3a3"
  border: "rgba(255, 255, 255, 0.1)"
typography:
  fontFamily: "Inter, sans-serif"
  heading:
    fontSize: "4.5rem"
    fontWeight: "700"
    letterSpacing: "-0.05em"
    lineHeight: "1.06"
  subheading:
    fontSize: "1.5rem"
    fontWeight: "600"
    letterSpacing: "-0.02em"
  body:
    fontSize: "1rem"
    fontWeight: "400"
    lineHeight: "1.6"
  label:
    fontSize: "0.75rem"
    fontWeight: "500"
    letterSpacing: "0.05em"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "32px"
  section: "96px"
rounded:
  none: "0px"
  sm: "4px"
  md: "8px"
  lg: "12px"
  xl: "16px"
  full: "9999px"
components:
  nav:
    position: "fixed"
    height: "64px"
    blur: "12px"
    zIndex: "50"
  card:
    background: "rgba(23, 23, 23, 0.5)"
    border: "1px solid rgba(255, 255, 255, 0.1)"
    borderRadius: "16px"
    shadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1)"
  button:
    primary:
      background: "linear-gradient(140deg, #0f0f11 0%, #1e1e21 100%)"
      borderRadius: "9999px"
      padding: "12px 24px"
    ghost:
      background: "transparent"
      border: "1px solid rgba(255, 255, 255, 0.1)"
motion:
  curve: "cubic-bezier(0.4, 0, 0.2, 1)"
  duration: "1s"
  stagger: "0.1s"
---
## Overview
The Creative Portfolio Showcase system is built for high-impact visual storytelling. It utilizes a deep black background with radial accent glows to create an immersive environment for artwork and professional services.

## Colors
The palette is strictly dark-mode, relying on `neutral-900` for surfaces and `neutral-100` for readability. Gradients are used sparingly on headings (White to Neutral-400) and borders to indicate premium quality.

## Typography
Built on the Inter typeface. Headings use tight tracking and high-contrast weights. Body text uses neutral-300 for reduced eye strain against the black background.

## Spacing
Follows an 8px modular scale. Section padding is generous (96px+) to give content room to breathe. Mobile margins are fixed at 24px.

## Layout
Utilizes a multi-layered z-index strategy:
- **Background (-10):** Animated aura gradients and Unicorn Studio effects.
- **Midground (0-5):** Main content and the "Gradient Blur" top-fade overlay.
- **Foreground (50+):** Sticky navigation and interactive tooltips/tags.

## Elevation & Depth
Depth is achieved through `backdrop-filter: blur()` and the `.border-gradient` technique, which uses a mask-composite to create a 1px thin luminous edge on cards and buttons.

## Shapes
Cards and UI containers use large radii (16px to 24px). Interactive elements like pills, tags, and primary buttons use the `rounded-full` token for a soft, approachable feel.

## Components
- **Navigation:** Fixed header with glassmorphism and user/menu circular icon buttons.
- **Hero Rail:** A grid of 3:4 aspect ratio cards with individual rotations (-8deg to +6deg) and hover scaling.
- **Pricing Cards:** Three-tier stack with the central 'Pro' card scaled 1.05x and highlighted with a violet glow.
- **Testimonial Grid:** 2-column layout with radial background gradients behind each block.

## Motion
- **Entrance:** `fadeSlideIn` keyframe moving 30px vertically with an initial blur.
- **Interactive Cards:** JavaScript-controlled focus state that blurs non-active cards (8px blur) and scales the target (1.15x).
- **Marquee:** Constant linear translation for community member galleries.

## Do's and Don'ts
- **Do:** Use gradient borders on all interactive surfaces.
- **Do:** Apply the `animate-on-scroll` class for all entrance transitions.
- **Don't:** Use solid white (#FFF) for large blocks of text; use neutral-300.
- **Don't:** Use square corners; all surfaces must have at least 8px radius.

## Accessibility
- Use `antialiased` font smoothing for white-on-black text.
- Ensure `aria-label` is present on icon-only buttons (Menu, User).
- Maintain a 10% root margin for scroll-triggered animations to ensure they trigger before the element hits the viewport edge.