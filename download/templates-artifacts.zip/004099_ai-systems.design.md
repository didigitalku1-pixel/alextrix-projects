---
version: 1.0.0
name: AI Systems Visual Language
description: A futuristic dark-mode theme featuring translucent layers, gradient accents, and sharp geometric structures.
colors:
  background: "#020617"
  foreground: "#f8fafc"
  primary: "#fdba74"
  secondary: "#60a5fa"
  border: "rgba(255, 255, 255, 0.1)"
  muted: "#94a3b8"
  accent-orange: "#fb923c"
  accent-blue: "#60a5fa"
typography:
  fontFamily: "Geist, Inter, ui-sans-serif, system-ui"
  heading1:
    fontSize: "60px"
    fontWeight: "400"
    letterSpacing: "-0.05em"
  heading2:
    fontSize: "48px"
    fontWeight: "400"
    letterSpacing: "-0.02em"
  body:
    fontSize: "16px"
    fontWeight: "400"
    lineHeight: "1.625"
  label:
    fontSize: "11px"
    fontWeight: "500"
    letterSpacing: "0.05em"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "48px"
  section: "80px"
rounded:
  sm: "4px"
  md: "8px"
  lg: "12px"
  xl: "24px"
  full: "999px"
components:
  nav:
    background: "rgba(255, 255, 255, 0.05)"
    blur: "8px"
    border: "1px solid rgba(255, 255, 255, 0.1)"
    rounded: "999px"
  button-primary:
    background: "#ffffff"
    color: "#0a0a0a"
    rounded: "999px"
  button-secondary:
    background: "rgba(255, 255, 255, 0.1)"
    border: "1px solid rgba(255, 255, 255, 0.15)"
    rounded: "999px"
  card:
    background: "rgba(15, 23, 42, 0.5)"
    blur: "12px"
    border: "1px solid rgba(255, 255, 255, 0.1)"
    rounded: "24px"
motion:
  curve: "ease-out"
  duration: "1s"
  intro: "fadeSlideIn"
---
## Overview
This visual system is engineered for AI-first applications. It emphasizes high-contrast dark backgrounds with ethereal light effects, simulating a premium, technical environment.

## Colors
The palette is rooted in `Slate-950` with accent colors used primarily for data visualization and interactive triggers.
- **Base**: Slate 950 for background, Slate 100 for text.
- **Accents**: Orange-300 for highlights and metrics; Blue-400 for secondary brand elements.
- **Surface**: Translucent whites (5% to 10% opacity) create depth on dark backgrounds.

## Typography
Primarily uses the **Geist** font family for its technical, mono-influenced clarity. Headings utilize tight tracking (-0.02em to -0.05em) to maintain a modern, engineered aesthetic.

## Spacing
Follows a strict rhythmic scale. Sections are padded with 80px-120px to allow heavy visual elements like parallax images and particles to breathe.

## Layout
- **Grid**: Uses a 12-column layout with wide gutters (24px-40px).
- **Layering**: Three distinct depths: Background (Particle/Grid), Midground (Glass Cards), and Foreground (Text/Buttons).
- **Dividers**: Subtle 1px gradients (`via-white/10`) replace solid lines to maintain the atmospheric feel.

## Elevation & Depth
- **Glassmorphism**: Achieved via `backdrop-blur` (8px to 16px) combined with thin semi-transparent borders.
- **Vignettes**: Radial and linear masks darken edges to focus the eye on central content.
- **Shadows**: Minimal use; depth is created through color contrast and blur rather than offset shadows.

## Shapes
- **Roundedness**: Dominant use of 24px (cards) and 999px (pills/buttons) radius.
- **Geometry**: Sharp 1px vertical and horizontal grid lines provide a technical structure behind organic rounded components.

## Components
- **Navigation**: Floating pill-shaped bar with high blur.
- **Feature Cards**: Large-radius containers containing nested data visualizations or high-resolution imagery.
- **Pricing Grid**: Three-tier system where the 'Popular' plan uses a distinct border-glow (Blue-400).
- **Metric Tickers**: Horizontally scrolling marquee for social proof/trust logos.

## Motion
- **Sequenced Entrance**: Elements slide upward 30px with an 8px blur filter on load.
- **Parallax**: Background imagery moves at 12% speed relative to scroll to create spatial immersion.
- **Magnetic Interaction**: Small UI elements (icons/labels) respond to mouse proximity with subtle XY translation.

## Do's and Don'ts
- **Do**: Use gradients for text clipping to signify "AI Intelligence."
- **Do**: Ensure all cards have a subtle `ring-1` border for edge definition.
- **Don't**: Use solid, opaque backgrounds for floating modals.
- **Don't**: Use sharp corners for interactive buttons.

## Accessibility
- Maintain a minimum contrast ratio of 4.5:1 for body text against dark backgrounds.
- Ensure all glass cards include a background color fallback for browsers that do not support backdrop filters.
- Interactive pill elements must have a clear `:hover` state change, typically increasing background opacity from 5% to 15%.