---
version: 1.0.0
name: Aura Financial System
description: A technical, cinematic banking interface utilizing radial glows, motion beams, and high-contrast typography.
colors:
  background: "#030303"
  brand-sky: "#38BDF8"
  brand-panel: "#0F110E"
  brand-dark: "#050505"
  text-primary: "#ffffff"
  text-secondary: "rgba(255, 255, 255, 0.7)"
  text-muted: "rgba(255, 255, 255, 0.4)"
  border-subtle: "rgba(255, 255, 255, 0.1)"
typography:
  sans:
    family: "Inter, sans-serif"
    weights: [300, 400, 500]
  serif:
    family: "Newsreader, serif"
    weights: [300, 400]
  mono:
    family: "ui-monospace, SFMono-Regular, monospace"
    weights: [400]
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "48px"
  container: "1280px"
rounded:
  sm: "4px"
  md: "8px"
  lg: "16px"
  xl: "24px"
  full: "9999px"
components:
  nav: "Floating pill-shaped blurred container with ring borders"
  primaryButton: "High-gloss 'Shiny CTA' with animated conic gradients and breathing shadow"
  secondaryButton: "Glassmorphism pill with shared gradient border mask"
  cards: "Spotlight-aware interactive panels with 3D perspective transforms"
  visualizer: "SVG-based sonar waves with rotating technical rings and data beams"
motion:
  beam: "3s linear infinite stroke-dashoffset animation"
  spin-slow: "12s-40s linear rotations for background depth"
  shimmer: "4s linear rotation for surface highlights"
---
## Overview
Aura is a visual language designed for 'programmable economics.' It mimics high-end trading terminals and futuristic operating systems, using deep blacks and electric sky blues to convey security and high-speed execution.

## Colors
The palette is dominated by **Rich Black (#030303)** and **Sky Blue (#38BDF8)**. Accent colors are used primarily for system status indicators (Emerald for online) and depth gradients. Glows should always use 25-40% opacity sky-blue radials.

## Typography
- **Serif (Newsreader):** Used for emotional, high-level narrative headlines. Often italicized to imply momentum.
- **Sans (Inter):** Used for UI controls, body copy, and secondary headlines.
- **Mono:** Used for technical metadata, labels, and system status indicators.

## Spacing
Follows an 8px grid system. Large sections are separated by 32px to 48px padding. Navigation and action buttons use 1.25rem to 2.5rem horizontal padding to maintain a wide, premium feel.

## Layout
- **Layering:** Uses a distinct three-tier depth system: Background (grid patterns), Midground (abstract SVG beams), and Foreground (frosted glass panels).
- **Constraints:** Max container width of 1280px with fluid responsive scaling for mobile.
- **Positioning:** Fixed navigation at top-center; absolute positioning for decorative data labels.

## Elevation & Depth
Depth is achieved through `backdrop-blur-xl` and `z-index` stacking rather than traditional box-shadows. Shadows are deep and diffused, often utilizing a slight sky-blue tint (`0 0 25px rgba(56, 189, 248, 0.4)`).

## Shapes
Primary containers use large radii (24px to 32px). Actionable elements (buttons, nav, chips) are almost exclusively fully rounded (pill-shaped) to provide a soft contrast against the rigid technical grid background.

## Components
- **Floating Nav:** Fixed position with `1px` white/10 ring and `backdrop-blur`.
- **Spotlight Cards:** Feature containers that track mouse movement to update CSS variables `--mouse-x` and `--mouse-y` for dynamic lighting.
- **Status Indicators:** Use a double-span approach—one static dot and one `animate-ping` dot for live activity.
- **Chat Terminal:** Dark background (#0A0A0A) with mono-spaced text and animated progress bars.

## Motion
- **Beams:** Use `stroke-dasharray` on SVG paths to simulate data flowing through the interface.
- **Conic Borders:** CTA buttons use `@property` animations to rotate a gradient border indefinitely.
- **Sonar:** Central core elements use a 3s cubic-bezier pulse on the radius property.

## Do's and Don'ts
- **Do:** Use grayscale filters on partner logos to maintain visual harmony.
- **Do:** Mix serif and sans-serif within a single headline to emphasize specific keywords.
- **Don't:** Use solid bright backgrounds; all surfaces should be dark and semi-transparent.
- **Don't:** Use sharp corners on interactive elements.

## Accessibility
- Maintain a minimum contrast ratio of 4.5:1 by using white text at 70%+ opacity on black surfaces.
- Use `selection:bg-brand-sky` to ensure user highlight visibility.
- Ensure all icons have `aria-hidden="true"` and buttons have descriptive text for screen readers.