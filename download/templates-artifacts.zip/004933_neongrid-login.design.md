---
version: 1.0.0
name: NeonGrid
description: A futuristic, security-focused visual system utilizing deep neutrals and emerald neon highlights.
colors:
  background: "#0a0a0a"
  surface-base: "#171717"
  surface-gradient-start: "#171717"
  surface-gradient-end: "#262626"
  primary-neon: "#34d399"
  primary-glow: "rgba(52, 211, 153, 0.55)"
  border-neutral: "#262626"
  text-primary: "#fafafa"
  text-secondary: "#a3a3a3"
  text-muted: "#737373"
  text-disabled: "#525252"
typography:
  headings:
    family: "Inter, system-ui, sans-serif"
    weight: "600"
    size: "22px"
    letter-spacing: "-0.025em"
  body:
    family: "Inter, system-ui, sans-serif"
    weight: "400"
    size: "14px"
  label:
    family: "Inter, system-ui, sans-serif"
    weight: "500"
    size: "12px"
    letter-spacing: "0.16em"
    case: "uppercase"
  caption:
    family: "Inter, system-ui, sans-serif"
    weight: "400"
    size: "11px"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "32px"
  container-padding: "40px"
rounded:
  sm: "4px"
  md: "8px"
  lg: "12px"
  xl: "16px"
  full: "9999px"
  card: "24px"
components:
  card:
    bg: "linear-gradient(to bottom, #171717, #171717, #262626)"
    border: "1px solid #262626"
    shadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1)"
  input:
    bg: "rgba(10, 10, 10, 0.6)"
    border: "1px solid #262626"
    focus-ring: "#10b981"
    shadow: "inset 0 2px 4px 0 rgba(0, 0, 0, 0.4)"
  primary-button:
    bg: "#10b981"
    text: "#0a0a0a"
    glow: "0 14px 35px rgba(16, 185, 129, 0.55)"
  social-button:
    bg: "#171717"
    border: "1px solid #262626"
    hover-bg: "rgba(38, 38, 38, 0.8)"
motion:
  standard: "transition all 200ms ease"
  pulse: "animation pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite"
---
## Overview
NeonGrid is a high-contrast dark mode system designed for authentication and technical dashboards. It leverages depth through gradients, inner shadows, and emerald neon accents to create a secure, cutting-edge aesthetic.

## Colors
The palette is rooted in the Neutral-950 spectrum, using depth-layering rather than color variety. Emerald-400 is the exclusive accent color, reserved for primary actions, branding, and status indicators. Border colors should remain subtle (Neutral-800) to maintain the dark-space feel.

## Typography
Typography prioritizes legibility in low-light environments. Headings use tight tracking and semi-bold weights. Secondary labels utilize wide letter-spacing (0.16em) and uppercase transformation to distinguish metadata from user content.

## Spacing
A strict grid system based on 4px increments. Layouts rely on significant negative space (40px internal padding) to separate the central interactive card from decorative background elements.

## Layout
The system uses a layered Z-axis approach:
- Background: Fixed saturation-zero imagery with a linear-gradient alpha mask.
- Midground: Decorative circuit nodes and connecting lines (absolute positioning, hidden on mobile).
- Foreground: The primary interactive card centered via Flexbox or Grid.

## Elevation & Depth
Depth is achieved through three primary techniques:
- Gradients: Surface backgrounds transition from lighter top-tones to darker bottoms.
- Inner Shadows: Inputs use `shadow-inner` with `black/40` to appear recessed into the card.
- Glows: High-importance elements (Logo, Primary Button) use colored box-shadows to simulate light emission.

## Shapes
Shapes are predominantly rounded-xl (12px) for inputs and nodes, while the main container utilizes a larger 24px (rounded-3xl) radius. Buttons are fully pill-shaped (rounded-full) to provide a distinct interactive silhouette.

## Components
- **Circuit Nodes**: Decorative blocks containing horizontal line bars and a single pulsing emerald dot.
- **Auth Inputs**: Recessed fields with left-aligned icons (16px) and right-aligned action buttons (e.g., 'Show').
- **Primary Button**: High-saturation emerald pill with a significant vertical glow offset.
- **Social Grid**: Three-column layout for provider icons using standard 12px rounded borders.

## Motion
- **Pulsing Status**: Decorative emerald dots use a 2s pulse animation.
- **Hover States**: Subtle color transitions (200ms) for social buttons and text links.
- **Focus States**: 1px ring expansion in emerald for all interactive inputs.

## Do's and Don'ts
- **Do** use uppercase with tracking for formal labels.
- **Do** use inner shadows for input fields.
- **Don't** use bright colors other than emerald.
- **Don't** use sharp corners; maintain the high-radius organic tech feel.

## Accessibility
- Maintain a minimum contrast ratio of 4.5:1 for text (Neutral-400 on Neutral-900 meets this requirement).
- Focus indicators must be visible (Emerald-500 ring) for keyboard navigation.
- Screen reader only text (`sr-only`) is required for icon-only social buttons.