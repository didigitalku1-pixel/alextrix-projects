---
version: "1.0.0"
name: "Aura Luxury Furniture System"
description: "A minimalist, high-contrast system blending architectural precision with organic comfort."
colors:
  background: "#F2EFEA"
  foreground: "#2C2824"
  surface: "#FFFFFF"
  surfaceDark: "#26221E"
  accent: "#C48C56"
  muted: "#0000004D"
  border: "#0000001A"
  beam: "rgba(255, 255, 255, 0.6)"
typography:
  display:
    family: "Plus Jakarta Sans"
    weight: "300"
    tracking: "-0.05em"
  heading:
    family: "Plus Jakarta Sans"
    weight: "300"
    tracking: "-0.02em"
  body:
    family: "Geist"
    weight: "400"
    lineHeight: "1.6"
  accent:
    family: "Inter"
    weight: "500"
    tracking: "0.05em"
  serif:
    family: "Playfair Display"
    weight: "400"
spacing:
  xs: "4px"
  sm: "12px"
  md: "24px"
  lg: "48px"
  xl: "64px"
  container: "88rem"
rounded:
  none: "0px"
  sm: "4px"
  md: "12px"
  lg: "16px"
  full: "999px"
components:
  nav:
    position: "absolute"
    padding: "32px 0"
    z-index: "40"
  hero:
    alignment: "center"
    minHeight: "100vh"
    textReveal: "clip-container"
  button:
    padding: "12px 24px"
    rounded: "999px"
    animation: "btn-beam"
  card:
    background: "rgba(255, 255, 255, 0.4)"
    blur: "12px"
    interaction: "flashlight"
  marquee:
    speed: "25s"
    opacity: "0.2"
motion:
  stagger: "0.15s"
  duration: "0.8s"
  easing: "cubic-bezier(0.16, 1, 0.3, 1)"
---
## Overview
Aura is a visual framework designed for luxury products that emphasize engineering and human mechanics. It utilizes a neutral, warm palette, vast negative space, and technical typography to convey both warmth and precision.

## Colors
The palette is anchored by the 'Oatmeal' background (`#F2EFEA`) and 'Charcoal' text (`#2C2824`).
- **Primary Background**: `#F2EFEA` (Light), `#26221E` (Dark Section)
- **Primary Text**: `#2C2824` (Light), `#F2EFEA` (Dark)
- **Interactive Accent**: `#C48C56` used for icons and status indicators.
- **Overlays**: Black at 10-20% opacity for image darkening and whitespace depth.

## Typography
- **Display (H1)**: Plus Jakarta Sans Light. Large scale (up to 10rem) with tight tracking and staggered character entrance animations.
- **Body**: Geist Sans. High legibility with 0.8 to 0.9 opacity for secondary information.
- **Technical Labels**: Monospace-adjacent Geist at 12px, all-caps, with 0.5 opacity for metadata and specifications.

## Spacing
The system relies on an 88rem (1408px) max-width container. Interior spacing uses large vertical padding (32px to 128px) to create a 'cinematic gallery' feel. Grid gaps are consistently 32px (md) or 64px (lg).

## Layout
- **Layer Stacks**: Utilizes a 4-column guide overlay (z-50) at 4% opacity to reinforce grid alignment.
- **Verticality**: Long-form scrolling with sections transitioning between high-key light modes and low-key dark modes.
- **Foreground Elements**: Absolute positioned icons (Sonar Rings) and interactive cards float over background images.

## Elevation & Depth
- **Backdrop Blur**: 12px blur on cards and navigation to create material hierarchy.
- **Z-Index Layering**: Navigation (40), Global Grid (50), Content (10).
- **WebGL Reveals**: Images are hidden behind staggered column masks that reveal on scroll.

## Shapes
- **Main Cards**: 16px (lg) border radius with extremely thin (1px) borders.
- **Interactive Elements**: Buttons and pills use a 999px (full) radius.
- **Decorative**: Sonar rings (circular) and Asterisk icons (rotational).

## Components
- **Nav**: Transparent backdrop with 70% opacity links; hover state is 100%.
- **Flashlight Card**: Glassmorphic container that tracks mouse position to create a radial gradient highlight.
- **Beam Button**: A high-contrast pill button with a linear gradient 'beam' animation that rotates around the border on hover.
- **Marquee**: Infinite horizontal text scroll with edge-to-edge transparency masking.

## Motion
- **Staggered Text**: Letters slide down from -120% Y-axis with a 0.15s stagger.
- **Sonar**: 2s scale-up animation with opacity fade-out to indicate interactive points.
- **Parallax**: Subtle object-scale (1.05 to 1.0) on container hover for gallery images.

## Do's and Don'ts
- **Do**: Use lowercase for body copy and uppercase for technical labels.
- **Do**: Maintain the mix-blend-multiply setting for product cutouts on warm backgrounds.
- **Don't**: Use vibrant colors outside of the `#C48C56` accent range.
- **Don't**: Use heavy drop shadows; prefer glassmorphism and subtle borders.

## Accessibility
- **Selection**: custom selection colors (`bg-[#2C2824] text-[#F2EFEA]`) to maintain brand contrast.
- **Contrast**: Text on dark sections must maintain `#F2EFEA` for WCAG compliance.
- **Interaction**: Pointer-events-none applied to all overlay guides to prevent interaction blocking.