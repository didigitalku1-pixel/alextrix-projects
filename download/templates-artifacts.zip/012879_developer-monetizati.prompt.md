Recreate the website "Ledger - Monetization Infrastructure" with high visual fidelity as a Tailwind CSS and Vanilla JavaScript site. The result must be a dark-themed, developer-focused landing page with intricate dashboard UI components and interactive financial visualizations.

Preserve source quirks:
- Mixed usage of Inter and Geist font families throughout the page.
- Dashboard metric counter resets to $0.0M and restarts after each loop.
- Precise 3D rotation transforms on the testimonials container using custom CSS utilities.
- Specific text-shadows and glows (e.g., emerald glows on the terminal cursor).

CRITICAL FIDELITY CONSTRAINTS
- Background textures: The hero must use the UnicornStudio integration script for the background shader effect.
- Selection color: Must be `selection:bg-emerald-500 selection:text-white` globally.
- Border Gradients: Use the specific `--border-gradient` variable and `::before` pseudo-element logic found in the Pricing and Feature sections.
- Spacing: Hero padding is `pt-32 pb-32`; Dashboard section has a `mb-24` and `-translate-y-6` offset.

TECH STACK / DEPENDENCIES
- CSS: Tailwind CSS (CDN), Custom 3D rotate-x/y utilities.
- Scripts: Iconify (iconify-icon), Unicorn Studio (v2.0.0), Vanilla JS for animations.
- Fonts: Inter, Geist, Geist Mono, Roboto, and Plus Jakarta Sans via Google Fonts.

ASSET MAP
- Logo: `https://cdn.midjourney.com/372600d1-0464-41c8-8632-fecb7f20ff47/0_3.png?w=800&q=80` (with `invert` class applied).
- Avatars:
  - Alicia Morin: `https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/6e807631-f507-40d1-92e2-17f496e11b6b_320w.webp`
  - Pricing faces: Unsplash IDs `534528741775-53994a69daeb`, `506794778202-cad84cf45f1d`, `1494790108377-be9c29b29330`.
- Marquee Logos (Supabase storage URLs):
  - `b9181a49-20ab-4552-b731-976469c0154b`
  - `ca43984b-3298-41bb-871b-d113545c657c`
  - `07ee863a-59fe-4785-a806-5592f2439df2`
  - `be92aecb-6303-4bbe-9283-ba238ac8b0ee`
  - `9f9002c0-4b36-4d16-b000-15655b25b879`
  - `1040d3ec-8da2-47f6-b134-1341261ccfb9`

VECTOR / ICON SHAPES
- Use `iconify-icon` for `solar:alt-arrow-down-linear`, `solar:book-bookmark-linear`, `lucide:shield-check`, `lucide:zap`, and `lucide:trending-up`.
- Custom SVG Paths: The Dashboard Revenue graph uses specific `C` (cubic bezier) path strings for the green area fill and yellow dashed lines.

MEDIA BEHAVIOR
- Background Shader: Use `<div data-us-project="vLGJIxHINq2tCeLOR9Dt">` to initialize the Unicorn Studio project.
- Infinite Marquee: `animate-[marquee-rtl_40s_linear_infinite]` with a duplicate set for seamless looping.

LAYER STACK / POSITIONING MAP
- Global: Fixed Nav (`z-50`) > Page Content (`z-30`) > Background Shaders (`-z-10`).
- Section 1 (Hero): Container `max-w-[1400px]`, Grid `lg:grid-cols-2`. Shiny CTA button uses a specific `@property --gradient-angle` animation.
- Section 2 (Dashboard): Floating Sidebar (Left) with `bg-[#0c0d10]`, Sticky Header with `backdrop-blur-md`, and Scrollable Content Area (`custom-scrollbar`).
- Section 3 (Features): Grid `lg:grid-cols-3`. Feature 1 spans 2 cols. Feature 2 (Webhooks) includes a `font-mono` terminal emulator.
- Section 4 (Testimonials): Stacked cards using `md:absolute` and `md:top-1/2 md:left-1/2`. Z-index order: Center (30), Sides (10).

SECTION DETAILS
- DASHBOARD REVENUE GRAPH: SVG paths must match exactly. Path 1 (Area): `M0,130 C40,140 80,110...`. Path 2 (Line): `M0,130 C40,140...` stroke `#34d399`.
- TERMINAL EMULATOR: Use a JS loop to type through `initializing_ledger_api`, `connecting_webhooks`, and `latency: 12ms`. Include a blinking emerald cursor.
- PRICE TOGGLE: A button with `id="billingKnob"`. JS must toggle `translate-x-6` on the knob and swap `data-monthly="29"` to `data-annual="279"` on the price span.
- TESTIMONIAL SWIPER: JS `handleTestimonialSwipe` function must manage card class swaps including `md:-rotate-[6deg]` for the left card and `md:rotate-[6deg]` for the right card.

GLOBAL ANIMATION / INTERACTION RULES
- Entrance: All major sections use `[animation:animationIn_0.8s_ease-out_0.1s_both]` with `animate-on-scroll` class.
- Scroll Observer: Initialize `IntersectionObserver` to trigger the `animate` class when 20% of the element is visible.
- Interactive Graphs: Use `animate-bar-loop` (transform scaleY) on vertical bar charts with staggered `animation-delay` (0ms to 600ms).

COMMON MISTAKES TO AVOID
- Do not use standard Tailwind `animate-pulse` for the graph bars; they must use the custom `barCycle` keyframe with `transform-origin: bottom`.
- Do not forget the `mix-blend-screen` and `invert` on the Midjourney logo asset.
- Do not skip the `shiny-cta` CSS properties; the border-spin animation is critical for the primary CTA's visual weight.

IMPLEMENTATION REQUIREMENTS
- Build as a single-page landing page.
- Use the exact font weights (300, 400, 500, 600, 700).
- Ensure the `LEDGER` big footer text is `text-[13vw]` with `pointer-events-none`.
- Final result must be pixel-perfect relative to the provided asset URLs and CSS rules.