---
version: 1.0.0
name: Velos Architecture
description: A reductionist visual system focusing on raw materiality, void-space, and cinematic depth.
colors:
  background-dark: "#0a0a0a"
  background-light: "#fdfdfd"
  background-offset: "#f8f8f8"
  surface-card: "rgba(10, 10, 10, 0.6)"
  accent-white: "#ffffff"
  accent-emerald: "#10b981"
  text-primary: "#ffffff"
  text-muted: "rgba(255, 255, 255, 0.6)"
  text-inverse: "#171717"
  border-glass: "rgba(255, 255, 255, 0.1)"
typography:
  display:
    family: "Bricolage Grotesque"
    weight: "700"
    lineHeight: "0.85"
  heading:
    family: "Bricolage Grotesque"
    weight: "300"
    lineHeight: "0.95"
  serif-italic:
    family: "Playfair Display"
    weight: "400"
    style: "italic"
  body:
    family: "Inter"
    weight: "400"
    lineHeight: "1.625"
  mono:
    family: "Inter"
    weight: "500"
    letterSpacing: "0.3em"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "32px"
  section-v: "128px"
rounded:
  sm: "4px"
  md: "8px"
  lg: "16px"
  xl: "24px"
  full: "999px"
  card: "32px"
components:
  nav:
    style: "pill-shaped"
    blur: "24px"
    border: "1px solid rgba(255, 255, 255, 0.1)"
  buttons:
    primary: "rounded-full px-8 py-4 font-medium transition-all"
    icon: "w-10 h-10 rounded-full border border-white/20"
  cards:
    project: "h-[520px] rounded-[32px] overflow-hidden flex flex-col justify-between p-8 group"
    glass: "backdrop-blur-2xl bg-neutral-950/60 border border-white/10"
  stats:
    label: "text-[10px] uppercase tracking-widest"
    value: "text-2xl font-bricolage"
motion:
  cinematic: "scale(1.4) to scale(1) over 3.5s with blur reduction"
  slideUp: "translateY(40px) to 0 over 1s"
  shimmer: "translateX(-150%) to 200% linear infinite"
---
## Overview
Velos is a visual system designed for high-end spatial storytelling. It balances brutalist minimalism—characterized by large, tight-leaded typography and raw background colors—with cinematic glassmorphism. The system emphasizes the relationship between "Void" (negative space) and "Mass" (structural components).

## Colors
The palette is primarily monochromatic, using a deep `neutral-950` for dark modes and a clean `neutral-50` for light modes. Glassmorphism is used to bridge these states, with `white/10` borders providing structural definition on dark surfaces. A single `emerald-500` pulse is reserved for live status indicators.

## Typography
- **Bricolage Grotesque**: Used for high-impact display text and headings. Tight tracking and line-height are required for the brutalist aesthetic.
- **Playfair Display**: Used sparingly for italicized accents to convey luxury and heritage.
- **Inter**: The workhorse for body copy and technical specifications.

## Spacing
Following an 8px base grid. Section vertical spacing is aggressive (128px+) to allow the "Void" philosophy to take effect. Small spacing (4px, 8px) is used within cards for technical data points.

## Layout
- **Global Grid**: A fixed 4-column vertical line overlay (`grid-lines`) at 15% opacity provides a constant architectural framework.
- **Hero Stack**: Absolute background image with scale transform, midground text with slide-up animations, and foreground glass cards.
- **Product Grid**: Responsive 1-to-3 column grid using large-radius cards (32px).

## Elevation & Depth
- **Z-Indices**: Nav (50), Grid Lines (5), Content (10).
- **Glassmorphism**: High-blur (24px+) backdrops with subtle inner-ring highlights (`ring-1 ring-white/5`) to simulate thick glass panes.

## Shapes
- **Project Cards**: Large 32px corner radius creates a soft-brutalist feel.
- **Pill Navigation**: Full rounding for the primary navigation container.
- **Inputs**: Fully rounded with subtle border-glow on focus.

## Components
- **Navigation**: A floating pill-shaped bar with a blurred background and icon-only actions on the right.
- **Material List**: A row-based component for technical specs, featuring a custom CSS-driven frequency response bar chart.
- **Project Card**: Image-heavy containers with a bottom-aligned text gradient and an top-right arrow icon that appears on hover.
- **Filter Sidebar**: Sticky navigation component for jobs or archives using custom-styled checkboxes.

## Motion
- **Entrance**: Long, eased cinematic entrance for hero images (3.5s).
- **Scroll Triggers**: Elements should use an `animate-on-scroll` class that toggles `animation-play-state` based on intersection observers.
- **Shimmer**: A diagonal gradient light-sweep used on glass cards to denote high-value interactivity.

## Do's and Don'ts
- **Do**: Use extremely large font sizes for primary headlines, even if they overlap slightly with background imagery.
- **Do**: Maintain high contrast between text and background surfaces.
- **Don't**: Use standard rectangular corners; maintain the large-radius standard for containers.
- **Don't**: Use vibrant colors for anything other than specific status signals.

## Accessibility
- Use `selection:bg-white/20` to ensure text readability during selection on dark backgrounds.
- All functional icons (magnifier, menu) must be wrapped in descriptive aria-labels or accompanied by hidden text.
- Maintain a minimum contrast ratio of 4.5:1 for body text against dark backgrounds.