---
version: 1.0.0
name: Aura Mobile Prototyping System
description: A visual language for mobile apps focusing on depth, layering, and immersive educational content.
colors:
  background: "#3F3F46"
  surface: "#FFFFFF"
  surfaceDark: "#1A1A1A"
  primary: "#BFD6BA"
  accent: "#F97316"
  textMain: "#111827"
  textMuted: "#9CA3AF"
  success: "#4ADE80"
  destructive: "#EF4444"
typography:
  sans:
    family: "Inter, sans-serif"
    weights: [300, 400, 500, 600]
  mono:
    family: "Geist Mono, monospace"
    weights: [300, 400, 500, 600]
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "32px"
  xxl: "48px"
rounded:
  sm: "8px"
  md: "12px"
  lg: "16px"
  xl: "24px"
  full: "999px"
components:
  header: "Transparent or white sticky headers with duotone iconography."
  cards: "Layered surfaces with significant negative margins and complex box-shadows."
  buttons: "Pill-shaped (rounded-full) with subtle border gradients or high-contrast fills."
  timeline: "Vertical monochromatic lines with overlapping avatar clusters."
  profiles: "Centered dark-mode cards with high-density stat grids and bordered avatars."
motion:
  standard: "transition-all duration-200 ease-in-out"
  pulse: "animate-pulse for live status indicators"
  hover: "scale-105 for interactive upload zones and list items"
---
## Overview
Aura Mobile focuses on an 'App-within-an-App' aesthetic. It uses floating layered cards, absolute positioning for depth, and high-quality photography to create an immersive, tactile experience for mobile interaction designers.

## Colors
- **Zinc 700 (#3F3F46)**: Used for the outer context/wrapper.
- **Orange 50 (#FFF7ED)**: Primary light-themed accent surface.
- **Neutral 500 (#737373)**: Dark utility backgrounds.
- **Green 400/50 (#4ADE80)**: Success states and live indicators.
- **Gray 900/100**: Core text and secondary button backgrounds.

## Typography
- **Primary Interface**: Inter for standard readability and form labels.
- **Technical Details**: Geist Mono for dates, status codes (e.g., DSGN402), and tracking-wide metadata.
- **Headings**: Tight tracking (-tighter) on text-2xl and above to create a modern architectural feel.

## Spacing
- Standard padding is 24px-32px (6-8 in Tailwind scale).
- Negative margins (e.g., -ml-10) are used to break the layout grid and create the signature 'floating' card effect.

## Layout
- **Layer Stacks**: Background image > Black gradient overlay > Centered floating card > Bottom content.
- **Z-Index Strategy**: Heavy use of z-10 and z-20 to ensure floating profile cards overlap transitions between sections.
- **Scroll Behavior**: Custom scrollbars are hidden (`no-scrollbar`) to maintain a clean app-like viewport.

## Elevation & Depth
- **Extreme Shadows**: Multi-layered box shadows simulating 5-6 distinct light sources for high-elevation floating cards.
- **Backdrop Blur**: 4px-8px blurs on semi-transparent cards to separate content from busy photographic backgrounds.

## Shapes
- **Roundedness**: Primary mobile containers use 24px (3xl). Floating action buttons and profile buttons use 999px (full).
- **Borders**: 1px white/10% or glass-morphism border gradients on dark cards.

## Components
- **Floating Peach Card**: Offset from the main container to break the visual box.
- **Avatar Clusters**: Overlapping circular images with 2px white borders.
- **Status Pill**: Pulsing green dot next to live session counts.
- **Upload Zone**: Dashed border interaction areas with light background tints on hover.

## Motion
- **Subtle Interactions**: Hover scales on iconography and buttons.
- **Presence Indicators**: 2s pulse cycles for 'Live' designers count.
- **Transitions**: Smooth color shifts for list items using standard ease curves.

## Do's and Don'ts
- **Do**: Use high-contrast font weight pairs (e.g., 300 for body, 600 for labels).
- **Do**: Use absolute positioning for profile summaries to overlap different background colors.
- **Don't**: Use sharp 90-degree corners; the system requires a minimum 8px radius.
- **Don't**: Use solid black backgrounds; prefer Zinc-900 or high-opacity overlays.

## Accessibility
- Maintain 4.5:1 contrast on all labels using Geist Mono.
- Icons must have `aria-hidden="true"` as they are primarily decorative or accompanied by labels.
- Large tap targets (min 44x44px) for all pill-shaped navigation elements.