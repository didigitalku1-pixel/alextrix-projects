Recreate the website "Fluxora" with high visual fidelity using Tailwind CSS and the Inter font family. The site is a dark-themed AI infrastructure landing page featuring a complex bento grid, glassmorphism, and custom scroll animations.

Preserve source quirks:
- The Bento Grid has a hard-coded height of 800px with a specific mask-image gradient that fades the bottom.
- Some icons are Solar Bold Duotone while others are Linear.
- The Chart.js implementation uses a hard-coded min value of 60 for the Y-axis.

CRITICAL FIDELITY CONSTRAINTS
- Background strategy: Use a fixed black background base with an overlay pattern of 64x64 grids (opacity 0.03) and a dynamic aura background using the provided script.
- Custom Borders: Implement the `.border-gradient` class using a pseudo-element with `mask-composite: exclude` and a 1px linear gradient (225deg, transparent, white/20, transparent).
- No standard scroll: All major sections must use the `.animate-on-scroll` class with the `fadeSlideIn` keyframe animation controlled by the IntersectionObserver script.

TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN)
- Iconify (Solar/MD sets)
- Chart.js (v4+)
- UnicornStudio.js (v1.4.29) for the aura background effects
- Inter Font (Weights: 300, 400, 500, 600, 700)

GLOBAL STYLE
- Body: `bg-neutral-950 text-white antialiased` with `font-family: Inter`.
- Keyframes: `fadeSlideIn` { 0% { opacity: 0; transform: translateY(30px); filter: blur(8px); } 100% { opacity: 1; transform: translateY(0); filter: blur(0); } }

ASSET MAP
- Hero Team: `https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/357cb3d1-9f65-4810-884b-f0072a65193d_1600w.webp`
- Globe: `https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/d25a1767-0ea8-4aac-b981-6afd67dc79a6_800w.webp`
- About Platform: `https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/bd276cb3-a53d-4683-83d8-727dc1ffaf68_1600w.webp`
- Testimonial Avatars: Use CA2DF... (Sarah), 4C9AA... (Michael), 8A90D... (Emily), A90AA... (David), EAE5D... (Jessica), 7D4BF... (Alex), and Unsplash ID `1544717305-2782549b5136` (Rachel).

VECTOR / ICON SHAPES
- Brand Star: `solar:star-fall-minimalistic-2-bold-duotone` (ViewBox 24x24).
- Grid Background SVG: Rect with `fill: url(#grid)` using a path `M64 0H0v64` at 0.5 stroke width.

LAYER STACK / POSITIONING MAP
- Layer 0 (Fixed): Black base background.
- Layer 1 (Fixed): SVG Grid Pattern (64x64).
- Layer 2 (Absolute): Aura background with `brightness-50 saturate-50` and `mask-image` linear gradient (top to bottom: transparent to black to transparent at 80%).
- Layer 3 (Relative): Header and Main content with `z-10`.
- Overlays: `blur-3xl` radial gradients in blue-500/10 and blue-400/10 for section backgrounds.

SECTION 1 - HEADER
- Layout: Max-w-7xl, flex justify-between, items-center.
- Items: Logo (Brand Star + Fluxora), Nav (Platform, Stories, Pricing, Docs), Status Pill (Online dot), CTA (Contact button with arrow icon).

SECTION 2 - HERO & BENTO GRID
- Pill: "New Simple Pricing" with star icon.
- Heading: Text-4xl to 7xl tracking-tighter.
- Bento Structure: 12-column grid, 800px height, auto-rows-200px.
- Key Bento Cards:
  1. Team Card (6 cols): Image + avatar stack + "Product Team" badge.
  2. Stat Card (3 cols): "140+", blue text growth stat.
  3. Code Card (3 cols): IDE-style window with `config.tsx` code snippet.
  4. Chart Card (3 cols): Chart.js Bar chart + "97.8% SLA met".
  5. Orbit Card (3 cols): Animated concentric pulses around a central widget icon.

SECTION 3 - TESTIMONIAL SWITCHER
- Structure: Full-width container with internal grid overlay pattern.
- Interaction: 7 avatar thumbnails. Clicking an avatar updates the large quote text and author info with a 250ms fade transition.
- Styles: Active avatar gets `ring-2 ring-white/20 shadow-lg` while others remain grayscale and 40% opacity.

SECTION 4 - ABOUT PLATFORM
- Layout: 2-column grid. Left: Large platform screenshot in a `rounded-[28px]` frame with blue glow. Right: Copy + "Discover Our Story" button + 3 feature mini-cards.

SECTION 5 - HOW IT WORKS
- Layout: Horizontal line dividers. 3 vertical step cards.
- Step 1: Document icon UI mock.
- Step 2: 4-square grid of small UI widgets (Monitor, Layers, Book icons).
- Step 3: Refresh icon + dashboard-style service badges.

SECTION 6 - SERVICES & FOOTER
- Services: Large heading "Let's Build Something Extraordinary". Two service rows with price tags ($2,999 / $5,999). Right side features a 5-image project masonry layout.
- Footer: 4-column link structure. Bottom row contains social icons (Twitter, GitHub, LinkedIn) and copyright notice.

GLOBAL ANIMATION / INTERACTION RULES
- IntersectionObserver: Init with `threshold: 0.2` and `rootMargin: "0px 0px -10% 0px"` to trigger the `.animate` class.
- Chart.js: Bar chart with `borderRadius: 6`, no legend, custom gray/blue axis colors.
- Hover Effects: Buttons translate -0.5y. Glass cards use `backdrop-blur-xl` and `bg-white/5`.

IMPLEMENTATION REQUIREMENTS
- Use original asset URLs from the ASSET MAP.
- Maintain exact responsive breakpoints (sm:640px, md:768px, lg:1024px, xl:1280px).
- Ensure the aura-background script is included and the `data-us-project` ID `XxCmD31vVBmiINgvYCho` is set for Unicorn Studio initialization.