---
version: 2.0
name: Lumina Creative
description: A visual system defined by dark aesthetics, 3D transformations, and fluid motion, specifically crafted for AI-driven video production interfaces.
colors:
  background: "#050505"
  primary: "#ea580c"
  primaryLight: "#fb923c"
  accent: "#fbbf24"
  surface: "rgba(255, 255, 255, 0.05)"
  border: "rgba(255, 255, 255, 0.1)"
  textMain: "#ffffff"
  textMuted: "rgba(255, 255, 255, 0.6)"
  textDim: "rgba(255, 255, 255, 0.4)"
typography:
  display:
    family: "Inter, sans-serif"
    weight: "500"
    size: "72px-128px"
    lineHeight: "0.9"
    tracking: "-0.05em"
  serifDisplay:
    family: "Instrument Serif, serif"
    weight: "600"
    size: "20px"
  body:
    family: "Inter, sans-serif"
    weight: "400"
    size: "18px"
    lineHeight: "1.6"
  mono:
    family: "monospace"
    weight: "400"
    size: "12px"
    tracking: "0.1em"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "32px"
  xl: "64px"
  section: "128px"
rounded:
  sm: "4px"
  md: "8px"
  lg: "12px"
  xl: "16px"
  full: "9999px"
components:
  navbar:
    position: "sticky"
    top: "0"
    blur: "8px"
    z-index: "50"
  actionButton:
    background: "linear-gradient(0deg, #ea580c, #ea580c)"
    glow: "radial-gradient(65% 65% at 50% 100%, #fbbfa8, transparent)"
    border: "1px solid rgba(255,255,255,0.3)"
    rounded: "9999px"
  cardStack:
    position: "relative"
    transform: "perspective-1000"
    depthGap: "12px"
    scaleFactor: "0.95"
  featureStep:
    layout: "flex"
    activeState: "bg-white/5 border-white/10 shadow-xl"
    indicator: "rounded-full bg-orange-500"
  footerContact:
    size: "text-8xl"
    hover: "bg-clip-text text-transparent bg-gradient-to-r"
motion:
  curve: "cubic-bezier(0.2, 0.8, 0.2, 1)"
  duration: "1s"
  parallax: "object-cover mix-blend-luminosity"
---
## Overview
Lumina focuses on "Cinematic Sophistication." It uses a deep obsidian foundation paired with high-energy orange light sources to mimic a dark studio environment. Visuals are characterized by 3D depth, particle animations, and "falling beam" grid lines.

## Colors
The palette is strictly limited to an obsidian base, monochrome grays, and a vivid Orange-to-Amber spectrum. Use semi-transparent white overlays for borders to maintain a glassmorphism effect without sacrificing high contrast.

## Typography
Typography leverages the interplay between the ultra-modern `Inter` sans-serif and the elegant `Instrument Serif`. Use extreme negative tracking for large display headings and wide tracking for mono-spaced metadata.

## Spacing
Based on a strict 4px grid. Hero sections require aggressive padding (128px+) to allow the "Aura" background effects to breathe. Use tight internal spacing (8px-12px) for interactive UI steps.

## Layout
Layouts use a 12-column grid intersected by vertical hair-lines.
- **Foreground:** Interactive cards and typography.
- **Midground:** Masked images and 3D transforms.
- **Background:** Fixed luminosity-blend images and animated conic-gradient particles.

## Elevation & Depth
Depth is achieved through `perspective: 1000px` and Z-index layering. Elements should appear to float above the surface using `backdrop-blur-md` and `box-shadow` with orange-tinted glows (`rgba(249, 115, 22, 0.3)`).

## Shapes
Use `9999px` (capsule) for primary actions and buttons. Use `12px-16px` for container cards and mobile mockups. Avoid sharp corners for interactive elements to keep the feel organic and high-tech.

## Components
- **The Aura Button:** Utilizes conic-gradient rotation in a pseudo-element behind the main surface for a permanent "energy" effect.
- **Card Stacks:** Layers multiple image cards using `origin-bottom` and scale transitions to simulate a physical deck.
- **Grid Beams:** 1px wide vertical lines with an `animate-beam` keyframe simulating data flow.

## Motion
All scroll-triggered elements must use the `fadeSlideIn` animation. Hover states on interactive cards should include a minor Y-axis translation (-4px) and a boost in glow opacity. Card transitions utilize `cubic-bezier(0.34, 1.56, 0.64, 1)` for a playful, springy feel.

## Do's and Don'ts
- **Do:** Use `mix-blend-luminosity` for background imagery to prevent color clashing.
- **Do:** Use orange strictly for emphasis, status indicators, and primary CTAs.
- **Don't:** Use solid white backgrounds or heavy drop shadows without a color tint.
- **Don't:** Overlap high-contrast text on top of bright sections of background images; use a black gradient overlay.

## Accessibility
- Maintain a minimum contrast ratio of 4.5:1 for body text against the obsidian background.
- Use `selection:bg-orange-500/30` to ensure text remains legible during selection.
- Interactive items must have a minimum height of 44px for touch targets.