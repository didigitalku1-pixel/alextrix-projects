---
version: 1.0.0
name: MAD Soaps Visual System
description: Professional marine and automotive preservation system for high-end detailing services.
colors:
  primary: "rgb(37, 99, 235)"
  primary-hover: "rgb(29, 78, 216)"
  secondary: "rgb(16, 185, 129)"
  text-main: "rgb(15, 23, 42)"
  text-muted: "rgb(71, 85, 105)"
  text-light: "rgb(148, 163, 184)"
  surface: "#ffffff"
  background-alt: "#f8fafc"
  dark-bg: "#0b1220"
  border: "#e2e8f0"
typography:
  headings:
    family: "'Inter', sans-serif"
    weight: "600"
    letterSpacing: "-0.02em"
  body:
    family: "'Inter', sans-serif"
    weight: "400"
    size: "0.95rem"
  eyebrow:
    size: "0.625rem"
    weight: "600"
    letterSpacing: ".18em"
    transform: "uppercase"
spacing:
  header-height: "5rem"
  section-padding-mobile: "4rem"
  section-padding-desktop: "6rem"
  container-max: "80rem"
  gap-card: "1.5rem"
  inline-padding: "1.5rem"
rounded:
  default: "0.75rem"
  card: "1rem"
  button: "9999px"
  icon-box: "0.5rem"
  dropdown: "0.75rem"
components:
  nav:
    sticky: true
    z-index: "50"
    backdrop: "blur-md"
  dropdown:
    transition: "all 0.2s ease-out"
    transform: "translateY(0.5rem)"
    shadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1)"
  hero:
    min-height: "85vh"
    overlay-opacity: "0.5"
    blend-mode: "object-cover"
  buttons:
    primary-shadow: "0 4px 12px rgba(37, 99, 235, 0.2)"
    hover-transform: "translateY(-1px)"
  cards:
    border: "1px solid #e2e8f0"
    hover-shadow: "0 10px 30px -5px rgba(0, 0, 0, 0.05)"
  footer:
    z-index: "10"
    gradient: "radial-gradient(1200px 600px at 20% 0%, rgba(37,99,235,0.18), transparent 55%)"
motion:
  standard-duration: "0.2s"
  slide-in: "cubic-bezier(0.16, 1, 0.3, 1)"
  hero-fade: "1000ms ease-in-out"
---
## Overview
A technical and premium visual system emphasizing cleanliness, durability, and professional expertise. It uses high-contrast typography and deep sea-inspired gradients to establish trust in marine restoration.

## Colors
The palette is anchored by a deep Navy and vivid Royal Blue (Primary), balanced with Slate grays and an Emerald accent for status indicators. The dark mode footer uses complex radial gradients to mimic deep-water lighting.

## Typography
Relies exclusively on the 'Inter' typeface. Headings use tight letter-spacing and varying weights to establish hierarchy. Eyebrows utilize wide tracking and uppercase transforms for a technical, labeled look.

## Spacing
Built on a flexible grid where the header is fixed at 5rem. Section padding is aggressive (up to 6rem on desktop) to allow for high readability and visual 'breathability'.

## Layout
- **Fixed Header**: Always present with a backdrop-blur for content overlap.
- **Layer Stacks**: Uses z-index 50 for navigation and 100 for mobile drawers.
- **Component Stacking**: Hero sections use absolute-positioned slideshow layers behind content for depth.

## Elevation & Depth
- **Low Elevation**: Default cards use 1px borders with subtle shadow on hover.
- **High Elevation**: Dropdown panels and mobile menus use significant box-shadows and backdrop filters to pop from the background.

## Shapes
Features a mix of highly rounded elements (pill buttons, circular badges) and medium-radius containers (1rem cards). This balance avoids looking too 'playful' while maintaining a modern app-like feel.

## Components
- **Navigation**: Desktop uses a hover-triggered dropdown with categorized link sections and labels.
- **Hero Slideshow**: Multi-layer image stack with cross-fade transitions and pulse-animated status badges.
- **Service Cards**: Flex-based containers with icon headers and location tags in the footer area.
- **FAQ Accordion**: Native details/summary elements with custom CSS-animated chevrons.
- **Call-to-Action**: Advanced buttons feature 'beam-spin' CSS animations using conic gradients on the border.

## Motion
- **Hero**: 5-second interval slideshow with 1-second crossfades.
- **Interactive**: 200ms transitions for hover states and dropdown visibility.
- **Mobile Drawer**: Slide-from-right animation using a refined cubic-bezier for a snappier feel.

## Do's and Don'ts
- **Do**: Use high-resolution maritime imagery with dark overlays for text legibility.
- **Do**: Maintain the -0.02em tracking on headings for a premium feel.
- **Don't**: Use sharp 90-degree corners; maintain the rounded radius system across all containers.
- **Don't**: Overcomplicate the color palette; stick to the Blue/Slate/White core.

## Accessibility
- Uses semantic `<details>` for accordions.
- Maintains high color contrast (Royal Blue on White / White on Navy).
- Implements `:focus:outline-none` only when paired with visual scale or shadow transforms to ensure keyboard navigability.