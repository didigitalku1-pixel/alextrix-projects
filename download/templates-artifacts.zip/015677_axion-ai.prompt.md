Recreate the website "Axion AI - Autonomous AI Infrastructure" with high visual fidelity as a Tailwind CSS and Vanilla JS site. The result must match the supplied reference website, not a cleaned-up reinterpretation.

Preserve source quirks:
- Masking masks: The hero content and footer use specific `mask-image` linear gradients (280deg for hero, 180deg for access section) that clip content; maintain these exact angles and stop points.
- Logo height quirk: The logo `<img>` has a class `h-00` (likely a typo for `h-8`), preserve the intended visual scale.
- Layout behavior: The left sidebar is a fixed-width (16) vertical track that disappears on mobile.

CRITICAL FIDELITY CONSTRAINTS
- Background: Fixed `inset-0` grid background with `opacity-[0.03]` and `bg-grid` class (40px cells).
- Stacking: Major use of `relative z-10` for main content and `fixed/absolute z-0` for background assets.
- No smooth scroll: The source uses a `no-scrollbar` utility; ensure the industrial, rigid feel is preserved.

TECH STACK / DEPENDENCIES
- Framework: Tailwind CSS (via CDN: https://cdn.tailwindcss.com)
- Icons: Iconify (via CDN: https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js)
- Animation: CSS keyframes and Vanilla JS Intersection Observer.
- Fonts: Google Fonts: 'Inter', 'JetBrains Mono', 'Geist', 'Roboto', 'Montserrat', 'Poppins', 'Playfair Display', 'Instrument Serif', 'Merriweather', 'Bricolage Grotesque', 'Plus Jakarta Sans', 'Manrope', 'Space Grotesk', 'Work Sans', 'PT Serif', 'Geist Mono', 'Space Mono', 'Quicksand', 'Nunito', 'Newsreader', 'Google Sans Flex', 'Oswald', 'DM Sans', 'Cormorant Garamond'.

GLOBAL STYLE
- Body: `text-zinc-400 bg-[#050505] selection:bg-orange-600 font-inter`.
- Typography: Primary headings in `font-geist` (or Inter fallback), UI labels and telemetry in `font-mono` (JetBrains Mono).
- Borders: Persistent `border-zinc-800` throughout all grid containers.

ASSET MAP
- Logo: `https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/5deecba8-dc0a-4556-9777-de9a588a4428_1600w.png`
- Hero Image (Right): `https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/8826ae6a-df85-4863-aa7e-53251ae70196_1600w.jpg`
- Core Engine Image: `https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/8721dd74-22c0-4f42-a5e2-c29bfc289ba2_1600w.jpg`
- Access Section Background: `https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/f879b8e1-cba6-476a-9fea-a4abd7ca2645_3840w.jpg?w=800&q=80`

MEDIA BEHAVIOR
- Scanline Overlay: A `z-10` div with `linear-gradient` (rgba(18,16,16,0) 50%, rgba(0,0,0,0.25) 50%) mimicking a CRT display over the hero image and CTA section.
- Hero Image Transition: `group-hover:brightness-100 group-hover:[transform:scaleX(-1.05)_scaleY(1.05)] transition-[filter,transform] duration-1000 ease-linear`.
- Core Engine: Includes an `animate-spin-slow` (6s linear) iconify element `solar:refresh-circle-linear`.

LAYER STACK / POSITIONING MAP
- HEADER: `sticky top-0 z-40 h-16 border-b` with a 3-part layout (Logo/64px width, Nav/flex-1, Search/fixed-width).
- SIDEBAR (MD+): `fixed left-0 z-10 w-16 h-screen border-r` with vertical text `-rotate-90`.
- MAIN CONTENT: Vertical stack of large grid rows.
- SECTION MASKING: The Hero and Console sections use `mask-image: linear-gradient(...)` to fade content into the dark background at edges.

SECTION 1 - HERO GRID
- Layout: `lg:grid-cols-12` border-b.
- Left (7 cols): H1 "Scale With Autonomy" (8xl). Text "Autonomy" in `text-zinc-600`. Orange vertical border (2px) on paragraph.
- Right (5 cols): Contains the scanline-overlayed image and a floating "Nexus Engine V4.0" panel with a 12% CPU load bar.

SECTION 2 - FEATURES QUAD
- Layout: `grid-cols-1 md:grid-cols-2 lg:grid-cols-4`.
- Item 4 (Performance): CSS grid data visualization dots (8x6 grid) and hover-interactive orange bars.

SECTION 3 - SYSTEM FLOW (Operational Logic)
- Layout: `lg:grid-cols-12` with a center-focused core orchestration engine.
- Core: Three concentric animated rings: `animate-[spin_10s_linear_infinite]` (outer), `animate-[spin_15s_linear_infinite_reverse]` (inner). Orbital dots (white and zinc) at top/bottom centers.
- Terminal: Fixed height box (32px) at bottom of core section with live `LOG_STREAM` log lines (00:01:23 format).

SECTION 4 - VALIDATION CONSOLE
- Layout: Left panel (8 cols) with "Enterprise Integrity" headline; Right panel (4 cols) with live counters.
- Metrics: "Event_Throughput" with a pulse animation on the orange progress bar fill.

SECTION 5 - ACCESS CONTROL
- Pricing cards: Level 01, Level 02 (Featured), Level 03.
- Level 02: `lg:scale-105 z-10` with orange border `orange-600/30` and glowing shadow.

SECTION 6 - CTA (SYSTEM READY)
- Headline: "System Ready" (9xl) with text-zinc-700 on "Ready".
- Button: "[ Initialize_Build ]" with 4 corner border accents (2x2 squares) that change color on hover.

GLOBAL ANIMATION / INTERACTION RULES
- System Reveal: `.sys-reveal` triggers `opacity: 1`, `translateY(0)`, `filter: blur(0)` when in viewport via Intersection Observer.
- Counter Logic: Elements with `data-sys-counter` animate from 0 to target over 2800ms with a quint ease-out.
- Flicker: `.sys-flicker-anim` uses a high-frequency opacity keyframe (0.08 to 1).

COMMON MISTAKES TO AVOID
- Do not use rounded corners; this site uses hard-edged industrial blocks (`rounded-none`).
- Do not use standard Tailwind grays; strictly use `zinc-400` to `zinc-900` and `orange-600` for accents.
- Do not omit the `backdrop-blur-sm` on floating UI panels.
- Ensure the scanline gradient size `bg-[length:100%_2px,3px_100%]` is exact for the CRT effect.