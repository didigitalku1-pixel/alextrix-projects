Recreate the website "Nexastream" with high visual fidelity as a Tailwind CSS/HTML site. The result must match the supplied reference website, not a cleaned-up reinterpretation. Be precise with stacking contexts, CSS glassmorphism, and SVG animations.

Preserve source quirks:
- The trusted-by section uses a CSS mask to fade out logos on the left/right but the underlying container has a slight 4px left margin quirk.
- Mobile view features a forced dark gradient overlay (`#09090b/90`) that is absent on desktop.
- Some icons use Solar icon library classes with hardcoded width/height in SVG attributes while others use Lucide.

CRITICAL FIDELITY CONSTRAINTS
- Background: Use the exact Unicorn Studio script reference for the animated aura background. If unavailable, recreate as a fixed container with a dark mesh gradient and `backdrop-blur-xl`.
- Layering: The Grid Lines Background must be z-index 0, Content z-index 20, and Navigation z-index 50.
- Borders: Use the custom `[style*="--border-gradient"]` pattern for buttons and navigation items to simulate thin, lit edges.

TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN: https://cdn.tailwindcss.com)
- Lucide Icons (https://unpkg.com/lucide@latest)
- Iconify (https://code.iconify.design/3/3.1.0/iconify.min.js)
- Fonts: Inter (Sans) and Newsreader (Serif/Italic) from Google Fonts.
- UnicornStudio (v1.4.29) for the animated project `NMlvqnkICwYYJ6lYb064`.

GLOBAL STYLE
- Body: `bg-[#09090b]`, `antialiased`, custom selection colors (`sky-500/30`).
- Headlines: Use `font-serif-custom` (Newsreader) for primary H1 and section H2s.
- Scroll: Smooth scroll enabled; `no-scrollbar` utility for horizontal carousels.

ASSET MAP
- Logo: SVG using `solar:box-bold-duotone` path data inside a sky-blue gradient circle.
- Integration Logos: Linear, Stripe, Vercel (preserved as custom SVGs in the source).
- Background Project: NMlvqnkICwYYJ6lYb064 via Unicorn Studio.

VECTOR / ICON SHAPES
- Data Flow SVG: ViewBox `0 0 1200 900`. Contains `path#pathMain` (cubic bezier) and multiple `rect` shapes with `animate-beam` classes.
- Beam Animation: `@keyframes dash-flow { 0% { stroke-dashoffset: 0; } 100% { stroke-dashoffset: -1000; } }` with `stroke-dasharray: 40 400`.
- Database/Tag Icons: Solar Bold Duotone paths (exact path data provided in source inventory).

LAYER STACK / POSITIONING MAP
- Fixed Backdrop: `fixed top-0 -z-10` container with mask-image linear gradient.
- Main Container: `relative min-h-screen lg:max-w-[1400px] lg:rounded-[2.5rem] lg:border-white/10 backdrop-blur-xl`.
- Grid Lines: `absolute inset-0 z-0` flex container with `w-px bg-white/5` children.
- Floating Cards: `absolute z-40` with `animate-float` (subtle 8px translateY loop).

SECTION 1 - HERO / NAVIGATION
- Nav: Glassmorphism pill for menu (`bg-white/10`, `backdrop-blur-md`). Sign-in button with blue-to-indigo gradient and right arrow icon.
- Content: H1 with `leading-[0.95]` and italic sky-blue span. Primary button uses a spinning conic gradient border on hover.
- Trusted By: Horizontal flex container with `grayscale invert brightness-200` logos and a 90deg linear-gradient mask.

SECTION 2 - INTELLIGENT CLUSTERING
- Layout: 2-column grid.
- Card 1 (Semantic Context): Features a 3D perspective grid floor (`rotateX(60deg)`) and a flow diagram with `stroke-dasharray` SVG connectors. Includes floating tag pills with individual transforms (`rotate-2`, `rotate-3`, `-translate-y-2`).
- Card 2 (Granular Control): UI mockup of a filter window. Includes a nested "Or Group" with a dashed left border and a glow effect in the bottom right corner.

SECTION 3 - DATA INGESTION
- Layout: Text left, Diagram right.
- Ingestion Diagram: Features 7 animated SVG beam lines converging into a central pulsing circle node (`circle.animate-pulse`). Cards for "Incoming Payload" and "Production Database" are stacked vertically with dashed vertical connectors.

SECTION 4 - EXPERT CAROUSEL
- Layout: Header with "Get Matched" buttons and a horizontal scroll area.
- Carousel: `flex overflow-x-auto snap-x`. Cards feature a browser chrome mockup (3 dots and address bar) and dynamic mini-graph UI (Indigo bars with hover scaling).

SECTION 5 - FOOTER / CTA
- CTA: Large Serif H1 "Ready to unify your data stack?".
- Footer: 6-column grid on desktop. Social icons using `simple-icons`. Bottom row includes a live system status indicator (Green pulsing dot).

GLOBAL ANIMATION / INTERACTION RULES
- Float: `animate-float` 6s ease-in-out infinite.
- Spin: Conic gradient spin for button borders (3s linear infinite).
- Beams: `animate-beam` for SVG paths with varying delays (-1s to -6s).
- Hover: Cards transition with `-translate-y-2` and increased border opacity.

IMPLEMENTATION REQUIREMENTS
- Build as the first screen. Use original SVG path data for all icons and diagrams.
- Apply `backdrop-blur-xl` to the main container and `backdrop-blur-md` to floating UI elements.
- Preserve the exact font-serif italics in headers.
- Ensure the horizontal carousel uses the `no-scrollbar` utility and `snap-center` behavior.