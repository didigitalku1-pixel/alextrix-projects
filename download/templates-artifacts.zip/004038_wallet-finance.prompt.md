Recreate the website "Finance Visibility — Hero" with high visual fidelity as a Tailwind CSS and Vanilla JavaScript site.

The result must match the supplied reference website, not a cleaned-up reinterpretation.

Preserve source quirks:
- The main logo uses `invert` on a white background image to appear black.
- The "Dashboard Overview" card uses fixed background image URLs for specific stat icons instead of standard SVGs.
- The font is set to Inter globally but relies on `font-geist` (Geist) for specific headings and labels.
- The mobile menu toggle has no transition; it simply toggles the `hidden` class.

CRITICAL FIDELITY CONSTRAINTS
- Use the exact asset URLs provided in the ASSET MAP.
- Maintain the specific layer stacking order, including absolute-positioned background glows and aura components.
- Ensure the intersection observer logic for scroll animations matches the `animate-on-scroll` pattern.
- Do not substitute Lucide icons with other libraries; use the exact SVG paths or the Lucide CDN.

TECH STACK / DEPENDENCIES
- CSS: Tailwind CSS (CDN)
- Fonts: Inter (Google Fonts), Geist (Google Fonts)
- Icons: Lucide Icons (CDN)
- Scripts: Unicorn Studio (v1.4.29) for background effects

GLOBAL STYLE
- Body: `min-h-screen antialiased text-gray-900 bg-white font-sans` (Fallback to Inter).
- Keyframes: Define `@keyframes fadeSlideIn { 0% { opacity: 0; transform: translateY(30px); filter: blur(8px); } 100% { opacity: 1; transform: translateY(0); filter: blur(0px); } }`.

ASSET MAP
- Logo: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/02953e23-c5de-433c-a0fe-8485f05f3d30_1600w.png`
- Dashboard Icon 1: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/80920247-d9c0-406c-ab7e-1b9a6384c859_320w.jpg`
- Dashboard Icon 2: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/f2b40c17-c344-4f5c-ac16-474225fc14f7_320w.jpg`
- Dashboard Icon 3: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/65f30a55-40ff-4e4c-b89e-ef3cd7425bc4_320w.jpg`
- Dashboard Icon 4: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/626847d5-32bb-4329-bf3d-30078cdfeace_320w.jpg`
- Section Background: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/a53ef6f7-ea7c-457d-a8d3-dd91c9933e39_3840w.jpg`
- Workflow Visual: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/c75d3f3e-eb2f-440c-bc4d-6d508f576eb7_1600w.png`
- Mobile App Preview: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/ea3a5611-6ce0-4973-9c34-7b2492e29a38_800w.jpg`

LAYER STACK / POSITIONING MAP
- BACKGROUND: `aura-background-component` (Absolute, -z-10, h-screen).
- NAV: `header` (Relative, z-20, sticky behavior not required but border-b active).
- GLOWS: Three `blur-3xl` circles in Hero section (`fuchsia-500/30`, `indigo-500/30`, `amber-400/30`).
- CARD OVERLAYS: "Status" and "Trend" badges in Hero use `absolute` with `backdrop-blur` and `ring-1 ring-black/5`.

SECTION 1 - NAVIGATION
- Flex container with brand logo (150px wide) inverted.
- Desktop nav links: Overview, Product, Pricing, Docs.
- Button: "Get Started" (bg-gray-900, rounded-full).
- Mobile toggle: Hamburger menu `lucide-menu` toggling `hidden` state of `#mobileMenu`.

SECTION 2 - HERO
- Two-column grid (lg:grid-cols-2).
- Left: "Real-time Finance Platform" badge, H1 "Financial visibility, simplified.", P text, and two CTA buttons.
- Right: Dashboard card (`bg-white/70`, `backdrop-blur-md`). Contains a 2x2 grid of stat cards with specific image backgrounds for icons. Includes floating badges for "Status" and "Trend".

SECTION 3 - INTELLIGENT AUTOMATION (SLIDER)
- Carousel container with `snap-x snap-mandatory`.
- Implementation: Left/Right arrow buttons must handle `scrollBy` logic via JS. Arrows should change opacity and cursor to `not-allowed` when at bounds.
- Cards: Three articles with `min-w-[84%]` on mobile and `sm:min-w-[420px]`.

SECTION 4 - PRODUCT WORKFLOW
- Background: Dark (`bg-gray-950`) with specific Supabase image background and `radial-gradient` overlay.
- Layout: Numbered list (1, 2, 3) using `text-white/10` large numbers.
- Right: Workflow visual image with a floating "Insight: Anomaly detected" badge.

SECTION 5 - MOBILE APP
- Headline: "Your finance copilot, now on mobile".
- Badges: App Store (black) and Android waitlist (ghost/glass).
- Visual: Phone mockup with `bg-gray-900` ring, gradient blur background, and the mobile dashboard preview image.

SECTION 6 - FOOTER
- Background: `bg-gray-900` with indigo and fuchsia blur accents.
- Newsletter: Email input and subscribe button.
- Links: Four columns (Product, Company, Resources, Legal).
- Socials: Three icons in rounded boxes.

GLOBAL ANIMATION / INTERACTION RULES
- Scroll triggers: Elements with `.animate-on-scroll` start `animation-play-state: paused` and switch to `running` when `IntersectionObserver` detects 20% visibility.
- Hover states: Buttons use `scale-105` and `transition-all`.
- Slider Logic: Smooth scroll via `scroller.scrollBy` with a calculated `getAmount` based on container width.

COMMON MISTAKES TO AVOID
- Do not use generic icons; preserve the specific Supabase-hosted image icons for the dashboard stats.
- Do not omit the `backdrop-blur-md` on glassmorphism elements.
- Do not forget the `invert` class on the brand logo.
- Ensure the carousel fade masks (gradient overlays on left/right) are present and `pointer-events-none`.