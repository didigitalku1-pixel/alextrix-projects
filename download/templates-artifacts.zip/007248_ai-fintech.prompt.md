Recreate the website "Fabric - The Commerce Layer" with high visual fidelity as a Tailwind CSS and Vanilla JS site. The result must match the supplied reference website, not a reinterpretation.

Preserve source quirks:
- Inconsistent font usage: Includes imports for Roboto, Montserrat, and Poppins, but primarily uses Inter (sans) and Newsreader (serif).
- Broken label in Workflow Section: The "High Priority" tag contains a malformed div string fragment in the source HTML.
- Overlapping interaction: Fixed grid beams animate regardless of section position.

CRITICAL FIDELITY CONSTRAINTS
- No standard scrollbars: Use `::-webkit-scrollbar { width: 0px; }`.
- Strict Layering: Background grid, beams, and mouse-glow must remain fixed. Do not allow content to scroll behind them in a way that breaks z-index order (grid must be at z-0).
- Selection color: `selection:bg-cyan-500/20`.

TECH STACK / DEPENDENCIES
- CSS: Tailwind CSS (Play CDN), custom keyframe block for `animationIn` and `reveal-vertical`.
- Icons: Iconify (`iconify-icon` element and script version 2.1.0).
- Fonts: `Inter` (weights 200-600) and `Newsreader` (italics and weights 200-800) from Google Fonts.
- Background Script: `unicornStudio.umd.js` for project `UtvhDctN8AjL6tvf1yKd`.

GLOBAL STYLE
- Body: `bg-black text-gray-300 font-sans antialiased`.
- Mouse Spotlight: A fixed `inset-0` div with `radial-gradient(800px circle at var(--mouse-x, 50%) var(--mouse-y, 50%), rgba(34,211,238,0.04), transparent 40%)`.
- Keyframes:
  - `beam`: `0% { top: -200px; opacity: 0 } 10% { opacity: 1 } 90% { opacity: 1 } 100% { top: 100%; opacity: 0 }`.
  - `animationIn`: Vertical slide up (30px) with blur (8px) and opacity fade.

ASSET MAP
- Logo: `solar:infinity-bold` (Cyan-400).
- Marquee Icons: `simple-icons:openai`, `simple-icons:stripe`, `simple-icons:vercel`, `simple-icons:ycombinator`, `simple-icons:coinbase`, `simple-icons:linear`.
- Section Icons: `solar:transfer-horizontal-linear`, `solar:chart-square-linear`, `solar:box-minimalistic-linear`, `solar:layers-minimalistic-linear`, `solar:bolt-linear`, `solar:code-circle-linear`, `solar:shield-check-linear`, `solar:cpu-bolt-linear`.

VECTOR / ICON SHAPES
- Use exact SVG path for Vercel: `m12 1.608l12 20.784H0Z`.
- Use exact SVG path for Coinbase: Long coordinate string (see Source Inventory #8).

MEDIA BEHAVIOR
- Background: `aura-background-component` with `-z-10` positioning and a `mask-image: linear-gradient(to bottom, transparent, black 0%, black 80%, transparent)`.
- Beams: Absolute positioned 1px wide lines with `animate-beam`. Delays range from 0.5s to 5s.

LAYER STACK / POSITIONING MAP
- LAYER 0 (Fixed Background): Unicorn Studio canvas (-z-10) -> Mouse Spotlight Gradient (z-0) -> Grid Lines (z-0).
- LAYER 1 (Sticky Nav): Navigation (z-40) with `backdrop-blur-md` and `bg-black/60`.
- LAYER 2 (Main Content): Hero, Features, Workflow, Pricing, CTA sections.
- LAYER 3 (Overlays): Fixed Top Gradient Line (z-50) -> Fixed Bottom Fade Gradient (z-20).

SECTION 1 - NAVIGATION
- Layout: 80px height, flex justify-between, `max-w-7xl`.
- Elements: Logo (Fabric text), Desktop links with group-hover chevron effect, "Contact Sales" pill button with sliding gradient overlay (`-translate-x-full` to `translate-x-full`).

SECTION 2 - HERO
- Elements:
  - Top Badge: `New` tag with `Fabric 2.0` text and `arrow-right` icon.
  - Headlines: Split grid. Left: "The liquidity layer for AI agents" (Newsreader Italic). Right: "Global treasury at code speed."
  - Card: "Issue cards..." text in `font-serif italic`. Features three small profile circle overlaps labeled "F", "A", "B".
  - Marquee: Infinite horizontal loop of 6 partner icons using `animate-marquee`.

SECTION 3 - FEATURES
- Layout: 3-column grid.
- Visuals:
  - Card 1: Mock ledger rows with a floating "SETTLED" badge.
  - Card 2: Mock dropdown and pivot control icons.
  - Card 3: Dashed border container with an `animate-pulse` selection rectangle.
- Interaction: Each card uses `spotlight-group` to reveal a `radial-gradient` border on hover based on `--mouse-x-rel`.

SECTION 4 - WORKFLOW
- Layout: 2-column grid.
- Left Side: Headers and 4-item feature list (Instant Settlement, SDK Native, etc.). Latency and Volume stats at bottom.
- Right Side: Kanban-style UI mock (`#050505` bg).
  - Column "Pending" with 3 cards (TX-944, TX-948, TX-951).
  - Column "Settled" with 2 cards (TX-902, TX-402).
  - Testimonial: Large serif blockquote from "Elena K." with Coinbase logo.

SECTION 5 - PRICING
- Header: "Predictable costs for infinite scale."
- Grid: 4-column table. First column is labels (Throughput, Finality, etc.). Columns 2-4 are plans.
- Highlight: "Settlement" plan has a `cyan-500/20` gradient glow and a pulse dot indicator.

SECTION 6 - FOOTER
- Structure: 4 columns (Brand, Product, Resources, Company).
- Bottom Bar: Copyright notice left, partner icons (Y-Combinator, SOC, GDPR) right with `grayscale hover:grayscale-0` transition.

GLOBAL ANIMATION / INTERACTION RULES
- Mouse Tracking: JS listener updates `--mouse-x` and `--mouse-y` on body, and `--mouse-x-rel`, `--mouse-y-rel` on all `.spotlight-group` elements via `getBoundingClientRect()`.
- Scroll Reveal: `IntersectionObserver` adds `.animate` class to `.animate-on-scroll` elements. Threshold 0.1, rootMargin -5% bottom.

IMPLEMENTATION REQUIREMENTS
- Use original asset URLs for the background and all Iconify references.
- Maintain the specific Newsreader/Inter font pairings for headlines.
- Ensure the background grid and beams remain fixed while the body scrolls.
- Do not fix the source's malformed div tag in the Workflow section; preserve the text content exactly.