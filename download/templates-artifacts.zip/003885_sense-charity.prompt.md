Recreate the website "Sense Charity & Impact" with high visual fidelity as a Tailwind CSS/HTML5 site. The result must match the supplied reference, preserving the high-contrast aesthetic and complex layer stacking.

Preserve source quirks:
- The site uses "Inter" as a primary body font but injects "Geist" for all structural headings and semantic UI elements via the `.font-geist` class.
- Logo links (brand assets) use a `mix-blend-multiply` mode and a specific `invert` filter to maintain visibility against varying backgrounds.
- Marquee animations are used in both the hero media card and the "Global Impact Network" section, using vertical translation from `0` to `-50%`.

CRITICAL FIDELITY CONSTRAINTS
- Asset fidelity: Do not use placeholders. Use exact Supabase storage URLs for images and logos.
- Layer fidelity: Media overlays (quote bubbles, pills, team avatars) must use absolute positioning with specific `backdrop-blur-md` and `bg-black/70` styles.
- Motion fidelity: Implement the specific `IntersectionObserver` logic found in the source to trigger `opacity-0`, `translate-y-8`, and `blur-md` transitions on scroll.

TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN: https://cdn.tailwindcss.com)
- Lucide Icons (CDN: https://unpkg.com/lucide@latest)
- UnicornStudio.js (v1.4.29) for background effects
- Fonts: Inter (300-800), Geist (300-700), Playfair Display (400-900)

GLOBAL STYLE
- Page Background: `#FFFFFF` (white) with `aura-background-component` absolute overlay.
- Primary Text: `neutral-900` (#171717).
- Body Font: `Inter`.
- UI/Heading Font: `Geist`.

ASSET MAP
- Logo: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/cabcb3dd-d3a2-48fd-9b67-55ddd5de69ce_800w.jpg` (Used with `invert` and `mix-blend-multiply`)
- Partner Logos: `ffc4abed...`, `570e9153...`, `7808c442...` (Supabase paths)
- Hero Main Image: `https://hoirqrkdgbmvpwutwuwj-all.supabase.co/storage/v1/object/public/assets/assets/83622075-3856-42e4-b240-0a0d6f838a20_1600w.jpg`
- Avatar Set: `5aa0d46a...`, `a847bbaa...`, `054cd9f9...` (Supabase paths)

VECTOR / ICON SHAPES
- Use Lucide classes: `arrow-right`, `play`, `users`, `check-circle-2`, `plus`, `heart`, `graduation-cap`, `droplets`, `home`, `mail`.
- Preserve exact `stroke-width="2"` and `viewBox="0 0 24 24"` settings.

LAYER STACK / POSITIONING MAP
- AURA BACKGROUND: `absolute top-0 w-full -z-10 h-[1000px]`.
- HEADER: `relative`, z-index auto.
- HERO LEFT: `max-w-xl` with staggered animation delays (`delay-150`, `delay-300`, `delay-[450ms]`).
- HERO RIGHT (MEDIA): `relative overflow-hidden rounded-[28px]`. Contains a masked marquee container.
- MARQUEE OVERLAYS: `absolute z-20` (Pills top-right, Quote bubble left, Story reel center, Team badge bottom-right).

SECTION 1 - NAVIGATION
- Flex layout, items-between. Brand logo (130x40px).
- Desktop: Gap-6, text-sm, `font-geist`.
- Mobile: Hamburger button (`md:hidden`) with JS toggle logic for `id="mobile-menu"`.

SECTION 2 - HERO
- Grid: 1 col (mobile), 2 cols (lg).
- Social Proof: Flex `-space-x-2` for avatars next to text "1000+ donor active members".
- Headline: `lg:text-[64px]` leading `1.05`, tracking `tighter`.
- Media Card: 760px height (desktop), 600px (mobile). Features a vertical marquee of `Message Set 1` and `Message Set 2` (exact duplicates for seamless loop).

SECTION 3 - IMPACT TRAINING PROGRAM
- Container: `bg-white max-w-7xl border-black/5 border rounded-3xl mt-32`.
- Feature Cards: 3-column grid. Each card has a `bg-black` header area containing an image with `object-cover`.
- Stats Bar: 4-column grid of `neutral-100/50` blocks with large semi-bold numbers.

SECTION 4 - MASTER PROGRAM (CURRICULUM)
- Header: `Training Program` pill followed by text-6xl heading.
- Layout: `lg:grid-cols-12`.
- Left (Col 5): Blue header card (`bg-blue-600`) with "Free" pricing and list of benefits with `lucide-check-circle-2`.
- Right (Col 6): Vertical stack of accordion-style buttons (`Module 1` through `Module 6`) with `lucide-plus` icons and gradient dividers.

SECTION 5 - PRICING (IMPACT LEVELS)
- 4-card grid. Plans: Helper, Supporter, Champion (Featured), Leader.
- Champion Card: `bg-blue-700` with white text, `Most Popular` absolute floating badge, and inset box shadow `rgba(255, 255, 255, 0.1) 0px 1px 1px 0px inset`.

SECTION 6 - PARTNERSHIP FORM
- 2-column grid. Left: `bg-neutral-50` card with form fields (Email, Org, Message). Right: "Partner with purpose" copy and "Sarah Chen" contact card.
- Form styling: `ring-1 ring-neutral-200 focus:ring-2 focus:ring-neutral-900`.

SECTION 7 - FOOTER
- Structure: Dark internal container (`bg-gradient-to-b from-neutral-800 to-neutral-950`).
- Features: Newsletter signup, 3-column link grid (Programs, Get Involved, About).
- Bottom Bar: Copyright notice, Privacy/Terms, and Social icons (Instagram, Twitter/X, YouTube) using `bg-black/5` blocks.

GLOBAL ANIMATION / INTERACTION RULES
- Scroll Reveal: Elements with `data-animate` start at `opacity-0 translate-y-8 blur-md`. Remove these classes when `isIntersecting`.
- Marquee: `40s linear infinite` marquee-vertical animation.
- Hover States: Buttons use `hover:bg-neutral-800` or `hover:bg-white/90` with `transition-colors`.

IMPLEMENTATION REQUIREMENTS
- Use exact pixel values for spacing (`pt-8`, `pb-16`, `mt-32`).
- Do not substitute Lucide icons with others.
- Ensure `backdrop-blur-md` is applied to all dark overlays in the hero section.
- Preserve the `mask-image` linear gradients for the scrolling marquee containers to prevent hard edges.