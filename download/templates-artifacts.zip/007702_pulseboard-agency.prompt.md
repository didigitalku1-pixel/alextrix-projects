Recreate the website "PulseBoard Agency" with high visual fidelity as a Tailwind CSS and GSAP-powered site. The result must be a dark, futuristic landing page that matches the source's exact section order, layout, and motion behavior.

Preserve source quirks:
- The custom cursor uses a `mix-blend-mode: difference` which interacts with white text and black backgrounds.
- The "PULSEBOARD" logo uses a mix of font weights (Bold for PULSE, Light for BOARD).
- The site uses a vertical "pin-spacer" for the Portal and Horizontal scroll sections, creating specific scroll heights.
- There is a subtle SVG noise filter applied via a data URI to card backgrounds.

CRITICAL FIDELITY CONSTRAINTS
- Cursor must be hidden on the body via `cursor: none` and replaced with the custom circle follower.
- Grayscale-to-color filter transitions must occur on all image hover states.
- Horizontal scroll must be pinned using GSAP ScrollTrigger, not native overflow-x.
- Hero heading text must be wrapped in overflow-hidden containers for the "Mask Reveal" entry animation.

TECH STACK / DEPENDENCIES
- Tailwind CSS (Play CDN)
- GSAP 3.12.2 + ScrollTrigger
- Lenis 1.0.29 (Smooth Scroll)
- Google Fonts: Space Grotesk (Display), Manrope (Body), Geist Mono (Code)
- UnicornStudio.js v1.4.29 (Background effects)

GLOBAL STYLE
- Background: `#030303` (Deep Black)
- Text: `#ffffff` (White)
- Fonts: `Manrope` for body, `Space Grotesk` for headings.
- Glass effect: `rgba(255, 255, 255, 0.03)` with `backdrop-filter: blur(10px)`.

ASSET MAP
- Hero Portal: https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=2670&auto=format&fit=crop
- Project 1: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/a906012b-00b9-4610-82f7-f1a6ef3453d0_1600w.jpg
- Project 2: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/32017361-6e8f-4ec6-a109-c74c79273ec4_1600w.webp
- Project 3: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/4ca1e73a-69c6-49d2-b4d2-339c3a121dda_1600w.webp
- Testimonial Avatars: Use original Supabase URLs (2dbcdf02, 90ec73f0, 83a1ae5f, 39e15168, c92852bb).

VECTOR / ICON SHAPES
- Navigation Icon: 3-layer stack icon using `viewBox="0 0 24 24"` with path `M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5`.
- Architecture Schematic: Custom SVG containing three lines originating from 50%/50% to 20%/30%, 80%/30%, and 50%/80%.

LAYER STACK / POSITIONING MAP
- Background Layer (z-0 fixed): Aura background component with linear gradient mask (`transparent` to `black` 0-80%).
- Navigation (z-50 fixed): Full-width container with internal centered max-width 1600px glass pill.
- Cursor (z-9999 fixed): Circle div with absolute positioning via JS `mousemove`.
- Hero (z-10 relative): Features an absolute canvas background (`#hero-canvas`) with opacity 0.4.

SECTION 1 - HERO
- Background: Animated HTML5 Canvas rendering vertical white "streams" (width 3px, randomized opacity and speed).
- Content: Badge "Global Agency" -> Heading "ENGINEERING DIGITAL PERFECTION" (Split into 3 spans for mask reveal) -> Bottom row with description and stats (120+, $2B+).

SECTION 2 - THE PORTAL
- Layout: Sticky container (`150vh` parent, `100vh` child) pinning a central image.
- Animation: GSAP ScrollTrigger scales `#portal-image` from `30% w / 40% h` to `100% w / 100% h` based on scroll progress.
- Overlay: "SELECTEDWORKS" centered with `mix-blend-overlay`.

SECTION 3 - HORIZONTAL GALLERY
- Layout: Container holding a wide flex track (`w-max`).
- Behavior: GSAP transforms `x` of `#horizontal-track` by `-(trackWidth - windowWidth)`.
- Items: 3 Projects with card structure: Image aspect-16/9, grayscale-img class, Title, Category, and Index number (01, 02, 03).

SECTION 4 - 3D SERVICES
- Layout: 2-column grid. Left column sticky with title and expertise list. Right column scrolls with two 3D tilt cards.
- Card 1 (Strategy): Features a "Scanning Line" CSS animation and an SVG node network with `animate-pulse` circles.
- Card 2 (Development): Features a window-styled UI with a typed code animation (`animate-type`) and a floating "v2.0.4 Ready" badge.
- Interaction: Mouse move on `.card-3d-wrap` calculates tilt via `rotateX` and `rotateY` style strings.

SECTION 5 - TESTIMONIALS
- Layout: 3-column vertical grid with `fade-mask` (top/bottom gradient overlays).
- Animation: Columns have different `data-speed` attributes (0.5, -0.8, 0.6) applied via GSAP parallax scrub.

GLOBAL ANIMATION / INTERACTION RULES
- Custom Cursor: Adds `.hovered` class on `.hover-trigger` elements and `.view-cursor` on `.view-trigger` items.
- Smooth Scroll: Lenis instance with `duration: 0.8` and custom cubic easing.
- 3D Tilt: `transform-style: preserve-3d` on cards with `translateZ(40px)` on inner children for depth.

COMMON MISTAKES TO AVOID
- Do not use native scroll for horizontal section; it must be GSAP-controlled pinning.
- Do not omit the grayscale filter transition on the horizontal gallery images.
- Do not use standard fonts; the Space Grotesk tracking-tighter look is essential for the brand identity.