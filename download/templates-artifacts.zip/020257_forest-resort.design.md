---
version: 1.0.0
name: Aetheria Design System
description: A premium visual framework for luxury eco-retreats, utilizing high-contrast typography, glassmorphism, and nature-inspired stone palettes.

colors:
  bg-primary: "#fafaf9" # stone-50
  bg-dark: "#0c0a09" # stone-950
  bg-surface: "#1c1917" # stone-900
  text-primary: "#44403c" # stone-600
  text-heading: "#1c1917" # stone-900
  text-muted: "#a8a29e" # stone-400
  accent-green: "#166534" # green-800
  glass-white: "rgba(255, 255, 255, 0.05)"
  glass-dark: "rgba(0, 0, 0, 0.3)"

typography:
  display:
    family: "Oswald"
    weight: "300"
    lineHeight: "0.9"
    letterSpacing: "-0.05em"
  heading:
    family: "Playfair Display"
    weight: "400"
    lineHeight: "1.05"
  body:
    family: "Instrument Sans"
    weight: "400"
    lineHeight: "1.625"
  button:
    family: "Instrument Sans"
    weight: "500"
    letterSpacing: "0.025em"

spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "32px"
  section: "128px"

rounded:
  sm: "4px"
  md: "8px"
  lg: "12px"
  xl: "16px"
  card: "32px"
  full: "999px"

components:
  navigation:
    position: "fixed"
    top: "0"
    width: "100%"
    zIndex: "50"
    layout: "flex-between"
  hero:
    height: "110vh"
    overflow: "hidden"
    position: "relative"
  button-primary:
    padding: "16px 32px"
    rounded: "999px"
    transition: "300ms ease"
  card-glass:
    backdropBlur: "12px"
    border: "1px solid rgba(255, 255, 255, 0.1)"
    padding: "16px"
  suite-card:
    height: "80vh"
    aspect: "portrait-tablet"
    borderRadius: "32px"

motion:
  inView:
    initial: "opacity: 0, translateY: 30px, blur: 8px"
    target: "opacity: 1, translateY: 0, blur: 0px"
    duration: "800ms"
    easing: "ease-out"
---
## Overview
Aetheria is a premium forest-sanctuary design system. It uses high-contrast text layers and sophisticated glassmorphism to create a sense of architectural depth. The system is designed to showcase high-resolution nature photography while maintaining a clean, minimal interface.

## Colors
The palette is rooted in the "Stone" scale, moving from a near-white `stone-50` for light sections to a deep `stone-950` for luxury dark sections. Accents are rare, utilizing `green-800` for biological themes and `white/80` for glass text elements.

## Typography
- **Oswald**: Used for large, aggressive display headers and branding. Must be uppercase or tight-tracked.
- **Playfair Display**: Used for editorial headings and section titles to add a sense of luxury and heritage.
- **Instrument Sans**: The functional workhorse for body text, navigation, and user interface elements.

## Spacing
The system relies on generous padding (128px for sections) to evoke a sense of "stillness" and "space." Inner component padding follows a strict scale from 4px to 32px.

## Layout
Layouts use a 12-column grid within a maximum width of 1600px. High-impact sections use `h-[110vh]` to intentionally overflow the viewport, encouraging natural scrolling. Layers are stacked using `z-index` with specific focus on foreground floating cards over background image scales.

## Elevation & Depth
- **Progressive Blur**: A fixed top-of-page gradient blur creates a transition layer for the sticky navigation.
- **Glassmorphism**: Use `backdrop-filter: blur(10px)` for all floating UI elements.
- **Shadows**: Large-scale image components use `shadow-2xl` to separate from background surfaces.

## Shapes
The system transitions from hard-edged typography to organic, rounded corners. Main content blocks use `rounded-[2rem]` (32px), while interactive elements use `rounded-full` (999px).

## Components
- **Navigation**: Sticky, transparent, or glass-based with high z-index.
- **Hero**: Immersive full-screen background with a slow pulse scale animation and absolute-positioned content cards.
- **Suites & Cards**: Large-format containers with bottom-aligned text overlays and gradient-to-black masks.
- **Badges**: Small pill-shaped markers for statuses like "Now Booking" or "4 Guests."

## Motion
- **Entrance**: Use the `animationIn` keyframe for elements as they enter the viewport: translateY(30px) to 0 and blur(8px) to 0.
- **Interaction**: Subtle `scale-105` on image hover with long duration (1000ms) for a cinematic feel.
- **Backgrounds**: The `pulse` animation (10s duration) on hero images creates a living, breathing interface.

## Do's and Don'ts
- **Do**: Use high-resolution, desaturated nature photography.
- **Do**: Mix serif and sans-serif typography to create hierarchy.
- **Don't**: Use vibrant primary colors (reds, blues) that conflict with the stone/earth palette.
- **Don't**: Use sharp corners on large container images; keep them at 32px radius.

## Accessibility
- Maintain a minimum contrast ratio for text on glass backgrounds by using `glass-dark` for light text.
- Ensure icons from Iconify have descriptive labels or are purely decorative.
- Interactive buttons must have a minimum height of 44px for touch targets.