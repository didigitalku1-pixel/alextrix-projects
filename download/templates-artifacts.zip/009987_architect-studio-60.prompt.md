Recreate the website "Velos - Spatial Dynamics" with high visual fidelity as a Tailwind CSS and modern JavaScript site. The result must match the supplied reference exactly, maintaining its brutalist, cinematic architecture studio aesthetic.

### Preserve source quirks:
- Unusual spacing: The Hero section headline has a negative margin (-mt-2 md:-mt-8) for tight overlap between "VOID" and "& MASS".
- Scrollbar concealment: The `.hide-scrollbar` class is defined but the main overflow is on the body.
- Section Naming: Projects are labeled "VOL. II" and Material specs "VOL. III", skipping an explicit "VOL. I" label in the hero section.

### CRITICAL FIDELITY CONSTRAINTS
- **Fixed Grid Lines**: Render four vertical lines fixed across the viewport (`grid-lines`) with 15% opacity to serve as a background structure.
- **Cinematic Entrance**: The Hero image must use the exact `cinematicEntrance` keyframes (scale 1.4 + blur 20px -> scale 1.0 + blur 0px) over 3.5s.
- **Animation Logic**: Elements with `.animate-on-scroll` must remain in `animation-play-state: paused` until they enter the viewport, then trigger once via IntersectionObserver.
- **No Placeholders**: Use the exact image URLs and icon names provided in the ASSET MAP.

### TECH STACK / DEPENDENCIES
- **Framework**: HTML5, Tailwind CSS (via CDN: https://cdn.tailwindcss.com)
- **Fonts**: Inter (Sans), Playfair Display (Serif), Bricolage Grotesque (Display) via Google Fonts.
- **Icons**: Iconify (via `iconify-icon` element).
- **Scripts**: custom IntersectionObserver logic for scroll animations.

### GLOBAL STYLE
- **Colors**: Background `#030303` (neutral-950), Accents: White, Emerald-500 (Live pulse).
- **Typography**:
  - Default: Inter
  - Headings: Bricolage Grotesque (font-bold/font-light)
  - Accents: Playfair Display (italic)
- **Selection**: `selection:bg-white/20 selection:text-white`.

### ASSET MAP
- **Hero BG**: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/182d91e1-5681-49cf-a16e-4d56864a24ff_3840w.webp
- **Project 1 (Modern Villa)**: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/4774bd65-dd1f-43a8-9d99-2b78ca5ea386_800w.jpg
- **Project 2 (Glass Tower)**: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/2a662871-accd-4114-b384-662748965262_800w.jpg
- **Project 3 (Zen Garden)**: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/0bd8636d-7546-4246-b9ad-5d35e6af5f29_800w.jpg
- **Material 1 (Slate)**: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/33b2ce34-6e4a-4514-b20d-7104ecf14efd_320w.webp
- **Material 2 (Timber)**: https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/1e4989cc-80c7-45b1-9eb3-3f72b473d778_320w.jpg

### LAYER STACK / POSITIONING MAP
1. **Fixed Grid Layer (Z-5)**: 4 vertical lines spanning `h-full` within a `max-w-7xl` container.
2. **Navigation (Z-50)**: Fixed top-6, pill-shaped `backdrop-blur-xl` container.
3. **Hero Content**:
   - BG Image (Z-0) + Gradient Overlays (Radial/Linear).
   - Data Badge (Z-20): Top-32 right-12.
   - Main Text (Z-10): Bottom-aligned grid.
   - Glass Card (Z-10): `bg-neutral-950/60` with a moving shimmer overlay (`shimmer-effect`).

### SECTION 1 - HERO
- **Typography**: "VOID" (11rem Bricolage) and "& MASS" (Playfair Italic & Bricolage).
- **Glass Card**: Includes a shimmer animation translating `-150%` to `200%` skewX(-20deg).
- **Stats**: Grid layout with `border-t border-white/20` and font-bricolage numbers.

### SECTION 2 - VOL. II (PROJECTS)
- **Layout**: White background (`#fdfdfd`). Sticky-style grid background pattern (`radial-gradient(#000 1px, transparent 1px)` at 32px size).
- **Cards**: 520px height. Hover effect: `-translate-y-2` and `shadow-2xl`.
- **Interaction**: Project cards use `overflow-hidden` for an image `scale-105` effect on hover.

### SECTION 3 - VOL. III (MATERIALS)
- **Layout**: Dark background (`neutral-950`). Grid rows with 12-column spans.
- **Audio Visualizer**: Decorative bar chart representing "Acoustic Damping" using 12 divs with heights from 40% to 90%.
- **Table Style**: Vertical alignment in rows using `border-l border-white/10` dividers for specs.

### SECTION 4 - CAREERS
- **Layout**: Jobs list (col-span-8) and sticky filter sidebar (col-span-4).
- **Interaction**: Hovering a job row triggers `translate-x-1` on the title and swaps icon background from `white/5` to `white` (text black).
- **Sidebar**: Sticky positioning at `top-32` with `backdrop-blur-md`.

### SECTION 5 - METHODOLOGY
- **Layout**: 4-column grid of white cards with `border-neutral-200`.
- **Interactions**: Cards elevate (`-translate-y-1`) and transition icons to `bg-neutral-900` text white.

### GLOBAL ANIMATION / INTERACTION RULES
- **IntersectionObserver**: `threshold: 0.1, rootMargin: "0px 0px -5% 0px"`. Adds `.animate` class to trigger CSS keyframes.
- **Keyframes**: Implement `animationIn` (opacity 0 + translateY 30px + blur 8px -> final).
- **Hover States**: Smooth 300ms-500ms transitions on all buttons and cards.

### IMPLEMENTATION REQUIREMENTS
- Build exactly as a single landing page.
- Use the exact IDs: `#projects`, `#process`, `#careers`, `#methodology` for smooth scroll targets.
- Preserve the precise font sizing (`text-[15vw]` responsive logic).
- Use only original assets from the ASSET MAP.