Recreate the website "AURA" with high visual fidelity as a Tailwind CSS and Vanilla JavaScript landing page. The final result must be a pixel-perfect reconstruction of the provided source, maintaining its skeuomorphic UI language, soft blue gradients, and specific layer stacking.

Preserve source quirks:
- Custom shadow values (e.g., shadow-[0_14px_38px_-22px_rgba(15,23,42,0.42)]) and inner borders (inset_0_1px_0_white) are used throughout to create depth.
- The pricing toggle uses a specific 260ms countdown/countup animation logic for values.
- Use of specific stroke-width: 1.5 for all solar iconify-icons.

CRITICAL FIDELITY CONSTRAINTS
- The background must include a fixed ambient drift effect using three separate animated blobs and a moving dot grid.
- Layout must adhere to the specific grid ratios: 1.02fr_0.98fr for Hero and 0.9fr_1.1fr for Transformation sections.
- All cards must use specific Tailwind-based skeuomorphic borders: white/90 border with inset shadows.

TECH STACK / DEPENDENCIES
- Tailwind CSS (CDN)
- Iconify-icon (v1.0.7) for all solar icons
- Google Fonts: Inter (300,400,500,600) and JetBrains Mono (400,500,600)
- UnicornStudio.js (v1.4.29) for specific project id: ty3N7ZPaIU7KlWixQFIc

GLOBAL STYLE
- Body: bg-[#f3f5f8], text-slate-900, font-['Inter',sans-serif], antialiased selection:bg-blue-100.
- Navigation: Fixed top-0, backdrop-blur-2xl, border-white/90, rounded-full.

ASSET MAP
- Icon Library: solar:stars-linear, solar:arrow-right-linear, solar:play-circle-linear, solar:shield-check-linear, solar:devices-linear, solar:bolt-circle-linear, solar:microphone-linear, solar:checklist-minimalistic-linear, solar:lock-keyhole-linear, solar:calendar-mark-linear, solar:case-round-linear, solar:sun-2-linear, solar:moon-stars-linear.
- Logo: Text-based "AU" in JetBrains Mono inside a gradient circle.

LAYER STACK / POSITIONING MAP
- BACKGROUND LAYER (fixed, z-[-10]): .aura-background-component with linear-gradient alpha mask.
- AMBIENT LAYER (fixed, z-0): contains .aura-bg-blob-one (top -12%, left -12%), .aura-bg-blob-two (bottom -18%, right -10%), .aura-bg-blob-three (center), and .aura-bg-dots grid.
- HEADER (fixed, z-50): sticky-ready navigation.
- MAIN CONTENT (relative, z-10): Sequential scrollable sections.
- OVERLAYS (absolute): Floating status bubbles (aura-float-bubble) in hero and CTA sections.

SECTION 1 - HERO
- Layout: 2-column grid (lg:grid-cols-[1.02fr_0.98fr]).
- Left: Headline uses text-shadow 0 1px 1px white/80 and specific leading-[0.92]. Buttons include deep blue gradients (from-blue-500 to-blue-600).
- Right: A complex mockup stack with absolute-positioned bubbles. Bubbles use aura-float-soft animation (50% translation: -8px). Mockup frame features a red/amber/emerald top bar simulation.

SECTION 2 - PROBLEM / TRANSFORMATION
- Feature Grid: 4-column rounded-[2rem] cards with hover:-translate-y-1.
- Transformation Block: Dark mode container (from-[#172033] to-[#101827]) with a 40px grid texture. Inner "Input -> Action" pipeline mockup showing scattered inputs (left) connecting to ranked outputs (right) via a dashed animated line.

SECTION 3 - CORE CAPABILITIES
- ID: #features.
- Grid: 3-column layout of high-gloss white/68 cards. Each card has a specific badge (e.g., "3 priorities ready").
- Wide card: Span 3 columns (lg:col-span-3) for "End-of-Day Wrap" with a custom triple-metric dashboard inside.

SECTION 4 - WORKFLOW TIMELINE
- ID: #workflow.
- Visual: Dashed connection line with a gradient flow animation (auraConnectionFlow). 4-step sequence featuring blue gradient number circles over glossy white cards.

SECTION 5 - BUILT FOR / USE CASES
- ID: #built-for.
- 3-card stack: "Founder Mode", "Executive Brief" (Featured Blue Gradient), and "Creator System". Each contains an inner simulated UI panel with specific clip-paths.

SECTION 6 - PRIVACY & PRICING
- ID: #privacy & #pricing.
- Privacy: Layout with a browser-style privacy center mockup featuring functional-looking toggles.
- Pricing Toggle: Skeuomorphic pill using ease-[cubic-bezier(0.4,0,0.2,1)] for the sliding background.
- Cards: Three-tier structure with the "Pro" card featuring a floating "Recommended" badge.

GLOBAL ANIMATION / INTERACTION RULES
- Ambient blobs: Drift using translate3d and scale over 26s, 32s, and 30s cycles.
- Hero Bubbles: Sequential entry using aura-bubble-in animation with delays from 300ms to 1200ms.
- Pricing Logic: JavaScript must increment/decrement price-val elements using a setInterval loop that calculates stepTime based on a 260ms duration.

IMPLEMENTATION REQUIREMENTS
- Use original Tailwind color hexes: #f3f5f8 (bg), #172033 (dark bg), #3b82f6 (blue-500).
- Maintain exact 1px dashed borders and inset box-shadows to ensure skeuomorphic depth.
- Ensure all links are smooth-scroll anchors with a target offset of 7.5rem.